#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# Waleed Android Repair & Verification Script (Termux ARM64)
# Target: com.waleed.video v0.2.0+2 (Flutter 3.47.7 / Engine deb287481e)
# ==============================================================================
set -euo pipefail

PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
FLUTTER_ROOT="${FLUTTER_ROOT:-$PREFIX/opt/flutter}"
ANDROID_SDK="${ANDROID_SDK:-$PREFIX/opt/android-sdk}"
PROJECT_DIR="${PROJECT_DIR:-/data/data/com.termux/files/home/waleed-app/flutter_app}"
ENGINE_HASH="deb287481e3ce9468f3434937ced4240a70539ca"
EXPECTED_VM_HASH="0451907c2eaa8467e848c0067bfe8ed4"
LINUX_DESKTOP_GEN_SNAPSHOT_SHA256="471523cad24d5eed1f9e582b6ae0e04b8bfd40482957d552334a9a9dff5a9ec1"

ENG_DIR="$FLUTTER_ROOT/bin/cache/artifacts/engine"
ANDROID_REL_DIR="$ENG_DIR/linux-arm64-android-release"
UPSTREAM_X64_DIR="$ENG_DIR/android-arm64-release/linux-x64"
BACKUP_STAMP="$(date +%Y%m%d_%H%M%S)"

echo "============================================================"
echo "[1/6] Checking environment and removing broken symlink..."
echo "============================================================"

mkdir -p "$ANDROID_REL_DIR" "$UPSTREAM_X64_DIR"

if [ -L "$ANDROID_REL_DIR/gen_snapshot" ]; then
    LINK_TARGET="$(readlink "$ANDROID_REL_DIR/gen_snapshot" || true)"
    echo "Found symlink at $ANDROID_REL_DIR/gen_snapshot -> $LINK_TARGET"
    if [ -f "$ANDROID_REL_DIR/gen_snapshot" ]; then
        CUR_SHA="$(sha256sum "$ANDROID_REL_DIR/gen_snapshot" | awk '{print $1}')"
        if [ "$CUR_SHA" = "$LINUX_DESKTOP_GEN_SNAPSHOT_SHA256" ]; then
            echo "Removing broken symlink to Linux desktop gen_snapshot ($CUR_SHA)..."
            rm -f "$ANDROID_REL_DIR/gen_snapshot"
        fi
    fi
elif [ -f "$ANDROID_REL_DIR/gen_snapshot" ]; then
    CUR_SHA="$(sha256sum "$ANDROID_REL_DIR/gen_snapshot" | awk '{print $1}')"
    if [ "$CUR_SHA" = "$LINUX_DESKTOP_GEN_SNAPSHOT_SHA256" ]; then
        echo "Removing copy of Linux desktop gen_snapshot ($CUR_SHA)..."
        mv "$ANDROID_REL_DIR/gen_snapshot" "$ANDROID_REL_DIR/gen_snapshot.linux_desktop.$BACKUP_STAMP.bak"
    fi
fi

# Function to verify whether a gen_snapshot binary is compiled for Android + compressed-pointers
is_android_gen_snapshot() {
    local bin="$1"
    [ -f "$bin" ] || return 1
    strings "$bin" | grep -Fq "$EXPECTED_VM_HASH" || return 1
    strings "$bin" | grep -Fq " compressed-pointers" || return 1
    strings "$bin" | grep -Fq " android" || return 1
    return 0
}

echo "============================================================"
echo "[2/6] Locating or downloading Android-target gen_snapshot..."
echo "============================================================"

if [ -f "$ANDROID_REL_DIR/gen_snapshot" ] && is_android_gen_snapshot "$ANDROID_REL_DIR/gen_snapshot"; then
    echo "Verified native Android-target gen_snapshot at $ANDROID_REL_DIR/gen_snapshot"
else
    UPSTREAM_URL="https://storage.googleapis.com/flutter_infra_release/flutter/${ENGINE_HASH}/android-arm64-release/linux-x64.zip"
    UPSTREAM_BIN="$UPSTREAM_X64_DIR/gen_snapshot"

    if ! is_android_gen_snapshot "$UPSTREAM_BIN"; then
        echo "Downloading official Android-target gen_snapshot for engine $ENGINE_HASH..."
        TMP_ZIP="${TMPDIR:-$PREFIX/tmp}/android-arm64-release-linux-x64.zip"
        curl -fL --retry 3 -o "$TMP_ZIP" "$UPSTREAM_URL"
        unzip -o "$TMP_ZIP" -d "$UPSTREAM_X64_DIR"
        chmod +x "$UPSTREAM_BIN"
        rm -f "$TMP_ZIP"
    fi

    if ! is_android_gen_snapshot "$UPSTREAM_BIN"; then
        echo "ERROR: $UPSTREAM_BIN did not pass Android compressed-pointers metadata check." >&2
        exit 1
    fi
    echo "Verified official Android-target binary strings in $UPSTREAM_BIN:"
    strings "$UPSTREAM_BIN" | grep -E "compressed-pointers|${EXPECTED_VM_HASH}" | head -n 5

    # Detect how to execute the x86_64 Android-target gen_snapshot on ARM64 Termux
    if command -v blink >/dev/null 2>&1; then
        RUNNER="blink"
    elif command -v box64 >/dev/null 2>&1; then
        RUNNER="box64"
    elif command -v qemu-x86_64 >/dev/null 2>&1 && [ -f "/lib64/ld-linux-x86-64.so.2" ]; then
        RUNNER="qemu-x86_64"
    elif command -v qemu-x86_64-static >/dev/null 2>&1 && [ -f "/lib64/ld-linux-x86-64.so.2" ]; then
        RUNNER="qemu-x86_64-static"
    else
        echo ""
        echo "NOTE: $UPSTREAM_BIN is an x86_64 Linux ELF binary."
        echo "On ARM64 Termux, install a user-mode runner (e.g. 'pkg install blink' or 'pkg install qemu-user-x86-64')"
        echo "OR install the termux-flutter-wsl .deb package that bundles a native aarch64 linux-arm64-android-release/gen_snapshot."
        exit 2
    fi

    cat > "$ANDROID_REL_DIR/gen_snapshot" <<EOF
#!$PREFIX/bin/bash
exec $RUNNER "$UPSTREAM_BIN" "\$@"
EOF
    chmod 755 "$ANDROID_REL_DIR/gen_snapshot"
    echo "Created wrapper at $ANDROID_REL_DIR/gen_snapshot using $RUNNER"
fi

echo "============================================================"
echo "[3/6] Cleaning stale Linux AOT snapshots..."
echo "============================================================"

cd "$PROJECT_DIR"
if [ -d ".dart_tool/flutter_build" ]; then
    find .dart_tool/flutter_build -name "app.so" -exec rm -fv {} +
fi

echo "============================================================"
echo "[4/6] Compiling and proving AOT snapshot metadata..."
echo "============================================================"

VERIFY_OUT="$PROJECT_DIR/build/aot_verify_$BACKUP_STAMP"
mkdir -p "$VERIFY_OUT"

flutter assemble -v \
    --output="$VERIFY_OUT" \
    -dTargetPlatform=android-arm64 \
    -dTargetFile=lib/main.dart \
    -dBuildMode=release \
    android_aot_release_android-arm64

TEST_APP_SO="$VERIFY_OUT/arm64-v8a/app.so"
if [ ! -f "$TEST_APP_SO" ]; then
    echo "ERROR: AOT verification failed to produce $TEST_APP_SO" >&2
    exit 1
fi

SNAPSHOT_FEATURES="$(strings "$TEST_APP_SO" | grep -E "^${EXPECTED_VM_HASH}product " | head -n 1 || true)"
echo "Observed AOT snapshot header:"
echo "  $SNAPSHOT_FEATURES"

if ! echo "$SNAPSHOT_FEATURES" | grep -Fq "arm64 android compressed-pointers"; then
    echo "FATAL: Snapshot does NOT contain 'arm64 android compressed-pointers'!" >&2
    echo "Refusing to proceed with Gradle APK build." >&2
    exit 1
fi
echo "SUCCESS: Verified 'arm64 android compressed-pointers' in $TEST_APP_SO"

echo "============================================================"
echo "[5/6] Building Release APK and verifying package..."
echo "============================================================"

flutter build apk --release --target-platform android-arm64 --no-pub -v

APK_PATH="$PROJECT_DIR/build/app/outputs/flutter-apk/app-release.apk"
if [ ! -f "$APK_PATH" ]; then
    echo "ERROR: Expected APK not found at $APK_PATH" >&2
    exit 1
fi

echo "Verifying embedded lib/arm64-v8a/libapp.so inside APK..."
TMP_EXTRACT="$(mktemp -d "${TMPDIR:-$PREFIX/tmp}/apk_verify.XXXXXX")"
unzip -q "$APK_PATH" "lib/arm64-v8a/libapp.so" -d "$TMP_EXTRACT"
APK_SNAPSHOT_FEATURES="$(strings "$TMP_EXTRACT/lib/arm64-v8a/libapp.so" | grep -E "^${EXPECTED_VM_HASH}product " | head -n 1 || true)"
rm -rf "$TMP_EXTRACT"

echo "APK libapp.so features: $APK_SNAPSHOT_FEATURES"
if ! echo "$APK_SNAPSHOT_FEATURES" | grep -Fq "arm64 android compressed-pointers"; then
    echo "FATAL: APK libapp.so does not match 'arm64 android compressed-pointers'!" >&2
    exit 1
fi

echo "============================================================"
echo "[6/6] Verifying APK alignment and signature..."
echo "============================================================"

if command -v zipalign >/dev/null 2>&1; then
    zipalign -c -v 4 "$APK_PATH" | tail -n 5
fi
if command -v apksigner >/dev/null 2>&1; then
    apksigner verify --verbose "$APK_PATH"
fi

echo "Done! Verified APK SHA-256:"
sha256sum "$APK_PATH"

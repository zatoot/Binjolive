# تطبيق وليد — Corrected Target Scope
Updated: 2026-11-06

## Product definition
Waleed is an independently implemented Android application intended to preserve the user-visible functionality and workflows of the reference Lingvotube version 5.2.3. The intended product difference is removal of advertising from the application.

## Non-negotiable acceptance rule
A build is not considered a Waleed feature-equivalent release merely because it builds or accepts a pasted video URL. It must implement and pass tests for the reference app's video discovery/navigation, search, player, captions/translation, voice-over, bookmarks, playlists, and settings workflows, subject to verified behavior in the reference installation.

## Scope
- Preserve the reference app's information architecture and user workflows, including navigation and screen states.
- Recreate functionality using independently written code and original implementation assets. Do not copy proprietary source code, private credentials, signing keys, or protected branding/assets.
- Remove the reference app's ad SDK integration, Advertising ID use, banner/interstitial/rewarded ads, and any workflow gate requiring a user to watch an advertisement.
- Do not claim that this removes advertisements that YouTube itself may show inside YouTube content.
- Preserve existing non-ad purchase/premium behavior only as explicitly verified and required; do not redesign or silently remove features.

## Known scope baseline
See `reports/LINGVOTUBE_FUNCTION_INVENTORY_20261106.md`. That inventory is a static-inspection baseline; live behavior and conditional states still require on-device verification.

## Release gate
No release may be described as complete until:
1. Each feature in the verified feature matrix has an implementation status and device test result.
2. App navigation and screen flows match the reference workflows closely enough to be functionally equivalent.
3. No ad SDK, Advertising ID permission, ad placement, or watch-an-ad gate remains in the Waleed APK.
4. APK installation, launch, player, captions, translation, voice-over, and persistence tests pass on the target Android device.

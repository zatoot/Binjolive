import 'package:youtube_explode_dart/youtube_explode_dart.dart';

import '../models/waleed_video.dart';

class YoutubeCatalogService {
  final YoutubeExplode _youtube = YoutubeExplode();
  bool _closed = false;

  YoutubeExplode get client => _youtube;

  Future<List<WaleedVideo>> searchVideos(
    String query, {
    int limit = 24,
    bool captionsOnly = false,
  }) async {
    if (_closed) {
      throw StateError('YouTube service has already been closed.');
    }
    final trimmed = query.trim();
    if (trimmed.isEmpty) return const [];

    var page = await _youtube.search.search(trimmed);
    final videos = <WaleedVideo>[];

    while (true) {
      for (final dynamic item in page) {
        if (videos.length >= limit) break;
        try {
          String id;
          try {
            id = item.id.value as String;
          } catch (_) {
            id = item.id.toString();
          }
          final String title = (item.title as String?)?.trim() ?? '';
          final String channel = (item.author as String?)?.trim() ?? '';
          final Duration? duration = item.duration as Duration?;
          final String thumbnail = _thumbnailUrl(item.thumbnails);

          if (id.isEmpty || title.isEmpty) continue;
          if (captionsOnly && !await hasCaptions(id)) continue;
          videos.add(
            WaleedVideo(
              id: id,
              title: title,
              channel: channel,
              thumbnailUrl: thumbnail,
              duration: duration,
            ),
          );
        } catch (_) {
          // Ignore malformed video results without failing the entire search.
        }
      }
      if (videos.length >= limit) break;
      final nextPage = await page.nextPage();
      if (nextPage == null) break;
      page = nextPage;
    }
    return videos;
  }

  Future<bool> hasCaptions(String videoId) async {
    try {
      final manifest = await _youtube.videos.closedCaptions.getManifest(
        videoId,
      );
      return manifest.tracks.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  String _thumbnailUrl(dynamic thumbnails) {
    try {
      final dynamic high = thumbnails.highResUrl;
      if (high is String && high.isNotEmpty) return high;
    } catch (_) {}
    try {
      final dynamic medium = thumbnails.mediumResUrl;
      if (medium is String && medium.isNotEmpty) return medium;
    } catch (_) {}
    try {
      final dynamic low = thumbnails.lowResUrl;
      if (low is String && low.isNotEmpty) return low;
    } catch (_) {}
    return '';
  }

  Future<List<WaleedVideo>> loadForYouFeed({
    List<WaleedVideo> recent = const <WaleedVideo>[],
    int limit = 24,
  }) async {
    final output = <WaleedVideo>[];
    final seen = <String>{...recent.map((video) => video.id)};

    // Build recommendations from the user's own recent watch history first.
    // YouTube's related-video endpoint is used rather than disguising a generic
    // text search as a personalized feed.
    for (final seed in recent.take(3)) {
      try {
        final source = await _youtube.videos.get(seed.id);
        final related = await _youtube.videos.getRelatedVideos(source);
        if (related == null) continue;
        for (final dynamic item in related) {
          try {
            String id;
            try {
              id = item.id.value as String;
            } catch (_) {
              id = item.id.toString();
            }
            final title = (item.title as String?)?.trim() ?? '';
            if (id.isEmpty || title.isEmpty || !seen.add(id)) continue;
            output.add(
              WaleedVideo(
                id: id,
                title: title,
                channel: (item.author as String?)?.trim() ?? '',
                thumbnailUrl: _thumbnailUrl(item.thumbnails),
                duration: item.duration as Duration?,
              ),
            );
            if (output.length >= limit) break;
          } catch (_) {
            // Ignore malformed or non-video recommendation entries.
          }
        }
      } catch (_) {
        // A single unavailable history item must not break the whole feed.
      }
      if (output.length >= limit) break;
    }

    if (output.isNotEmpty) return output;
    // Cold-start fallback: clearly a generic discovery query, not personalized.
    return searchVideos('popular videos', limit: limit);
  }

  Future<void> close() async {
    if (_closed) return;
    _closed = true;
    _youtube.close();
  }
}

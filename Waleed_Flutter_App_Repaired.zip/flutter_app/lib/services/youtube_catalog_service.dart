import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:youtube_explode_dart/youtube_explode_dart.dart';

import '../models/waleed_video.dart';

class FeedCategory {
  const FeedCategory({
    required this.id,
    required this.label,
    required this.query,
  });

  final String id;
  final String label;
  final String query;
}

class YoutubeCatalogService {
  final YoutubeExplode _youtube = YoutubeExplode();
  final http.Client _http = http.Client();
  bool _closed = false;

  YoutubeExplode get client => _youtube;

  static const List<FeedCategory> categories = [
    FeedCategory(id: 'all', label: 'من أجلك', query: 'TED Ed animated lessons subtitles'),
    FeedCategory(id: 'english', label: 'تعلّم الإنجليزية', query: 'learn english conversation subtitles'),
    FeedCategory(id: 'ted', label: 'محاضرات TED', query: 'TED talks inspiring speeches'),
    FeedCategory(id: 'tech', label: 'تقنية وذكاء اصطناعي', query: 'artificial intelligence technology explained'),
    FeedCategory(id: 'science', label: 'وثائقيات وعلوم', query: 'BBC Earth National Geographic documentary short'),
    FeedCategory(id: 'stories', label: 'قصص وتاريخ', query: 'history documentary short story animated'),
  ];

  static const List<WaleedVideo> _curatedFallbackVideos = [
    WaleedVideo(
      id: 'arj7oStGLkU',
      title: 'Tim Urban: Inside the mind of a master procrastinator | TED',
      channel: 'TED',
      thumbnailUrl: 'https://i.ytimg.com/vi/arj7oStGLkU/hqdefault.jpg',
      duration: Duration(minutes: 14, seconds: 4),
    ),
    WaleedVideo(
      id: 'UF8uR6Z6KLc',
      title: "Steve Jobs' 2005 Stanford Commencement Address",
      channel: 'Stanford',
      thumbnailUrl: 'https://i.ytimg.com/vi/UF8uR6Z6KLc/hqdefault.jpg',
      duration: Duration(minutes: 15, seconds: 5),
    ),
    WaleedVideo(
      id: 'eIho2S0ZahI',
      title: 'How to speak so that people want to listen | Julian Treasure | TED',
      channel: 'TED',
      thumbnailUrl: 'https://i.ytimg.com/vi/eIho2S0ZahI/hqdefault.jpg',
      duration: Duration(minutes: 9, seconds: 58),
    ),
    WaleedVideo(
      id: '8S0FDjFBj8o',
      title: 'The power of vulnerability | Brené Brown | TED',
      channel: 'TED',
      thumbnailUrl: 'https://i.ytimg.com/vi/8S0FDjFBj8o/hqdefault.jpg',
      duration: Duration(minutes: 20, seconds: 50),
    ),
    WaleedVideo(
      id: 'qp0HIF3SfI4',
      title: 'How great leaders inspire action | Simon Sinek | TED',
      channel: 'TED',
      thumbnailUrl: 'https://i.ytimg.com/vi/qp0HIF3SfI4/hqdefault.jpg',
      duration: Duration(minutes: 18, seconds: 4),
    ),
    WaleedVideo(
      id: 'H14bBuluwB8',
      title: 'Grit: the power of passion and perseverance | Angela Lee Duckworth',
      channel: 'TED',
      thumbnailUrl: 'https://i.ytimg.com/vi/H14bBuluwB8/hqdefault.jpg',
      duration: Duration(minutes: 6, seconds: 13),
    ),
  ];

  Future<List<WaleedVideo>> searchVideos(
    String query, {
    int limit = 24,
    bool captionsOnly = false,
  }) async {
    if (_closed) {
      throw StateError('YouTube service has already been closed.');
    }
    final trimmed = query.trim();
    if (trimmed.isEmpty) return const [];

    // Direct URL or Video ID support in search box
    final directId = WaleedVideo.tryExtractVideoId(trimmed);
    if (directId != null) {
      final details = await fetchVideoDetails(directId);
      return [details];
    }

    // Engine 1: Fast InnerTube JSON search (supports captions filter via YouTube params `EgIoAQ%3D%3D`)
    try {
      final innerResults = await _innerTubeSearch(
        trimmed,
        limit: limit,
        captionsOnly: captionsOnly,
      );
      if (innerResults.isNotEmpty) {
        return innerResults;
      }
    } catch (_) {}

    // Engine 2: youtube_explode_dart search fallback
    final videos = <WaleedVideo>[];
    final seenIds = <String>{};
    try {
      var page = await _youtube.search
          .search(captionsOnly ? '$trimmed subtitles' : trimmed)
          .timeout(const Duration(seconds: 12));

      while (videos.length < limit) {
        for (final dynamic item in page) {
          if (videos.length >= limit) break;
          try {
            String id;
            try {
              id = item.id.value as String;
            } catch (_) {
              id = item.id.toString();
            }
            final String title = (item.title as String?)?.trim() ?? '';
            final String channel = (item.author as String?)?.trim() ?? '';
            final Duration? duration = item.duration as Duration?;
            final String thumbnail = _thumbnailUrl(item.thumbnails, id);

            if (id.isEmpty || title.isEmpty || !seenIds.add(id)) continue;
            videos.add(
              WaleedVideo(
                id: id,
                title: title,
                channel: channel,
                thumbnailUrl: thumbnail,
                duration: duration,
              ),
            );
          } catch (_) {}
        }
        if (videos.length >= limit) break;
        final nextPage = await page.nextPage().timeout(const Duration(seconds: 8));
        if (nextPage == null || nextPage.isEmpty) break;
        page = nextPage;
      }
    } catch (_) {
      if (videos.isEmpty) rethrow;
    }

    return videos;
  }

  Future<List<WaleedVideo>> loadForYouFeed({
    List<WaleedVideo> recent = const <WaleedVideo>[],
    String categoryId = 'all',
    int limit = 24,
  }) async {
    final output = <WaleedVideo>[];
    final seen = <String>{};

    if (categoryId == 'all' && recent.isNotEmpty) {
      for (final seed in recent.take(2)) {
        seen.add(seed.id);
        try {
          final related = await loadRelatedVideos(seed.id, limit: 10);
          for (final v in related) {
            if (seen.add(v.id)) {
              output.add(v);
              if (output.length >= limit) return output;
            }
          }
        } catch (_) {}
      }
    }

    final category = categories.firstWhere(
      (c) => c.id == categoryId,
      orElse: () => categories.first,
    );

    try {
      final searched = await searchVideos(
        category.query,
        limit: limit,
        captionsOnly: true,
      );
      for (final v in searched) {
        if (seen.add(v.id)) {
          output.add(v);
          if (output.length >= limit) break;
        }
      }
    } catch (_) {}

    if (output.isEmpty) {
      return _curatedFallbackVideos;
    }
    return output;
  }

  Future<WaleedVideo> fetchVideoDetails(
    String videoId, {
    WaleedVideo? fallback,
  }) async {
    // 1. Try InnerTube player details first (fast)
    try {
      final resp = await _http
          .post(
            Uri.parse('https://www.youtube.com/youtubei/v1/player?prettyPrint=false'),
            headers: const {
              'Content-Type': 'application/json',
              'User-Agent':
                  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            },
            body: jsonEncode({
              'videoId': videoId,
              'context': {
                'client': {
                  'clientName': 'WEB',
                  'clientVersion': '2.20250201.00.00',
                  'hl': 'ar',
                  'gl': 'US',
                },
              },
            }),
          )
          .timeout(const Duration(seconds: 8));

      if (resp.statusCode == 200) {
        final dynamic data = jsonDecode(utf8.decode(resp.bodyBytes));
        if (data is Map && data['videoDetails'] is Map) {
          final vd = data['videoDetails'] as Map;
          final title = vd['title']?.toString().trim() ?? fallback?.title ?? '';
          final author = vd['author']?.toString().trim() ?? fallback?.channel ?? '';
          final desc = vd['shortDescription']?.toString() ?? fallback?.description ?? '';
          final lenSec = int.tryParse(vd['lengthSeconds']?.toString() ?? '');
          final views = int.tryParse(vd['viewCount']?.toString() ?? '');
          DateTime? pubDate = fallback?.publishedAt;
          if (data['microformat'] is Map &&
              data['microformat']['playerMicroformatRenderer'] is Map) {
            final mf = data['microformat']['playerMicroformatRenderer'] as Map;
            final rawDate = mf['publishDate']?.toString();
            if (rawDate != null) {
              pubDate = DateTime.tryParse(rawDate);
            }
          }
          if (title.isNotEmpty) {
            return WaleedVideo(
              id: videoId,
              title: title,
              channel: author,
              thumbnailUrl: 'https://i.ytimg.com/vi/$videoId/hqdefault.jpg',
              duration: lenSec != null && lenSec > 0 ? Duration(seconds: lenSec) : fallback?.duration,
              viewCount: views ?? fallback?.viewCount,
              publishedAt: pubDate,
              description: desc,
              progress: fallback?.progress ?? 0,
              lastPositionMs: fallback?.lastPositionMs ?? 0,
            );
          }
        }
      }
    } catch (_) {}

    // 2. Fallback to youtube_explode_dart
    try {
      final v = await _youtube.videos.get(videoId).timeout(const Duration(seconds: 10));
      return WaleedVideo(
        id: videoId,
        title: v.title,
        channel: v.author,
        thumbnailUrl: _thumbnailUrl(v.thumbnails, videoId),
        duration: v.duration,
        viewCount: v.engagement.viewCount,
        publishedAt: v.publishDate,
        description: v.description,
        progress: fallback?.progress ?? 0,
        lastPositionMs: fallback?.lastPositionMs ?? 0,
      );
    } catch (_) {
      return fallback ??
          WaleedVideo(
            id: videoId,
            title: 'فيديو YouTube ($videoId)',
            channel: 'YouTube',
            thumbnailUrl: 'https://i.ytimg.com/vi/$videoId/hqdefault.jpg',
          );
    }
  }

  Future<List<WaleedVideo>> loadRelatedVideos(
    String videoId, {
    int limit = 12,
  }) async {
    final output = <WaleedVideo>[];
    final seen = <String>{videoId};

    // 1. Try InnerTube /youtubei/v1/next for related videos
    try {
      final resp = await _http
          .post(
            Uri.parse('https://www.youtube.com/youtubei/v1/next?prettyPrint=false'),
            headers: const {
              'Content-Type': 'application/json',
              'User-Agent':
                  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            },
            body: jsonEncode({
              'videoId': videoId,
              'context': {
                'client': {
                  'clientName': 'WEB',
                  'clientVersion': '2.20250201.00.00',
                  'hl': 'ar',
                  'gl': 'US',
                },
              },
            }),
          )
          .timeout(const Duration(seconds: 8));
      if (resp.statusCode == 200) {
        final dynamic data = jsonDecode(utf8.decode(resp.bodyBytes));
        final parsed = _extractVideosFromInnerTubeTree(data, seen: seen, limit: limit);
        if (parsed.isNotEmpty) return parsed;
      }
    } catch (_) {}

    // 2. Fallback to youtube_explode_dart related videos
    try {
      final current = await _youtube.videos.get(videoId).timeout(const Duration(seconds: 8));
      final related = await _youtube.videos
          .getRelatedVideos(current)
          .timeout(const Duration(seconds: 8));
      if (related != null) {
        for (final dynamic item in related) {
          try {
            final id = item.id.value as String;
            final title = (item.title as String?)?.trim() ?? '';
            if (id.isEmpty || title.isEmpty || !seen.add(id)) continue;
            output.add(
              WaleedVideo(
                id: id,
                title: title,
                channel: (item.author as String?)?.trim() ?? '',
                thumbnailUrl: _thumbnailUrl(item.thumbnails, id),
                duration: item.duration as Duration?,
              ),
            );
            if (output.length >= limit) break;
          } catch (_) {}
        }
      }
    } catch (_) {}

    return output;
  }

  Future<List<WaleedVideo>> _innerTubeSearch(
    String query, {
    required int limit,
    required bool captionsOnly,
  }) async {
    final body = <String, Object?>{
      'query': query,
      'context': {
        'client': {
          'clientName': 'WEB',
          'clientVersion': '2.20250201.00.00',
          'hl': 'ar',
          'gl': 'US',
        },
      },
    };
    if (captionsOnly) {
      // YouTube search filter protobuf parameter for "Subtitles/CC"
      body['params'] = 'EgIoAQ%3D%3D';
    }

    final resp = await _http
        .post(
          Uri.parse('https://www.youtube.com/youtubei/v1/search?prettyPrint=false'),
          headers: const {
            'Content-Type': 'application/json',
            'User-Agent':
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          },
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 10));

    if (resp.statusCode != 200) return const [];
    final dynamic data = jsonDecode(utf8.decode(resp.bodyBytes));
    return _extractVideosFromInnerTubeTree(data, seen: <String>{}, limit: limit);
  }

  List<WaleedVideo> _extractVideosFromInnerTubeTree(
    dynamic root, {
    required Set<String> seen,
    required int limit,
  }) {
    final results = <WaleedVideo>[];

    void walk(dynamic node) {
      if (results.length >= limit || node == null) return;
      if (node is Map) {
        final renderer = node['videoRenderer'] ??
            node['compactVideoRenderer'] ??
            node['gridVideoRenderer'];
        if (renderer is Map) {
          final video = _parseVideoRenderer(renderer);
          if (video != null && seen.add(video.id)) {
            results.add(video);
            if (results.length >= limit) return;
          }
        }
        for (final value in node.values) {
          walk(value);
          if (results.length >= limit) return;
        }
      } else if (node is List) {
        for (final item in node) {
          walk(item);
          if (results.length >= limit) return;
        }
      }
    }

    walk(root);
    return results;
  }

  WaleedVideo? _parseVideoRenderer(Map<dynamic, dynamic> r) {
    final id = r['videoId']?.toString() ?? '';
    if (id.isEmpty) return null;

    final title = _extractText(r['title']);
    if (title.isEmpty) return null;

    var channel = _extractText(r['ownerText']);
    if (channel.isEmpty) channel = _extractText(r['longBylineText']);
    if (channel.isEmpty) channel = _extractText(r['shortBylineText']);

    final lengthStr = _extractText(r['lengthText']);
    final duration = _parseDurationText(lengthStr);

    return WaleedVideo(
      id: id,
      title: title,
      channel: channel,
      thumbnailUrl: 'https://i.ytimg.com/vi/$id/hqdefault.jpg',
      duration: duration,
    );
  }

  String _extractText(dynamic obj) {
    if (obj == null) return '';
    if (obj is String) return obj;
    if (obj is Map) {
      if (obj['simpleText'] != null) return obj['simpleText'].toString().trim();
      final runs = obj['runs'];
      if (runs is List) {
        return runs
            .map((e) => e is Map ? (e['text']?.toString() ?? '') : '')
            .join()
            .trim();
      }
    }
    return '';
  }

  Duration? _parseDurationText(String raw) {
    final cleaned = raw.trim();
    if (cleaned.isEmpty) return null;
    final parts = cleaned.split(':').map((e) => int.tryParse(e.trim())).toList();
    if (parts.any((e) => e == null)) return null;
    if (parts.length == 2) {
      return Duration(minutes: parts[0]!, seconds: parts[1]!);
    }
    if (parts.length == 3) {
      return Duration(hours: parts[0]!, minutes: parts[1]!, seconds: parts[2]!);
    }
    return null;
  }

  String _thumbnailUrl(dynamic thumbnails, String videoId) {
    try {
      final dynamic high = thumbnails.highResUrl;
      if (high is String && high.isNotEmpty) return high;
    } catch (_) {}
    try {
      final dynamic medium = thumbnails.mediumResUrl;
      if (medium is String && medium.isNotEmpty) return medium;
    } catch (_) {}
    return 'https://i.ytimg.com/vi/$videoId/hqdefault.jpg';
  }

  Future<void> close() async {
    if (_closed) return;
    _closed = true;
    _youtube.close();
    _http.close();
  }
}

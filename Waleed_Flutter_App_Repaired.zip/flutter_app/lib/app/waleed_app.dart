import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import '../data/app_settings.dart';
import 'app_shell.dart';

class WaleedApp extends StatelessWidget {
  const WaleedApp({super.key});

  static const Color background = Color(0xFF0E1017);
  static const Color surface = Color(0xFF181B24);
  static const Color accent = Color(0xFF7C6CFF);

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    final isDark = settings.darkMode;
    final brightness = isDark ? Brightness.dark : Brightness.light;

    return MaterialApp(
      title: 'وليد',
      debugShowCheckedModeBanner: false,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData(
        useMaterial3: true,
        brightness: brightness,
        scaffoldBackgroundColor: isDark ? background : const Color(0xFFF4F6FA),
        colorScheme: ColorScheme.fromSeed(
          seedColor: accent,
          brightness: brightness,
          surface: isDark ? surface : Colors.white,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: isDark ? background : Colors.white,
          foregroundColor: isDark ? Colors.white : Colors.black87,
          centerTitle: false,
          elevation: 0,
          scrolledUnderElevation: 0,
        ),
        cardTheme: CardThemeData(
          color: isDark ? surface : Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: isDark ? const Color(0xFF141720) : Colors.white,
          indicatorColor: accent.withValues(alpha: 0.22),
        ),
      ),
      home: const AppShell(),
    );
  }
}

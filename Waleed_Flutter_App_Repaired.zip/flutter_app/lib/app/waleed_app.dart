import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/app_settings.dart';

import 'app_shell.dart';

class WaleedApp extends StatelessWidget {
  const WaleedApp({super.key});

  static const Color background = Color(0xFF101116);
  static const Color surface = Color(0xFF1A1C23);
  static const Color accent = Color(0xFF8B7CFF);

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    final brightness = settings.darkMode ? Brightness.dark : Brightness.light;
    return MaterialApp(
      title: 'وليد',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: brightness,
        scaffoldBackgroundColor: settings.darkMode
            ? background
            : const Color(0xFFF5F5F8),
        colorScheme: ColorScheme.fromSeed(
          seedColor: accent,
          brightness: brightness,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: settings.darkMode ? background : Colors.white,
          foregroundColor: settings.darkMode ? Colors.white : Colors.black87,
          centerTitle: false,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          color: settings.darkMode ? surface : Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
      themeMode: settings.darkMode ? ThemeMode.dark : ThemeMode.light,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      home: const AppShell(),
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../data/app_settings.dart';

import '../screens/bookmarks/bookmarks_screen.dart';
import '../screens/videos/videos_screen.dart';
import '../screens/youtube/youtube_tab.dart';
import '../screens/player/player_screen.dart';
import '../models/waleed_video.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  static const MethodChannel _shareMethods = MethodChannel(
    'com.waleed.video/share_intents',
  );
  static const EventChannel _shareEvents = EventChannel(
    'com.waleed.video/share_events',
  );

  StreamSubscription<dynamic>? _sharedTextSubscription;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _sharedTextSubscription = _shareEvents.receiveBroadcastStream().listen(
      (event) => _openSharedVideo(event?.toString()),
      onError: (_) {},
    );
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        final shared = await _shareMethods.invokeMethod<String>(
          'getInitialSharedText',
        );
        if (mounted) _openSharedVideo(shared);
      } on PlatformException {
        // A normal launcher start has no shared payload.
      } on MissingPluginException {
        // Allows the Dart UI to run in tests and non-Android previews.
      }
    });
  }

  String? _extractYouTubeId(String raw) {
    final match = RegExp(
      r'(?:https?://)?(?:www\.|m\.)?(?:youtube\.com/(?:watch\?(?:[^#\s]*&)?v=|shorts/|live/|embed/)|youtu\.be/)([A-Za-z0-9_-]{11})',
      caseSensitive: false,
    ).firstMatch(raw);
    if (match != null) return match.group(1);

    final uri = Uri.tryParse(raw.trim());
    if (uri == null) return null;
    if (uri.host == 'youtu.be' && uri.pathSegments.isNotEmpty) {
      return uri.pathSegments.first;
    }
    if (uri.host.endsWith('youtube.com')) {
      final queryId = uri.queryParameters['v'];
      if (queryId != null && RegExp(r'^[A-Za-z0-9_-]{11}$').hasMatch(queryId)) {
        return queryId;
      }
      final segments = uri.pathSegments;
      for (final marker in ['shorts', 'live', 'embed']) {
        final index = segments.indexOf(marker);
        if (index >= 0 && index + 1 < segments.length) {
          return segments[index + 1];
        }
      }
    }
    return null;
  }

  void _openSharedVideo(String? raw) {
    if (!mounted || raw == null || raw.trim().isEmpty) return;
    final id = _extractYouTubeId(raw);
    if (id == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('الرابط المشارك ليس رابط فيديو YouTube معروفاً.'),
        ),
      );
      return;
    }
    final video = WaleedVideo(
      id: id,
      title: 'فيديو من YouTube',
      channel: '',
      thumbnailUrl: 'https://i.ytimg.com/vi/$id/hqdefault.jpg',
    );
    Navigator.of(
      context,
    ).push(MaterialPageRoute<void>(builder: (_) => PlayerScreen(video: video)));
  }

  @override
  void dispose() {
    _sharedTextSubscription?.cancel();
    super.dispose();
  }

  void _openSettings() {
    Navigator.of(context)
        .push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const VideosScreen(),
      const YoutubeTab(),
      const BookmarksScreen(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'وليد',
          style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .2),
        ),
        actions: [
          IconButton(
            tooltip: 'الإعدادات',
            onPressed: _openSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      drawer: _WaleedDrawer(onSettings: _openSettings),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.video_library_outlined),
            selectedIcon: Icon(Icons.video_library),
            label: 'الفيديوهات',
          ),
          NavigationDestination(
            icon: Icon(Icons.smart_display_outlined),
            selectedIcon: Icon(Icons.smart_display),
            label: 'YouTube',
          ),
          NavigationDestination(
            icon: Icon(Icons.bookmarks_outlined),
            selectedIcon: Icon(Icons.bookmarks),
            label: 'الإشارات المرجعية',
          ),
        ],
      ),
    );
  }
}

class _WaleedDrawer extends StatelessWidget {
  const _WaleedDrawer({required this.onSettings});

  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 24),
            const CircleAvatar(
              radius: 34,
              backgroundColor: Color(0xFF8B7CFF),
              child: Text(
                'و',
                style: TextStyle(fontSize: 38, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'وليد',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.workspace_premium_outlined),
              title: const Text('Premium'),
              onTap: () => _showNotice(
                context,
                'معلومات الاشتراك ستتوفر بعد تنفيذ نظام المشتريات.',
              ),
            ),
            ListTile(
              leading: const Icon(Icons.restore),
              title: const Text('استعادة المشتريات'),
              onTap: () =>
                  _showNotice(context, 'لم تتم إضافة نظام مشتريات بعد.'),
            ),
            Consumer<AppSettings>(
              builder: (context, settings, _) => SwitchListTile(
                secondary: const Icon(Icons.dark_mode_outlined),
                title: const Text('الوضع الداكن'),
                value: settings.darkMode,
                onChanged: settings.setDarkMode,
              ),
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined),
              title: const Text('الإعدادات'),
              onTap: () {
                Navigator.pop(context);
                onSettings();
              },
            ),
            ListTile(
              leading: const Icon(Icons.share_outlined),
              title: const Text('مشاركة التطبيق'),
              onTap: () {
                Navigator.pop(context);
                SharePlus.instance.share(
                  ShareParams(
                    text: 'جرّب تطبيق وليد لترجمة الفيديوهات ومتابعة النصوص أثناء التشغيل.',
                  ),
                );
              },
            ),
            const Spacer(),
            const ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('حول وليد'),
              subtitle: Text('مشغل وترجمة فيديوهات — إصدار تجريبي'),
            ),
          ],
        ),
      ),
    );
  }

  void _showNotice(BuildContext context, String message) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        children: [
          const ListTile(title: Text('لغة الواجهة'), subtitle: Text('العربية')),
          SwitchListTile(
            title: const Text('تدوير المشغل تلقائياً'),
            value: settings.autoRotate,
            onChanged: settings.setAutoRotate,
          ),
          SwitchListTile(
            title: const Text('ترجمة عناوين الفيديو في شاشة البحث'),
            value: settings.translateTitles,
            onChanged: settings.setTranslateTitles,
          ),
          SwitchListTile(
            title: const Text('تشغيل الفيديو التالي تلقائياً'),
            value: settings.autoNext,
            onChanged: settings.setAutoNext,
          ),
          SwitchListTile(
            title: const Text('الوضع الداكن'),
            value: settings.darkMode,
            onChanged: settings.setDarkMode,
          ),
        ],
      ),
    );
  }
}

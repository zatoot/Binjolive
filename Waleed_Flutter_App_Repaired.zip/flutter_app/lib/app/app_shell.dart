import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../data/app_settings.dart';
import '../data/local_store.dart';
import '../models/waleed_video.dart';
import '../screens/bookmarks/bookmarks_screen.dart';
import '../screens/player/player_screen.dart';
import '../screens/search/video_search_screen.dart';
import '../screens/videos/videos_screen.dart';
import '../screens/youtube/youtube_tab.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  static const MethodChannel _shareMethods = MethodChannel(
    'com.waleed.video/share_intents',
  );
  static const EventChannel _shareEvents = EventChannel(
    'com.waleed.video/share_events',
  );

  StreamSubscription<dynamic>? _sharedTextSubscription;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _sharedTextSubscription = _shareEvents.receiveBroadcastStream().listen(
      (event) => _openSharedVideo(event?.toString()),
      onError: (_) {},
    );
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        final shared = await _shareMethods.invokeMethod<String>(
          'getInitialSharedText',
        );
        if (mounted) _openSharedVideo(shared);
      } on PlatformException {
        // Normal launcher start
      } on MissingPluginException {
        // Non-Android test environment
      }
    });
  }

  void _openSharedVideo(String? raw) {
    if (!mounted || raw == null || raw.trim().isEmpty) return;
    final id = WaleedVideo.tryExtractVideoId(raw);
    if (id == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('الرابط المشارك ليس رابط فيديو YouTube صالحاً.'),
        ),
      );
      return;
    }
    final video = WaleedVideo(
      id: id,
      title: 'فيديو من YouTube',
      channel: 'YouTube',
      thumbnailUrl: 'https://i.ytimg.com/vi/$id/hqdefault.jpg',
    );
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => PlayerScreen(video: video)),
    );
  }

  Future<void> _promptPasteUrl() async {
    final controller = TextEditingController();
    try {
      final clip = await Clipboard.getData(Clipboard.kTextPlain);
      final clipText = clip?.text?.trim() ?? '';
      if (WaleedVideo.tryExtractVideoId(clipText) != null) {
        controller.text = clipText;
      }
    } catch (_) {}

    if (!mounted) {
      controller.dispose();
      return;
    }

    final submitted = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('فتح رابط فيديو YouTube'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(
            hintText: 'https://youtu.be/... أو معرّف الفيديو',
            prefixIcon: const Icon(Icons.link),
            suffixIcon: IconButton(
              tooltip: 'لصق من الحافظة',
              icon: const Icon(Icons.content_paste),
              onPressed: () async {
                final data = await Clipboard.getData(Clipboard.kTextPlain);
                if (data?.text != null) {
                  controller.text = data!.text!.trim();
                }
              },
            ),
          ),
          onSubmitted: (val) => Navigator.pop(dialogContext, val),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(dialogContext, controller.text),
            icon: const Icon(Icons.play_arrow),
            label: const Text('تشغيل وترجمة'),
          ),
        ],
      ),
    );
    controller.dispose();

    if (submitted != null && submitted.trim().isNotEmpty) {
      _openSharedVideo(submitted);
    }
  }

  @override
  void dispose() {
    _sharedTextSubscription?.cancel();
    super.dispose();
  }

  void _openSettings() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      VideosScreen(onPasteLink: _promptPasteUrl),
      const YoutubeTab(),
      const BookmarksScreen(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF8B7CFF), Color(0xFF5B4BFF)],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              alignment: Alignment.center,
              child: const Icon(
                Icons.translate_rounded,
                color: Colors.white,
                size: 19,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'وليد',
              style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .2),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'لصق رابط YouTube',
            onPressed: _promptPasteUrl,
            icon: const Icon(Icons.add_link_rounded),
          ),
          IconButton(
            tooltip: 'بحث عن فيديو',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const VideoSearchScreen(),
              ),
            ),
            icon: const Icon(Icons.search_rounded),
          ),
          IconButton(
            tooltip: 'الإعدادات',
            onPressed: _openSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      drawer: _WaleedDrawer(
        onSettings: _openSettings,
        onPasteLink: _promptPasteUrl,
      ),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.video_library_outlined),
            selectedIcon: Icon(Icons.video_library),
            label: 'الفيديوهات',
          ),
          NavigationDestination(
            icon: Icon(Icons.smart_display_outlined),
            selectedIcon: Icon(Icons.smart_display),
            label: 'YouTube',
          ),
          NavigationDestination(
            icon: Icon(Icons.bookmarks_outlined),
            selectedIcon: Icon(Icons.bookmarks),
            label: 'الإشارات المرجعية',
          ),
        ],
      ),
    );
  }
}

class _WaleedDrawer extends StatelessWidget {
  const _WaleedDrawer({
    required this.onSettings,
    required this.onPasteLink,
  });

  final VoidCallback onSettings;
  final VoidCallback onPasteLink;

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF7C6CFF).withValues(alpha: 0.25),
                    Colors.transparent,
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const CircleAvatar(
                    radius: 30,
                    backgroundColor: Color(0xFF7C6CFF),
                    child: Text(
                      'و',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'تطبيق وليد',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF2E7D32).withValues(alpha: 0.22),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFF66BB6A).withValues(alpha: 0.5),
                      ),
                    ),
                    child: const Text(
                      'نسخة كاملة مجانية • بدون إعلانات',
                      style: TextStyle(
                        fontSize: 11.5,
                        color: Color(0xFF81C784),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.add_link_rounded),
              title: const Text('فتح رابط YouTube مباشر'),
              onTap: () {
                Navigator.pop(context);
                onPasteLink();
              },
            ),
            ListTile(
              leading: const Icon(Icons.translate_rounded),
              title: const Text('لغة الترجمة الافتراضية'),
              subtitle: Text(
                AppSettings.languageLabel(settings.targetLanguageCode),
              ),
              onTap: () {
                Navigator.pop(context);
                onSettings();
              },
            ),
            SwitchListTile(
              secondary: const Icon(Icons.record_voice_over_outlined),
              title: const Text('التعليق الصوتي التلقائي'),
              value: settings.voiceOverEnabled,
              onChanged: settings.setVoiceOverEnabled,
            ),
            SwitchListTile(
              secondary: const Icon(Icons.dark_mode_outlined),
              title: const Text('الوضع الداكن'),
              value: settings.darkMode,
              onChanged: settings.setDarkMode,
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined),
              title: const Text('جميع الإعدادات'),
              onTap: () {
                Navigator.pop(context);
                onSettings();
              },
            ),
            ListTile(
              leading: const Icon(Icons.share_outlined),
              title: const Text('مشاركة التطبيق'),
              onTap: () {
                Navigator.pop(context);
                SharePlus.instance.share(
                  ShareParams(
                    text:
                        'جرّب تطبيق وليد لترجمة فيديوهات YouTube ومتابعة النصوص والتعليق الصوتي الفوري بدون إعلانات.',
                  ),
                );
              },
            ),
            const Spacer(),
            const Divider(height: 1),
            const ListTile(
              leading: Icon(Icons.verified_outlined, color: Color(0xFF8B7CFF)),
              title: Text('حول تطبيق وليد'),
              subtitle: Text('الإصدار 0.3.0 • مشغل ومترجم فيديو ودبلجة صوتية'),
            ),
          ],
        ),
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          const _SectionHeader(title: 'الترجمة واللغات'),
          ListTile(
            leading: const Icon(Icons.language_rounded),
            title: const Text('نطق / ترجمة الفيديوهات إلى'),
            subtitle: Text(
              AppSettings.languageLabel(settings.targetLanguageCode),
            ),
            trailing: DropdownButton<String>(
              value: settings.targetLanguageCode,
              underline: const SizedBox.shrink(),
              items: AppSettings.supportedLanguages
                  .map(
                    (lang) => DropdownMenuItem<String>(
                      value: lang.code,
                      child: Text(lang.arabicName),
                    ),
                  )
                  .toList(),
              onChanged: (val) {
                if (val != null) settings.setTargetLanguageCode(val);
              },
            ),
          ),
          SwitchListTile(
            secondary: const Icon(Icons.subtitles_outlined),
            title: const Text('إظهار النص الأصلي للفيديو'),
            value: settings.showOriginalCaptions,
            onChanged: settings.setShowOriginalCaptions,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.closed_caption_outlined),
            title: const Text('إظهار النص المترجم'),
            value: settings.showTranslatedCaptions,
            onChanged: settings.setShowTranslatedCaptions,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.picture_in_picture_alt_outlined),
            title: const Text('إظهار الترجمة فوق شاشة الفيديو'),
            value: settings.showOverlayCaptions,
            onChanged: settings.setShowOverlayCaptions,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'حجم الخط الأساسي: ${settings.primaryFontSize.round()}',
                ),
                Slider(
                  min: 12,
                  max: 26,
                  divisions: 14,
                  value: settings.primaryFontSize,
                  onChanged: settings.setPrimaryFontSize,
                ),
                Text(
                  'حجم خط الترجمة: ${settings.translationFontSize.round()}',
                ),
                Slider(
                  min: 12,
                  max: 26,
                  divisions: 14,
                  value: settings.translationFontSize,
                  onChanged: settings.setTranslationFontSize,
                ),
              ],
            ),
          ),
          const Divider(),
          const _SectionHeader(title: 'المشغّل والبحث'),
          SwitchListTile(
            secondary: const Icon(Icons.screen_rotation_outlined),
            title: const Text('تدوير المشغل تلقائياً'),
            value: settings.autoRotate,
            onChanged: settings.setAutoRotate,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.translate),
            title: const Text('ترجمة عناوين الفيديو في شاشة البحث'),
            value: settings.translateTitles,
            onChanged: settings.setTranslateTitles,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.skip_next_outlined),
            title: const Text('تشغيل الفيديو التالي تلقائياً'),
            value: settings.autoNext,
            onChanged: settings.setAutoNext,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.dark_mode_outlined),
            title: const Text('الوضع الداكن'),
            value: settings.darkMode,
            onChanged: settings.setDarkMode,
          ),
          const Divider(),
          const _SectionHeader(title: 'البيانات والسجل'),
          ListTile(
            leading: const Icon(Icons.delete_sweep_outlined, color: Colors.redAccent),
            title: const Text('مسح سجل المشاهدة الأخيرة'),
            onTap: () async {
              await context.read<LocalStore>().clearAllRecent();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('تم مسح سجل المشاهدة.')),
                );
              }
            },
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
      child: Text(
        title,
        style: const TextStyle(
          color: Color(0xFF8B7CFF),
          fontWeight: FontWeight.bold,
          fontSize: 13.5,
        ),
      ),
    );
  }
}

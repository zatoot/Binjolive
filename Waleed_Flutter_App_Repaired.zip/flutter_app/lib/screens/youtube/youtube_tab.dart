import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../models/waleed_video.dart';
import '../player/player_screen.dart';

class YoutubeTab extends StatefulWidget {
  const YoutubeTab({super.key});

  @override
  State<YoutubeTab> createState() => _YoutubeTabState();
}

class _YoutubeTabState extends State<YoutubeTab>
    with AutomaticKeepAliveClientMixin {
  late final WebViewController _controller;
  bool _loading = true;
  bool _canGoBack = false;
  bool _canGoForward = false;
  String? _error;
  DateTime _lastOpenedTime = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  bool get wantKeepAlive => true;

  static const String _youtubeInterceptScript = r'''
(function() {
  if (window.__waleedYoutubeHookInstalled) return;
  window.__waleedYoutubeHookInstalled = true;

  function extractId(url) {
    if (!url) return null;
    var patterns = [
      /[?&]v=([A-Za-z0-9_-]{11})/,
      /youtu\.be\/([A-Za-z0-9_-]{11})/,
      /\/watch\/([A-Za-z0-9_-]{11})/,
      /\/shorts\/([A-Za-z0-9_-]{11})/,
      /\/embed\/([A-Za-z0-9_-]{11})/
    ];
    for (var i = 0; i < patterns.length; i++) {
      var m = url.match(patterns[i]);
      if (m && m[1]) return m[1];
    }
    return null;
  }

  function sendToWaleed(url) {
    var id = extractId(url);
    if (id && window.OpenVideo && typeof window.OpenVideo.postMessage === 'function') {
      window.OpenVideo.postMessage('https://www.youtube.com/watch?v=' + id);
      return true;
    }
    return false;
  }

  document.addEventListener('click', function(e) {
    var el = e.target;
    while (el && el !== document.body) {
      if (el.tagName === 'A' && el.href) {
        if (extractId(el.href)) {
          e.preventDefault();
          e.stopPropagation();
          sendToWaleed(el.href);
          return false;
        }
      }
      el = el.parentElement;
    }
  }, true);

  var origPushState = history.pushState;
  history.pushState = function(state, title, url) {
    if (url && extractId(url.toString())) {
      sendToWaleed(url.toString());
      return;
    }
    return origPushState.apply(this, arguments);
  };

  var origReplaceState = history.replaceState;
  history.replaceState = function(state, title, url) {
    if (url && extractId(url.toString())) {
      sendToWaleed(url.toString());
      return;
    }
    return origReplaceState.apply(this, arguments);
  };
})();
''';

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0E1017))
      ..addJavaScriptChannel(
        'OpenVideo',
        onMessageReceived: (message) {
          _openVideoByUrl(message.message);
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (mounted) {
              setState(() {
                _loading = true;
                _error = null;
              });
            }
          },
          onPageFinished: (_) async {
            if (mounted) setState(() => _loading = false);
            await _injectInterceptScript();
            await _updateNavigationState();
          },
          onUrlChange: (change) {
            final url = change.url;
            if (url != null && WaleedVideo.tryExtractVideoId(url) != null) {
              _openVideoByUrl(url);
            }
          },
          onWebResourceError: (error) {
            if (error.isForMainFrame == true && mounted) {
              setState(() {
                _loading = false;
                _error = error.description;
              });
            }
          },
          onNavigationRequest: (request) {
            final id = WaleedVideo.tryExtractVideoId(request.url);
            if (id != null) {
              _openVideoById(id);
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse('https://m.youtube.com'));
  }

  Future<void> _injectInterceptScript() async {
    try {
      await _controller.runJavaScript(_youtubeInterceptScript);
    } catch (_) {}
  }

  void _openVideoByUrl(String rawUrl) {
    final id = WaleedVideo.tryExtractVideoId(rawUrl);
    if (id != null) {
      _openVideoById(id);
    }
  }

  void _openVideoById(String id) {
    if (!mounted) return;
    final now = DateTime.now();
    if (now.difference(_lastOpenedTime).inMilliseconds < 900) return;
    _lastOpenedTime = now;

    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => PlayerScreen(
          video: WaleedVideo(
            id: id,
            title: 'فيديو من YouTube',
            channel: 'YouTube',
            thumbnailUrl: 'https://i.ytimg.com/vi/$id/hqdefault.jpg',
          ),
        ),
      ),
    );
  }

  Future<void> _reload() => _controller.reload();

  Future<void> _updateNavigationState() async {
    try {
      final back = await _controller.canGoBack();
      final forward = await _controller.canGoForward();
      if (!mounted) return;
      setState(() {
        _canGoBack = back;
        _canGoForward = forward;
      });
    } catch (_) {}
  }

  Future<void> _goHome() =>
      _controller.loadRequest(Uri.parse('https://m.youtube.com'));

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          color: const Color(0xFF7C6CFF).withValues(alpha: 0.14),
          child: const Row(
            children: [
              Icon(Icons.touch_app_outlined, size: 17, color: Color(0xFF9E92FF)),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'اضغط على أي فيديو داخل YouTube لفتحه وترجمته فوراً داخل مشغّل وليد',
                  style: TextStyle(fontSize: 12),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: Stack(
            children: [
              WebViewWidget(controller: _controller),
              if (_loading)
                const Align(
                  alignment: Alignment.topCenter,
                  child: LinearProgressIndicator(minHeight: 2.5),
                ),
              if (_error != null)
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.wifi_off,
                          size: 42,
                          color: Colors.white54,
                        ),
                        const SizedBox(height: 12),
                        const Text('تعذر تحميل YouTube داخل التطبيق.'),
                        const SizedBox(height: 6),
                        Text(
                          _error!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white54),
                        ),
                        const SizedBox(height: 12),
                        FilledButton.tonal(
                          onPressed: _reload,
                          child: const Text('إعادة المحاولة'),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
        Material(
          color: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF181B24)
              : Colors.grey.shade100,
          child: SafeArea(
            top: false,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  tooltip: 'رجوع',
                  onPressed: _canGoBack
                      ? () async {
                          await _controller.goBack();
                          _updateNavigationState();
                        }
                      : null,
                  icon: const Icon(Icons.arrow_back),
                ),
                IconButton(
                  tooltip: 'تقدم',
                  onPressed: _canGoForward
                      ? () async {
                          await _controller.goForward();
                          _updateNavigationState();
                        }
                      : null,
                  icon: const Icon(Icons.arrow_forward),
                ),
                IconButton(
                  tooltip: 'الرئيسية',
                  onPressed: _goHome,
                  icon: const Icon(Icons.home_outlined),
                ),
                IconButton(
                  tooltip: 'تحديث',
                  onPressed: _reload,
                  icon: const Icon(Icons.refresh),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

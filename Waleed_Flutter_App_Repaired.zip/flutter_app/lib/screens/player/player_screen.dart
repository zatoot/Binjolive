import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../data/app_settings.dart';
import '../../data/local_store.dart';
import '../../models/waleed_video.dart';
import '../../services/caption_service.dart';
import '../../services/youtube_catalog_service.dart';
import '../../widgets/video_list_tile.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({
    required this.video,
    this.initialPosition = Duration.zero,
    super.key,
  });

  final WaleedVideo video;
  final Duration initialPosition;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen>
    with SingleTickerProviderStateMixin {
  late final WebViewController _webController;
  late final TabController _tabController;
  final ScrollController _transcriptScroll = ScrollController();
  final FlutterTts _tts = FlutterTts();

  late WaleedVideo _video;
  bool _playerReady = false;
  bool _isPlaying = false;
  bool _repeatVideo = false;
  double _playbackRate = 1.0;
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = Duration.zero;
  bool _autoNextTriggered = false;

  List<CaptionTrackOption> _availableTracks = [];
  CaptionTrackOption? _selectedTrack;
  List<WaleedCaptionLine> _captions = [];
  final Map<int, String> _translated = {};
  final Set<int> _translationPending = {};
  int _translationGeneration = 0;
  bool _loadingCaptions = true;
  String? _captionsError;

  int _activeCaption = -1;
  bool _autoScrollTranscript = true;
  String _transcriptFilter = '';
  bool _showTranscriptSearch = false;
  final TextEditingController _transcriptSearchCtrl = TextEditingController();

  bool _ttsReady = false;
  bool _ttsSpeaking = false;
  bool _pausedForTtsTail = false;
  int _lastSpokenCaptionIndex = -1;
  List<Map<String, String>> _targetVoices = [];
  DateTime _lastProgressSave = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _lastUserScrollTime = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _video = widget.video;
    _totalDuration = widget.video.duration ?? Duration.zero;
    _tabController = TabController(length: 3, vsync: this);
    _initWebViewPlayer();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final settings = context.read<AppSettings>();
      final store = context.read<LocalStore>();
      await _applyOrientation(settings.autoRotate);
      if (!mounted) return;
      await _initializeAudio(settings);
      if (!mounted) return;
      unawaited(store.saveRecent(_video));
      unawaited(_refreshVideoMetadata());
      unawaited(_autoLoadCaptionsAndTranslate());
    });
  }

  Future<void> _applyOrientation(bool autoRotate) async {
    await SystemChrome.setPreferredOrientations(
      autoRotate
          ? const [
              DeviceOrientation.portraitUp,
              DeviceOrientation.portraitDown,
              DeviceOrientation.landscapeLeft,
              DeviceOrientation.landscapeRight,
            ]
          : const [DeviceOrientation.portraitUp],
    );
  }

  void _initWebViewPlayer() {
    final startSeconds = (widget.initialPosition.inMilliseconds / 1000.0).round();
    final html = '''
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <style>
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      background-color: #000;
      overflow: hidden;
    }
    #player {
      position: absolute;
      top: 0; left: 0; width: 100%; height: 100%;
    }
  </style>
</head>
<body>
  <div id="player"></div>
  <script>
    var tag = document.createElement('script');
    tag.src = "https://www.youtube.com/iframe_api";
    var firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

    var player;
    var pollTimer;

    function sendEvent(payload) {
      if (window.WaleedPlayer && window.WaleedPlayer.postMessage) {
        window.WaleedPlayer.postMessage(JSON.stringify(payload));
      }
    }

    function onYouTubeIframeAPIReady() {
      player = new YT.Player('player', {
        width: '100%',
        height: '100%',
        videoId: '${_video.id}',
        playerVars: {
          'autoplay': 1,
          'controls': 1,
          'playsinline': 1,
          'rel': 0,
          'iv_load_policy': 3,
          'cc_load_policy': 0,
          'hl': 'ar',
          'start': $startSeconds,
          'origin': 'https://www.youtube.com'
        },
        events: {
          'onReady': function(event) {
            sendEvent({
              type: 'ready',
              duration: player.getDuration ? player.getDuration() : 0
            });
            event.target.playVideo();
            startPolling();
          },
          'onStateChange': function(event) {
            sendEvent({
              type: 'state',
              state: event.data,
              currentTime: player.getCurrentTime ? player.getCurrentTime() : 0,
              duration: player.getDuration ? player.getDuration() : 0
            });
          },
          'onError': function(event) {
            sendEvent({
              type: 'error',
              code: event.data
            });
          }
        }
      });
    }

    function startPolling() {
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = setInterval(function() {
        if (player && typeof player.getCurrentTime === 'function') {
          sendEvent({
            type: 'tick',
            currentTime: player.getCurrentTime() || 0,
            duration: player.getDuration() || 0,
            state: player.getPlayerState ? player.getPlayerState() : -1
          });
        }
      }, 140);
    }
  </script>
</body>
</html>
''';

    _webController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..addJavaScriptChannel(
        'WaleedPlayer',
        onMessageReceived: (msg) => _onPlayerJsMessage(msg.message),
      )
      ..loadHtmlString(html, baseUrl: 'https://www.youtube.com');
  }

  void _onPlayerJsMessage(String rawJson) {
    if (!mounted) return;
    try {
      final dynamic data = jsonDecode(rawJson);
      if (data is! Map) return;
      final type = data['type']?.toString() ?? '';

      if (type == 'ready') {
        final durSec = (data['duration'] as num?)?.toDouble() ?? 0;
        setState(() {
          _playerReady = true;
          if (durSec > 0) {
            _totalDuration = Duration(milliseconds: (durSec * 1000).round());
          }
        });
      } else if (type == 'state') {
        final stateCode = (data['state'] as num?)?.toInt() ?? -1;
        final playing = stateCode == 1;
        if (_isPlaying != playing) {
          setState(() => _isPlaying = playing);
        }
        if (stateCode == 0) {
          if (_repeatVideo) {
            _seekTo(Duration.zero);
            _playVideo();
          } else {
            _handleVideoEnded();
          }
        }
      } else if (type == 'tick') {
        final sec = (data['currentTime'] as num?)?.toDouble() ?? 0.0;
        final durSec = (data['duration'] as num?)?.toDouble() ?? 0.0;
        final stateCode = (data['state'] as num?)?.toInt() ?? -1;
        final playing = stateCode == 1;
        if (durSec > 0) {
          _totalDuration = Duration(milliseconds: (durSec * 1000).round());
        }
        if (_isPlaying != playing) {
          setState(() => _isPlaying = playing);
        }
        _onPosition(Duration(milliseconds: (sec * 1000).round()));
      }
    } catch (_) {}
  }

  Future<void> _playVideo() async {
    try {
      await _webController.runJavaScript(
        'if(player && player.playVideo) player.playVideo();',
      );
    } catch (_) {}
  }

  Future<void> _pauseVideo() async {
    try {
      await _webController.runJavaScript(
        'if(player && player.pauseVideo) player.pauseVideo();',
      );
    } catch (_) {}
  }

  Future<void> _seekTo(Duration position) async {
    final sec = (position.inMilliseconds / 1000.0).clamp(0.0, 86400.0);
    setState(() => _currentPosition = position);
    try {
      await _webController.runJavaScript(
        'if(player && player.seekTo) player.seekTo($sec, true);',
      );
    } catch (_) {}
  }

  Future<void> _setPlayerVolume(int volumePercent) async {
    final vol = volumePercent.clamp(0, 100);
    try {
      await _webController.runJavaScript(
        'if(player && player.setVolume) { player.unMute(); player.setVolume($vol); }',
      );
    } catch (_) {}
  }

  Future<void> _mutePlayer() async {
    try {
      await _webController.runJavaScript(
        'if(player && player.mute) player.mute();',
      );
    } catch (_) {}
  }

  Future<void> _unMutePlayer() async {
    try {
      await _webController.runJavaScript(
        'if(player && player.unMute) player.unMute();',
      );
    } catch (_) {}
  }

  Future<void> _setPlaybackRate(double rate) async {
    setState(() => _playbackRate = rate);
    try {
      await _webController.runJavaScript(
        'if(player && player.setPlaybackRate) player.setPlaybackRate($rate);',
      );
    } catch (_) {}
  }

  Future<void> _refreshVideoMetadata() async {
    if (!mounted) return;
    final catalog = context.read<YoutubeCatalogService>();
    final store = context.read<LocalStore>();
    try {
      final detailed = await catalog.fetchVideoDetails(
        _video.id,
        fallback: _video,
      );
      if (!mounted) return;
      setState(() {
        _video = detailed;
        if (detailed.duration != null && _totalDuration == Duration.zero) {
          _totalDuration = detailed.duration!;
        }
      });
      await store.saveRecent(detailed);
    } catch (_) {}
  }

  Future<void> _autoLoadCaptionsAndTranslate() async {
    if (!mounted) return;
    final captionsService = context.read<CaptionService>();
    final targetLang = context.read<AppSettings>().targetLanguageCode;
    setState(() {
      _loadingCaptions = true;
      _captionsError = null;
    });
    try {
      final tracks = await captionsService.listTracks(_video.id);
      if (!mounted) return;
      _availableTracks = tracks;
      if (tracks.isEmpty) {
        setState(() {
          _loadingCaptions = false;
          _captionsError = 'هذا الفيديو لا يحتوي على ترجمة نصية متاحة من المصدر.';
        });
        return;
      }

      final chosen = captionsService.selectBestDefaultTrack(
        tracks,
        targetLanguageCode: targetLang,
      );
      if (chosen != null) {
        await _selectCaptionTrack(chosen);
      } else {
        setState(() => _loadingCaptions = false);
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loadingCaptions = false;
        _captionsError = 'تعذر جلب مسارات الترجمة. اضغط لإعادة المحاولة.';
      });
    }
  }

  Future<void> _selectCaptionTrack(CaptionTrackOption track) async {
    if (!mounted) return;
    final captionsService = context.read<CaptionService>();
    final generation = ++_translationGeneration;
    setState(() {
      _selectedTrack = track;
      _loadingCaptions = true;
      _captionsError = null;
      _captions = [];
      _translated.clear();
      _translationPending.clear();
      _activeCaption = -1;
      _lastSpokenCaptionIndex = -1;
    });

    try {
      final lines = await captionsService.loadTrack(track);
      if (!mounted || generation != _translationGeneration) return;
      setState(() {
        _captions = lines;
        _loadingCaptions = false;
      });
      unawaited(_prefetchAllTranslations(generation, startFromIndex: 0));
    } catch (_) {
      if (!mounted || generation != _translationGeneration) return;
      setState(() {
        _loadingCaptions = false;
        _captionsError = 'تعذر تحميل نصوص هذا المسار.';
      });
    }
  }

  Future<void> _prefetchAllTranslations(
    int generation, {
    required int startFromIndex,
  }) async {
    if (!mounted || _captions.isEmpty || _selectedTrack == null) return;
    final captionsService = context.read<CaptionService>();
    final targetCode = context.read<AppSettings>().targetLanguageCode;
    final sourceCode = _selectedTrack!.languageCode;

    final total = _captions.length;
    final orderedIndices = <int>[
      for (var i = startFromIndex.clamp(0, total - 1); i < total; i++) i,
      for (var i = 0; i < startFromIndex.clamp(0, total - 1); i++) i,
    ];

    const batchSize = 20;
    for (var i = 0; i < orderedIndices.length; i += batchSize) {
      if (!mounted || generation != _translationGeneration) return;
      final batchIndices = orderedIndices
          .sublist(i, (i + batchSize).clamp(0, orderedIndices.length))
          .where(
            (idx) =>
                !_translated.containsKey(idx) &&
                !_translationPending.contains(idx),
          )
          .toList();
      if (batchIndices.isEmpty) continue;

      setState(() => _translationPending.addAll(batchIndices));
      try {
        final batchResult = await captionsService.translateBatch(
          lines: _captions,
          indices: batchIndices,
          sourceCode: sourceCode,
          targetCode: targetCode,
        );
        if (!mounted || generation != _translationGeneration) return;
        setState(() {
          _translated.addAll(batchResult);
          _translationPending.removeAll(batchIndices);
        });
      } catch (_) {
        if (!mounted || generation != _translationGeneration) return;
        setState(() => _translationPending.removeAll(batchIndices));
      }
    }
  }

  Future<void> _initializeAudio(AppSettings settings) async {
    try {
      await _tts.setLanguage(settings.targetLanguageCode);
      await _tts.setSpeechRate(settings.voiceOverSpeechRate);
      await _tts.setPitch(settings.voiceOverPitch);
      await _tts.setVolume(settings.voiceOverSpeechVolume);
      await _loadTargetVoices(settings.targetLanguageCode);

      _tts.setStartHandler(() {
        if (!mounted) return;
        _ttsSpeaking = true;
      });
      _tts.setCompletionHandler(() {
        if (!mounted) return;
        _ttsSpeaking = false;
        _onTtsFinished();
      });
      _tts.setCancelHandler(() {
        if (!mounted) return;
        _ttsSpeaking = false;
      });
      _tts.setErrorHandler((_) {
        if (!mounted) return;
        _ttsSpeaking = false;
        _onTtsFinished();
      });
      _ttsReady = true;
    } catch (_) {}
  }

  void _onTtsFinished() {
    if (!mounted) return;
    final settings = context.read<AppSettings>();
    if (settings.voiceOverMuteVideo) {
      _unMutePlayer();
    } else if (settings.voiceOverEnabled) {
      _setPlayerVolume(100);
    }
    if (_pausedForTtsTail) {
      _pausedForTtsTail = false;
      _playVideo();
    }
  }

  Future<void> _loadTargetVoices(String languageCode) async {
    try {
      final dynamic available = await _tts.getVoices;
      if (available is List) {
        final norm = languageCode.toLowerCase().split(RegExp('[-_]')).first;
        final voices = available
            .whereType<Map>()
            .map(
              (voice) => {
                'name': voice['name']?.toString() ?? '',
                'locale': voice['locale']?.toString() ?? '',
              },
            )
            .where(
              (voice) =>
                  voice['name']!.isNotEmpty &&
                  voice['locale']!.toLowerCase().startsWith(norm),
            )
            .toList();
        if (mounted) setState(() => _targetVoices = voices);
      }
    } catch (_) {
      if (mounted) setState(() => _targetVoices = []);
    }
  }

  Future<void> _changeTargetLanguage(String languageCode) async {
    final settings = context.read<AppSettings>();
    await settings.setTargetLanguageCode(languageCode);
    final generation = ++_translationGeneration;
    setState(() {
      _translated.clear();
      _translationPending.clear();
      _targetVoices = [];
      _lastSpokenCaptionIndex = -1;
    });
    try {
      await _tts.setLanguage(languageCode);
    } catch (_) {}
    await _loadTargetVoices(languageCode);
    unawaited(
      _prefetchAllTranslations(
        generation,
        startFromIndex: _activeCaption >= 0 ? _activeCaption : 0,
      ),
    );
  }

  void _onPosition(Duration position) {
    _currentPosition = position;
    final effectiveDur = _totalDuration.inMilliseconds > 0
        ? _totalDuration
        : _video.duration;
    if (effectiveDur != null &&
        effectiveDur.inMilliseconds > 0 &&
        DateTime.now().difference(_lastProgressSave) >=
            const Duration(seconds: 6)) {
      _lastProgressSave = DateTime.now();
      context.read<LocalStore>().updateRecentProgress(
            _video.id,
            position.inMilliseconds / effectiveDur.inMilliseconds,
            positionMs: position.inMilliseconds,
          );
    }

    if (_captions.isEmpty || !mounted) return;
    final settings = context.read<AppSettings>();

    if (settings.voiceOverEnabled &&
        settings.voiceOverPauseForTail &&
        _ttsSpeaking &&
        !_pausedForTtsTail &&
        _activeCaption >= 0 &&
        _activeCaption < _captions.length) {
      final activeEnd = _captions[_activeCaption].end;
      if (position >= activeEnd - const Duration(milliseconds: 120)) {
        _pausedForTtsTail = true;
        _pauseVideo();
        return;
      }
    }

    final index = _captions.indexWhere(
      (line) => position >= line.offset && position < line.end,
    );

    if (index != _activeCaption && index >= 0) {
      setState(() => _activeCaption = index);
      _scrollToActiveCaption(index);

      if (!_translated.containsKey(index)) {
        unawaited(
          _prefetchAllTranslations(
            _translationGeneration,
            startFromIndex: index,
          ),
        );
      }
      if (settings.voiceOverEnabled && _lastSpokenCaptionIndex != index) {
        _lastSpokenCaptionIndex = index;
        unawaited(_speakLine(index));
      }
    }
  }

  void _scrollToActiveCaption(int index) {
    if (!_autoScrollTranscript ||
        _showTranscriptSearch ||
        !_transcriptScroll.hasClients) {
      return;
    }
    if (DateTime.now().difference(_lastUserScrollTime) <
        const Duration(seconds: 4)) {
      return;
    }
    const double estimatedCardHeight = 108.0;
    final viewport = _transcriptScroll.position.viewportDimension;
    final targetOffset =
        ((index * estimatedCardHeight) - (viewport * 0.28)).clamp(
      0.0,
      _transcriptScroll.position.maxScrollExtent,
    );
    _transcriptScroll.animateTo(
      targetOffset,
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _speakLine(int index, {bool forceSpeak = false}) async {
    if (!_ttsReady || index < 0 || index >= _captions.length) return;
    final settings = context.read<AppSettings>();
    final captionsService = context.read<CaptionService>();
    if (!forceSpeak && !settings.voiceOverEnabled) return;

    if (!_translated.containsKey(index) && _selectedTrack != null) {
      try {
        final text = await captionsService.translateLine(
          text: _captions[index].text,
          sourceCode: _selectedTrack!.languageCode,
          targetCode: settings.targetLanguageCode,
        );
        if (mounted) {
          setState(() => _translated[index] = text);
        }
      } catch (_) {}
    }

    final lineText = _translated[index]?.trim().isNotEmpty == true
        ? _translated[index]!
        : _captions[index].text;
    if (lineText.trim().isEmpty) return;

    if (settings.voiceOverMuteVideo) {
      await _mutePlayer();
    } else {
      await _setPlayerVolume((settings.voiceOverVideoVolume * 100).round());
    }

    final captionDuration = _captions[index].duration.inMilliseconds / 1000.0;
    final automaticRate =
        (lineText.runes.length / (math.max(captionDuration, 0.8) * 22))
            .clamp(0.38, 0.78)
            .toDouble();
    await _tts.setSpeechRate(
      settings.voiceOverAutoRate ? automaticRate : settings.voiceOverSpeechRate,
    );
    await _tts.setPitch(settings.voiceOverPitch);
    await _tts.setVolume(settings.voiceOverSpeechVolume);
    await _tts.speak(lineText);
  }

  Future<void> _skipBy(Duration delta) async {
    var target = _currentPosition + delta;
    if (target < Duration.zero) target = Duration.zero;
    if (_totalDuration > Duration.zero && target > _totalDuration) {
      target = _totalDuration;
    }
    await _seekTo(target);
  }

  Future<void> _saveBookmarkWithDialog(int index) async {
    if (index < 0 || index >= _captions.length) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('اختر سطراً من الترجمة لحفظه كإشارة مرجعية.'),
        ),
      );
      return;
    }
    final store = context.read<LocalStore>();
    final line = _captions[index];
    final origCtrl = TextEditingController(text: line.text);
    final transCtrl = TextEditingController(text: _translated[index] ?? '');
    final noteCtrl = TextEditingController();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('إشارة مرجعية جديدة'),
        content: SizedBox(
          width: 440,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: origCtrl,
                  minLines: 1,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'النص الأصلي'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: transCtrl,
                  minLines: 1,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'الترجمة'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: noteCtrl,
                  minLines: 1,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'ملاحظة (اختياري)',
                    hintText: 'أدخل ملاحظة حول هذه الكلمة أو الجملة',
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await store.addBookmark(
        video: _video,
        position: line.offset,
        originalText: origCtrl.text.trim(),
        translatedText: transCtrl.text.trim(),
        note: noteCtrl.text.trim(),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم حفظ الإشارة المرجعية.')),
        );
      }
    }
    origCtrl.dispose();
    transCtrl.dispose();
    noteCtrl.dispose();
  }

  Future<void> _copyCaption(int index) async {
    if (index < 0 || index >= _captions.length) return;
    final original = _captions[index].text;
    final translated = _translated[index];
    final value = translated == null || translated.isEmpty
        ? original
        : '$original\n$translated';
    await Clipboard.setData(ClipboardData(text: value));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم النسخ إلى الحافظة.')),
    );
  }

  Future<void> _shareFullTranscript() async {
    if (_captions.isEmpty) return;
    final buffer = StringBuffer('${_video.title}\n${_video.watchUrl}\n\n');
    for (var i = 0; i < _captions.length; i++) {
      final line = _captions[i];
      final trans = _translated[i];
      buffer.writeln('[${_formatTimestamp(line.offset)}] ${line.text}');
      if (trans != null && trans.isNotEmpty) {
        buffer.writeln('   -> $trans');
      }
    }
    await SharePlus.instance.share(
      ShareParams(title: _video.title, text: buffer.toString()),
    );
  }

  Future<void> _handleVideoEnded() async {
    if (!mounted) return;
    final autoNext = context.read<AppSettings>().autoNext;
    if (_autoNextTriggered || !autoNext) return;
    _autoNextTriggered = true;
    final catalog = context.read<YoutubeCatalogService>();
    try {
      final related = await catalog.loadRelatedVideos(_video.id, limit: 4);
      if (related.isEmpty || !mounted) return;
      final nextVideo = related.first;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => PlayerScreen(video: nextVideo)),
      );
    } catch (_) {}
  }

  Future<void> _openOnYouTube() async {
    final uri = Uri.parse(_video.watchUrl);
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر فتح الفيديو في تطبيق YouTube.')),
      );
    }
  }

  Future<void> _openCaptionsAndFontSettings() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.76,
        maxChildSize: 0.92,
        minChildSize: 0.5,
        builder: (context, scrollController) {
          final settings = context.watch<AppSettings>();
          final selectedKey = _selectedTrack == null
              ? null
              : '${_selectedTrack!.languageCode}_${_selectedTrack!.isAutoGenerated}';
          return SafeArea(
            child: ListView(
              controller: scrollController,
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
              children: [
                const Text(
                  'إعدادات الترجمة والخط',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 14),
                DropdownButtonFormField<String>(
                  initialValue: settings.targetLanguageCode,
                  decoration: const InputDecoration(
                    labelText: 'نطق / ترجمة إلى',
                    prefixIcon: Icon(Icons.translate_rounded),
                  ),
                  items: AppSettings.supportedLanguages
                      .map(
                        (lang) => DropdownMenuItem<String>(
                          value: lang.code,
                          child: Text('${lang.arabicName} (${lang.nativeName})'),
                        ),
                      )
                      .toList(),
                  onChanged: (val) {
                    if (val != null) _changeTargetLanguage(val);
                  },
                ),
                const SizedBox(height: 12),
                const Text(
                  'إظهار الترجمة النصية',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('النص الأساسي (الأصلي)'),
                  value: settings.showOriginalCaptions,
                  onChanged: settings.setShowOriginalCaptions,
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('النص المترجم'),
                  value: settings.showTranslatedCaptions,
                  onChanged: settings.setShowTranslatedCaptions,
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('شريط الترجمة فوق الفيديو'),
                  value: settings.showOverlayCaptions,
                  onChanged: settings.setShowOverlayCaptions,
                ),
                const Divider(),
                const Text(
                  'إعدادات الخط',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text(
                  'حجم الترجمة الأساسية (${settings.primaryFontSize.round()})',
                ),
                Slider(
                  min: 12,
                  max: 26,
                  divisions: 14,
                  value: settings.primaryFontSize,
                  onChanged: settings.setPrimaryFontSize,
                ),
                Text('حجم الترجمة (${settings.translationFontSize.round()})'),
                Slider(
                  min: 12,
                  max: 26,
                  divisions: 14,
                  value: settings.translationFontSize,
                  onChanged: settings.setTranslationFontSize,
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Text('نمط الخط: '),
                    const SizedBox(width: 8),
                    Expanded(
                      child: SegmentedButton<int>(
                        segments: const [
                          ButtonSegment(value: 0, label: Text('خفيف')),
                          ButtonSegment(value: 1, label: Text('عادي')),
                          ButtonSegment(value: 2, label: Text('متوسط')),
                          ButtonSegment(value: 3, label: Text('عريض')),
                        ],
                        selected: {settings.fontWeightIndex},
                        onSelectionChanged: (set) {
                          if (set.isNotEmpty) {
                            settings.setFontWeightIndex(set.first);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                const Divider(),
                const Text(
                  'مسار اللغة المصدر للفيديو',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                if (_availableTracks.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('لا توجد مسارات ترجمة نصية متاحة لهذا الفيديو.'),
                  )
                else
                  ..._availableTracks.map((track) {
                    final key =
                        '${track.languageCode}_${track.isAutoGenerated}';
                    final isSelected = key == selectedKey;
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(
                        isSelected
                            ? Icons.radio_button_checked
                            : Icons.radio_button_unchecked,
                        color: isSelected ? const Color(0xFF8B7CFF) : null,
                      ),
                      title: Text(track.label),
                      subtitle: Text(
                        track.isAutoGenerated
                            ? 'مُولّدة تلقائياً (${track.languageCode})'
                            : 'مسار أساسي (${track.languageCode})',
                      ),
                      onTap: () {
                        Navigator.pop(sheetContext);
                        _selectCaptionTrack(track);
                      },
                    );
                  }),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _openVoiceOverSettings() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
          child: Consumer<AppSettings>(
            builder: (context, settings, _) => SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'إعدادات التعليق الصوتي (الدبلجة)',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('تفعيل التعليق الصوتي'),
                    subtitle: const Text(
                      'قراءة الترجمة بصوت مسموع أثناء تشغيل الفيديو',
                    ),
                    value: settings.voiceOverEnabled,
                    onChanged: (val) async {
                      await settings.setVoiceOverEnabled(val);
                      if (!val) {
                        await _tts.stop();
                        await _unMutePlayer();
                        await _setPlayerVolume(100);
                      }
                    },
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('السرعة التلقائية'),
                    subtitle: const Text(
                      'مزامنة سرعة النطق تلقائياً مع طول الجملة',
                    ),
                    value: settings.voiceOverAutoRate,
                    onChanged: settings.setVoiceOverAutoRate,
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('انتظار اكتمال نطق الجملة'),
                    subtitle: const Text(
                      'إيقاف الفيديو مؤقتاً لأجزاء من الثانية حتى ينتهي نطق الجملة الطويلة',
                    ),
                    value: settings.voiceOverPauseForTail,
                    onChanged: settings.setVoiceOverPauseForTail,
                  ),
                  if (_targetVoices.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: DropdownButtonFormField<String>(
                        initialValue: _targetVoices.any(
                          (v) =>
                              '${v['name']}|${v['locale']}' ==
                              settings.selectedVoiceKey,
                        )
                            ? settings.selectedVoiceKey
                            : null,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'الصوت المختار',
                        ),
                        items: _targetVoices.map((voice) {
                          final key = '${voice['name']}|${voice['locale']}';
                          return DropdownMenuItem<String>(
                            value: key,
                            child: Text(
                              '${voice['name']} (${voice['locale']})',
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }).toList(),
                        onChanged: (key) async {
                          if (key == null) return;
                          final voice = _targetVoices.firstWhere(
                            (item) =>
                                '${item['name']}|${item['locale']}' == key,
                          );
                          await _tts.setVoice(voice);
                          await settings.setSelectedVoiceKey(key);
                        },
                      ),
                    ),
                  _SliderSetting(
                    title: 'سرعة النطق',
                    value: settings.voiceOverSpeechRate,
                    min: 0.25,
                    max: 0.85,
                    onChanged: settings.setVoiceOverSpeechRate,
                  ),
                  _SliderSetting(
                    title: 'النبرة (Pitch)',
                    value: settings.voiceOverPitch,
                    min: 0.5,
                    max: 2.0,
                    onChanged: settings.setVoiceOverPitch,
                  ),
                  _SliderSetting(
                    title: 'مستوى صوت الكلام',
                    value: settings.voiceOverSpeechVolume,
                    min: 0,
                    max: 1,
                    onChanged: settings.setVoiceOverSpeechVolume,
                  ),
                  _SliderSetting(
                    title: 'مستوى صوت الفيديو أثناء النطق',
                    value: settings.voiceOverVideoVolume,
                    min: 0,
                    max: 1,
                    onChanged: (value) async {
                      await settings.setVoiceOverVideoVolume(value);
                      if (settings.voiceOverEnabled &&
                          !settings.voiceOverMuteVideo) {
                        await _setPlayerVolume((value * 100).round());
                      }
                    },
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('كتم صوت الفيديو الأصلي تماماً أثناء النطق'),
                    value: settings.voiceOverMuteVideo,
                    onChanged: settings.setVoiceOverMuteVideo,
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => Navigator.pop(sheetContext),
                      child: const Text('تم'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  String _formatTimestamp(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    if (d.inHours > 0) {
      return '${d.inHours}:${two(d.inMinutes.remainder(60))}:${two(d.inSeconds.remainder(60))}';
    }
    return '${two(d.inMinutes)}:${two(d.inSeconds.remainder(60))}';
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    _tts.stop();
    _tabController.dispose();
    _transcriptScroll.dispose();
    _transcriptSearchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _video.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700),
        ),
        actions: [
          IconButton(
            tooltip: 'مشاركة النص الكامل',
            onPressed: _captions.isNotEmpty ? _shareFullTranscript : null,
            icon: const Icon(Icons.ios_share_outlined, size: 20),
          ),
          IconButton(
            tooltip: 'إضافة إلى قائمة تشغيل',
            onPressed: () =>
                VideoListTile.showAddToPlaylistDialog(context, _video),
            icon: const Icon(Icons.playlist_add, size: 22),
          ),
          IconButton(
            tooltip: 'فتح في YouTube',
            onPressed: _openOnYouTube,
            icon: const Icon(Icons.open_in_new, size: 20),
          ),
        ],
      ),
      body: Column(
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Stack(
              alignment: Alignment.bottomCenter,
              children: [
                WebViewWidget(controller: _webController),
                if (!_playerReady)
                  const Center(
                    child: CircularProgressIndicator(color: Color(0xFF8B7CFF)),
                  ),
                if (settings.showOverlayCaptions &&
                    _activeCaption >= 0 &&
                    _activeCaption < _captions.length)
                  Positioned(
                    left: 10,
                    right: 10,
                    bottom: 28,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.78),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (settings.showTranslatedCaptions)
                                Text(
                                  _translated[_activeCaption] ??
                                      (_translationPending
                                              .contains(_activeCaption)
                                          ? 'جارٍ الترجمة…'
                                          : ''),
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: const Color(0xFFFFE082),
                                    fontSize: (settings.translationFontSize - 1)
                                        .clamp(12.0, 22.0),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              if (settings.showOriginalCaptions)
                                Text(
                                  _captions[_activeCaption].text,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: (settings.primaryFontSize - 1.5)
                                        .clamp(11.0, 20.0),
                                    fontWeight: settings.captionFontWeight,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Material(
            color: isDark ? const Color(0xFF141720) : Colors.grey.shade100,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    IconButton(
                      tooltip: 'الرجوع 10 ثوانٍ',
                      onPressed: () => _skipBy(const Duration(seconds: -10)),
                      icon: const Icon(Icons.replay_10_rounded),
                    ),
                    IconButton(
                      tooltip: _isPlaying ? 'إيقاف مؤقت' : 'تشغيل',
                      onPressed: () {
                        if (_isPlaying) {
                          _pauseVideo();
                        } else {
                          _playVideo();
                        }
                      },
                      icon: Icon(
                        _isPlaying
                            ? Icons.pause_circle_filled_rounded
                            : Icons.play_circle_fill_rounded,
                        size: 30,
                        color: const Color(0xFF8B7CFF),
                      ),
                    ),
                    IconButton(
                      tooltip: 'التقديم 10 ثوانٍ',
                      onPressed: () => _skipBy(const Duration(seconds: 10)),
                      icon: const Icon(Icons.forward_10_rounded),
                    ),
                    const SizedBox(width: 4),
                    FilterChip(
                      avatar: Icon(
                        settings.voiceOverEnabled
                            ? Icons.volume_up_rounded
                            : Icons.volume_off_outlined,
                        size: 17,
                      ),
                      label: const Text('الدبلجة الصوتية'),
                      selected: settings.voiceOverEnabled,
                      onSelected: (val) async {
                        await settings.setVoiceOverEnabled(val);
                        if (val && _activeCaption >= 0) {
                          unawaited(
                            _speakLine(_activeCaption, forceSpeak: true),
                          );
                        } else if (!val) {
                          await _tts.stop();
                          await _unMutePlayer();
                          await _setPlayerVolume(100);
                        }
                      },
                    ),
                    const SizedBox(width: 6),
                    ActionChip(
                      avatar:
                          const Icon(Icons.closed_caption_outlined, size: 17),
                      label: Text(
                        _selectedTrack != null
                            ? '${_selectedTrack!.normalizedLang.toUpperCase()} ← ${settings.targetLanguageCode.toUpperCase()}'
                            : 'إعدادات الترجمة',
                      ),
                      onPressed: _openCaptionsAndFontSettings,
                    ),
                    const SizedBox(width: 6),
                    ActionChip(
                      avatar: const Icon(Icons.tune_rounded, size: 17),
                      label: const Text('الصوت'),
                      onPressed: _openVoiceOverSettings,
                    ),
                    const SizedBox(width: 6),
                    PopupMenuButton<double>(
                      tooltip: 'سرعة التشغيل',
                      initialValue: _playbackRate,
                      onSelected: _setPlaybackRate,
                      itemBuilder: (context) => const [
                        PopupMenuItem(value: 0.5, child: Text('0.5x')),
                        PopupMenuItem(value: 0.75, child: Text('0.75x')),
                        PopupMenuItem(value: 1.0, child: Text('1.0x (عادي)')),
                        PopupMenuItem(value: 1.25, child: Text('1.25x')),
                        PopupMenuItem(value: 1.5, child: Text('1.5x')),
                        PopupMenuItem(value: 2.0, child: Text('2.0x')),
                      ],
                      child: Chip(
                        label: Text('${_playbackRate}x'),
                      ),
                    ),
                    IconButton(
                      tooltip: 'إعادة الفيديو تلقائياً',
                      onPressed: () =>
                          setState(() => _repeatVideo = !_repeatVideo),
                      icon: Icon(
                        Icons.repeat_rounded,
                        color: _repeatVideo ? const Color(0xFF8B7CFF) : null,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          TabBar(
            controller: _tabController,
            tabs: [
              Tab(
                text: _captions.isEmpty
                    ? 'النصوص والترجمة'
                    : 'النصوص (${_captions.length})',
              ),
              const Tab(text: 'المقترحات والمعلومات'),
              const Tab(text: 'إشاراتي'),
            ],
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildTranscriptTab(settings, isDark),
                _RelatedAndInfoTab(
                  video: _video,
                  onOpenOnYouTube: _openOnYouTube,
                ),
                _VideoBookmarksTab(
                  video: _video,
                  onSeekTo: _seekTo,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTranscriptTab(AppSettings settings, bool isDark) {
    if (_loadingCaptions) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 12),
            Text('جارٍ استخراج وترجمة نصوص الفيديو تلقائياً...'),
          ],
        ),
      );
    }

    if (_captions.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.subtitles_off_outlined,
                size: 46,
                color: Colors.white38,
              ),
              const SizedBox(height: 12),
              Text(
                _captionsError ?? 'هذا الفيديو لا يحتوي على ترجمة نصية متاحة.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 14),
              FilledButton.tonalIcon(
                onPressed: _autoLoadCaptionsAndTranslate,
                icon: const Icon(Icons.refresh),
                label: const Text('إعادة فحص المسارات'),
              ),
            ],
          ),
        ),
      );
    }

    final filteredIndices = <int>[];
    final q = _transcriptFilter.trim().toLowerCase();
    for (var i = 0; i < _captions.length; i++) {
      if (q.isEmpty) {
        filteredIndices.add(i);
      } else {
        final orig = _captions[i].text.toLowerCase();
        final trans = (_translated[i] ?? '').toLowerCase();
        if (orig.contains(q) || trans.contains(q)) {
          filteredIndices.add(i);
        }
      }
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 4),
          child: Row(
            children: [
              if (_translationPending.isNotEmpty) ...[
                const SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                const SizedBox(width: 8),
                Text(
                  'مُترجم ${_translated.length}/${_captions.length}',
                  style: const TextStyle(fontSize: 12, color: Colors.white70),
                ),
              ] else
                Text(
                  '${_captions.length} سطر جاهز',
                  style: const TextStyle(fontSize: 12, color: Colors.white60),
                ),
              const Spacer(),
              IconButton(
                tooltip: 'بحث داخل نص الفيديو',
                visualDensity: VisualDensity.compact,
                onPressed: () {
                  setState(() {
                    _showTranscriptSearch = !_showTranscriptSearch;
                    if (!_showTranscriptSearch) {
                      _transcriptSearchCtrl.clear();
                      _transcriptFilter = '';
                    }
                  });
                },
                icon: Icon(
                  Icons.find_in_page_outlined,
                  size: 20,
                  color:
                      _showTranscriptSearch ? const Color(0xFF8B7CFF) : null,
                ),
              ),
              FilterChip(
                visualDensity: VisualDensity.compact,
                label: const Text(
                  'تتبع تلقائي',
                  style: TextStyle(fontSize: 11.5),
                ),
                selected: _autoScrollTranscript,
                onSelected: (v) => setState(() => _autoScrollTranscript = v),
              ),
            ],
          ),
        ),
        if (_showTranscriptSearch)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 2, 12, 8),
            child: TextField(
              controller: _transcriptSearchCtrl,
              autofocus: true,
              onChanged: (val) => setState(() => _transcriptFilter = val),
              decoration: InputDecoration(
                hintText: 'ابحث عن كلمة أو جملة داخل الفيديو...',
                prefixIcon: const Icon(Icons.search, size: 19),
                suffixIcon: _transcriptFilter.isNotEmpty
                    ? IconButton(
                        onPressed: () {
                          _transcriptSearchCtrl.clear();
                          setState(() => _transcriptFilter = '');
                        },
                        icon: const Icon(Icons.close, size: 18),
                      )
                    : null,
                isDense: true,
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        Expanded(
          child: NotificationListener<UserScrollNotification>(
            onNotification: (_) {
              _lastUserScrollTime = DateTime.now();
              return false;
            },
            child: ListView.builder(
              controller: _transcriptScroll,
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
              itemCount: filteredIndices.length,
              itemBuilder: (context, listIdx) {
                final index = filteredIndices[listIdx];
                final line = _captions[index];
                final active = index == _activeCaption;
                final translated = _translated[index];
                final pending = _translationPending.contains(index);

                return Card(
                  color: active
                      ? const Color(0xFF2D2752)
                      : (isDark ? const Color(0xFF181B24) : Colors.white),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: active
                        ? const BorderSide(color: Color(0xFF8B7CFF), width: 1.4)
                        : BorderSide.none,
                  ),
                  margin: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => _seekTo(line.offset),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(12, 10, 8, 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          if (settings.showOriginalCaptions)
                            Text(
                              line.text,
                              textDirection: TextDirection.ltr,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontSize: settings.primaryFontSize,
                                fontWeight: settings.captionFontWeight,
                                height: 1.35,
                              ),
                            ),
                          if (settings.showTranslatedCaptions) ...[
                            const SizedBox(height: 6),
                            if (translated != null && translated.isNotEmpty)
                              Text(
                                translated,
                                style: TextStyle(
                                  color: isDark
                                      ? const Color(0xFFFFE082)
                                      : const Color(0xFF4A3AFF),
                                  fontSize: settings.translationFontSize,
                                  fontWeight: settings.captionFontWeight,
                                  height: 1.4,
                                ),
                              )
                            else if (pending)
                              const Text(
                                'جارٍ الترجمة…',
                                style: TextStyle(
                                  color: Colors.white54,
                                  fontSize: 13,
                                ),
                              ),
                          ],
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: active
                                      ? const Color(0xFF8B7CFF)
                                      : Colors.white.withValues(alpha: 0.08),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  _formatTimestamp(line.offset),
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color:
                                        active ? Colors.white : Colors.white70,
                                  ),
                                ),
                              ),
                              const Spacer(),
                              IconButton(
                                tooltip: 'تشغيل من هذا السطر',
                                visualDensity: VisualDensity.compact,
                                onPressed: () => _seekTo(line.offset),
                                icon: const Icon(
                                  Icons.play_arrow_rounded,
                                  size: 20,
                                ),
                              ),
                              IconButton(
                                tooltip: 'نطق الجملة صوتياً',
                                visualDensity: VisualDensity.compact,
                                onPressed: () =>
                                    _speakLine(index, forceSpeak: true),
                                icon: const Icon(
                                  Icons.record_voice_over_outlined,
                                  size: 18,
                                ),
                              ),
                              IconButton(
                                tooltip: 'نسخ النص والترجمة',
                                visualDensity: VisualDensity.compact,
                                onPressed: () => _copyCaption(index),
                                icon: const Icon(Icons.copy_outlined, size: 18),
                              ),
                              IconButton(
                                tooltip: 'حفظ كإشارة مرجعية',
                                visualDensity: VisualDensity.compact,
                                onPressed: () => _saveBookmarkWithDialog(index),
                                icon: const Icon(
                                  Icons.bookmark_add_outlined,
                                  size: 19,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

class _RelatedAndInfoTab extends StatefulWidget {
  const _RelatedAndInfoTab({
    required this.video,
    required this.onOpenOnYouTube,
  });

  final WaleedVideo video;
  final VoidCallback onOpenOnYouTube;

  @override
  State<_RelatedAndInfoTab> createState() => _RelatedAndInfoTabState();
}

class _RelatedAndInfoTabState extends State<_RelatedAndInfoTab> {
  late Future<List<WaleedVideo>> _relatedFuture;
  bool _descExpanded = false;

  @override
  void initState() {
    super.initState();
    _relatedFuture = context
        .read<YoutubeCatalogService>()
        .loadRelatedVideos(widget.video.id, limit: 12);
  }

  @override
  Widget build(BuildContext context) {
    final v = widget.video;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  v.title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(
                      Icons.person_outline,
                      size: 16,
                      color: Colors.white60,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        v.channel.isEmpty ? 'YouTube' : v.channel,
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ),
                    TextButton.icon(
                      onPressed: widget.onOpenOnYouTube,
                      icon: const Icon(Icons.open_in_new, size: 16),
                      label: const Text('YouTube'),
                    ),
                  ],
                ),
                if (v.viewCount != null || v.publishedAt != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    [
                      if (v.viewCount != null) 'المشاهدات: ${v.viewCount}',
                      if (v.publishedAt != null)
                        'تاريخ النشر: ${v.publishedAt!.toIso8601String().split('T').first}',
                    ].join(' • '),
                    style: const TextStyle(fontSize: 12, color: Colors.white54),
                  ),
                ],
                if (v.description.isNotEmpty) ...[
                  const Divider(height: 20),
                  const Text(
                    'الوصف',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    v.description,
                    maxLines: _descExpanded ? null : 3,
                    overflow: _descExpanded
                        ? TextOverflow.visible
                        : TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, height: 1.4),
                  ),
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: TextButton(
                      onPressed: () =>
                          setState(() => _descExpanded = !_descExpanded),
                      child: Text(_descExpanded ? 'عرض أقل' : 'عرض المزيد'),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'فيديوهات مقترحة ذات صلة',
          style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        FutureBuilder<List<WaleedVideo>>(
          future: _relatedFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: CircularProgressIndicator()),
              );
            }
            final videos = snapshot.data ?? const <WaleedVideo>[];
            if (videos.isEmpty) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'لا توجد اقتراحات إضافية حالياً.',
                  style: TextStyle(color: Colors.white54),
                ),
              );
            }
            return Column(
              children: videos
                  .map(
                    (item) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: VideoListTile(
                        video: item,
                        onTap: () => Navigator.of(context).pushReplacement(
                          MaterialPageRoute<void>(
                            builder: (_) => PlayerScreen(video: item),
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            );
          },
        ),
      ],
    );
  }
}

class _VideoBookmarksTab extends StatelessWidget {
  const _VideoBookmarksTab({
    required this.video,
    required this.onSeekTo,
  });

  final WaleedVideo video;
  final ValueChanged<Duration> onSeekTo;

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LocalStore>();
    return FutureBuilder<List<Map<String, Object?>>>(
      future: store.loadBookmarks(videoId: video.id),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting &&
            !snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final rows = snapshot.data ?? const [];
        if (rows.isEmpty) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'لم تحفظ أي إشارات مرجعية في هذا الفيديو بعد.\nاضغط أيقونة الإشارة المرجعية بجانب أي سطر لحفظه هنا.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white60),
              ),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: rows.length,
          separatorBuilder: (_, _) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final row = rows[index];
            final posMs = row['position_ms'] as int? ?? 0;
            final orig = row['original_text'] as String? ?? '';
            final trans = row['translated_text'] as String? ?? '';
            final note = row['note'] as String? ?? '';
            return Card(
              child: ListTile(
                onTap: () => onSeekTo(Duration(milliseconds: posMs)),
                leading: IconButton.filledTonal(
                  onPressed: () => onSeekTo(Duration(milliseconds: posMs)),
                  icon: const Icon(Icons.play_arrow),
                ),
                title: Text(orig),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (trans.isNotEmpty)
                      Text(
                        trans,
                        style: const TextStyle(color: Color(0xFFFFE082)),
                      ),
                    if (note.isNotEmpty)
                      Text(
                        'ملاحظة: $note',
                        style:
                            const TextStyle(fontSize: 12, color: Colors.white60),
                      ),
                  ],
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit_outlined, size: 19),
                      onPressed: () =>
                          BookmarksScreenStateHelper.edit(context, row),
                    ),
                    IconButton(
                      icon: const Icon(
                        Icons.delete_outline,
                        size: 19,
                        color: Colors.redAccent,
                      ),
                      onPressed: () => store.removeBookmark(row['id'] as int),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class BookmarksScreenStateHelper {
  static Future<void> edit(BuildContext context, Map<String, Object?> row) {
    final store = context.read<LocalStore>();
    final original = TextEditingController(
      text: row['original_text'] as String? ?? '',
    );
    final translated = TextEditingController(
      text: row['translated_text'] as String? ?? '',
    );
    final note = TextEditingController(text: row['note'] as String? ?? '');

    return showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تعديل الإشارة المرجعية'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: original,
                decoration: const InputDecoration(labelText: 'النص الأصلي'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: translated,
                decoration: const InputDecoration(labelText: 'الترجمة'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: note,
                decoration: const InputDecoration(labelText: 'ملاحظة'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('حفظ'),
          ),
        ],
      ),
    ).then((saved) async {
      if (saved == true) {
        await store.updateBookmark(
          id: row['id'] as int,
          originalText: original.text,
          translatedText: translated.text,
          note: note.text,
        );
      }
      original.dispose();
      translated.dispose();
      note.dispose();
    });
  }
}

class _SliderSetting extends StatelessWidget {
  const _SliderSetting({
    required this.title,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
  });

  final String title;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text(title)),
            Text(
              value.toStringAsFixed(2),
              style: const TextStyle(color: Colors.white54),
            ),
          ],
        ),
        Slider(
          value: value.clamp(min, max),
          min: min,
          max: max,
          onChanged: onChanged,
        ),
      ],
    );
  }
}

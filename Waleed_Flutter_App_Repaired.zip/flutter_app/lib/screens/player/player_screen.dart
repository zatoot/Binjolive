import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../data/local_store.dart';
import '../../data/app_settings.dart';
import '../../models/waleed_video.dart';
import '../../services/caption_service.dart';
import '../../services/youtube_catalog_service.dart';
import '../../widgets/video_thumbnail.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({
    required this.video,
    this.initialPosition = Duration.zero,
    super.key,
  });

  final WaleedVideo video;
  final Duration initialPosition;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late final YoutubePlayerController _player;
  late final CaptionService _captionsService;
  late final LocalStore _store;
  final FlutterTts _tts = FlutterTts();
  StreamSubscription<Duration>? _positionSubscription;
  StreamSubscription<YoutubePlayerValue>? _playerStateSubscription;
  bool _autoNextTriggered = false;

  List<WaleedCaptionLine> _captions = [];
  final Map<int, String> _translated = {};
  final Set<int> _translationPending = {};
  final Map<int, Future<void>> _translationTasks = {};
  int _translationGeneration = 0;
  CaptionTrackOption? _selectedTrack;
  int _activeCaption = -1;
  Duration _currentPosition = Duration.zero;
  bool _captionsVisible = true;
  bool _translationVisible = true;
  bool _voiceOverEnabled = false;
  bool _autoRate = true;
  bool _muteVideo = false;
  double _speechRate = 0.5;
  double _pitch = 1.0;
  double _speechVolume = 1.0;
  double _videoVolume = 0.25;
  double _captionFontSize = 15;
  bool _ttsReady = false;
  List<Map<String, String>> _targetVoices = [];
  String _targetLanguageCode = 'ar';
  String? _selectedVoiceKey;
  DateTime _lastProgressSave = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _player = YoutubePlayerController.fromVideoId(
      videoId: widget.video.id,
      autoPlay: true,
      params: const YoutubePlayerParams(
        showControls: true,
        showFullscreenButton: true,
        privacyEnhancedMode: true,
        enableCaption: false,
        strictRelatedVideos: true,
        interfaceLanguage: 'ar',
      ),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final autoRotate = context.read<AppSettings>().autoRotate;
      await SystemChrome.setPreferredOrientations(
        autoRotate
            ? const [
                DeviceOrientation.portraitUp,
                DeviceOrientation.portraitDown,
                DeviceOrientation.landscapeLeft,
                DeviceOrientation.landscapeRight,
              ]
            : const [DeviceOrientation.portraitUp],
      );
      if (!mounted) return;
      _captionsService = context.read<CaptionService>();
      _store = context.read<LocalStore>();
      _initializeAudio();
      _store.saveRecent(widget.video);
      if (widget.initialPosition > Duration.zero) {
        Future<void>.delayed(const Duration(milliseconds: 1200), () {
          if (mounted) {
            _player.seekTo(
              seconds: widget.initialPosition.inMilliseconds / 1000.0,
            );
          }
        });
      }
      _positionSubscription = _player.videoStateStream
          .map((state) => state.position)
          .listen(_onPosition);
      _playerStateSubscription = _player.stream.listen((value) {
        if (value.playerState == PlayerState.ended) _handleVideoEnded();
      });
    });
  }

  Future<void> _initializeAudio() async {
    await _tts.setLanguage(_targetLanguageCode);
    await _tts.setSpeechRate(_speechRate);
    await _tts.setPitch(_pitch);
    await _tts.setVolume(_speechVolume);
    await _loadTargetVoices(_targetLanguageCode);
    _tts.setCompletionHandler(() {
      if (_muteVideo) _player.unMute();
    });
    _ttsReady = true;
  }

  Future<void> _loadTargetVoices(String languageCode) async {
    try {
      final dynamic available = await _tts.getVoices;
      if (available is List) {
        final voices = available
            .whereType<Map>()
            .map(
              (voice) => {
                'name': voice['name']?.toString() ?? '',
                'locale': voice['locale']?.toString() ?? '',
              },
            )
            .where(
              (voice) =>
                  voice['name']!.isNotEmpty &&
                  voice['locale']!.toLowerCase().startsWith(
                    languageCode.toLowerCase(),
                  ),
            )
            .toList();
        if (mounted) setState(() => _targetVoices = voices);
      }
    } catch (_) {
      if (mounted) setState(() => _targetVoices = []);
    }
  }

  Future<void> _changeTargetLanguage(String languageCode) async {
    setState(() {
      _translationGeneration++;
      _translationTasks.clear();
      _translationPending.clear();
      _targetLanguageCode = languageCode;
      _translated.clear();
      _translationPending.clear();
      _targetVoices = [];
      _selectedVoiceKey = null;
    });
    try {
      await _tts.setLanguage(languageCode);
    } catch (_) {
      // Text translation remains available even if this device has no TTS voice.
    }
    await _loadTargetVoices(languageCode);
    if (_activeCaption >= 0) await _translateLine(_activeCaption);
  }

  void _onPosition(Duration position) {
    _currentPosition = position;
    final duration = widget.video.duration;
    if (duration != null &&
        duration.inMilliseconds > 0 &&
        DateTime.now().difference(_lastProgressSave) >=
            const Duration(seconds: 8)) {
      _lastProgressSave = DateTime.now();
      _store.updateRecentProgress(
        widget.video.id,
        position.inMilliseconds / duration.inMilliseconds,
      );
    }
    if (_captions.isEmpty || !mounted) return;
    final index = _captions.indexWhere(
      (line) =>
          position >= line.offset && position < line.offset + line.duration,
    );
    if (index != _activeCaption) {
      setState(() => _activeCaption = index);
      if ((_translationVisible || _voiceOverEnabled) && index >= 0) {
        _translateLine(index);
      }
      if (_voiceOverEnabled && index >= 0) _speakLine(index);
    }
  }

  Future<void> _translateLine(int index) {
    final track = _selectedTrack;
    if (track == null ||
        index < 0 ||
        index >= _captions.length ||
        _translated.containsKey(index)) {
      return Future<void>.value();
    }
    final pending = _translationTasks[index];
    if (pending != null) return pending;
    final generation = _translationGeneration;
    final targetCode = _targetLanguageCode;
    final task = _performTranslation(index, track, targetCode, generation);
    _translationTasks[index] = task;
    return task;
  }

  Future<void> _performTranslation(
    int index,
    CaptionTrackOption track,
    String targetCode,
    int generation,
  ) async {
    _translationPending.add(index);
    try {
      final value = await _captionsService.translateLine(
        text: _captions[index].text,
        sourceCode: track.languageCode,
        targetCode: targetCode,
      );
      if (!mounted || generation != _translationGeneration) return;
      setState(() => _translated[index] = value);
    } catch (_) {
      if (!mounted || generation != _translationGeneration) return;
      setState(() => _translated[index] = 'تعذرت ترجمة هذا السطر');
    } finally {
      if (generation == _translationGeneration) {
        _translationPending.remove(index);
        _translationTasks.remove(index);
      }
    }
  }

  Future<void> _speakLine(int index) async {
    if (!_ttsReady || index < 0 || index >= _captions.length) return;
    if (!_translated.containsKey(index)) await _translateLine(index);
    final line = _translated[index] ?? _captions[index].text;
    if (_muteVideo) await _player.mute();
    final captionDuration = _captions[index].duration.inMilliseconds / 1000.0;
    final automaticRate =
        (line.runes.length / (math.max(captionDuration, 0.6) * 24))
            .clamp(0.25, 0.8)
            .toDouble();
    await _tts.setSpeechRate(_autoRate ? automaticRate : _speechRate);
    await _tts.setPitch(_pitch);
    await _tts.setVolume(_speechVolume);
    await _tts.speak(line);
  }

  Future<void> _openCaptions() async {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1A1C23),
      builder: (sheetContext) => _CaptionTrackSheet(
        videoId: widget.video.id,
        selected: _selectedTrack,
        onSelect: (track, lines) {
          setState(() {
            _translationGeneration++;
            _translationTasks.clear();
            _translationPending.clear();
            _selectedTrack = track;
            _captions = lines;
            _translated.clear();
            _translationPending.clear();
            _activeCaption = -1;
            _captionsVisible = true;
            _translationVisible = true;
          });
          Navigator.pop(sheetContext);
        },
      ),
    );
  }

  Future<void> _openVoiceOverSettings() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1A1C23),
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, update) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'إعدادات التعليق الصوتي',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('تفعيل التعليق الصوتي'),
                    value: _voiceOverEnabled,
                    onChanged: (value) {
                      setState(() => _voiceOverEnabled = value);
                      update(() {});
                    },
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('السرعة التلقائية'),
                    value: _autoRate,
                    onChanged: (value) {
                      setState(() => _autoRate = value);
                      update(() {});
                    },
                  ),
                  if (_targetVoices.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: DropdownButtonFormField<String>(
                        initialValue: _selectedVoiceKey,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'الصوت العربي',
                        ),
                        items: _targetVoices.map((voice) {
                          final key = '${voice['name']}|${voice['locale']}';
                          return DropdownMenuItem<String>(
                            value: key,
                            child: Text(
                              '${voice['name']} (${voice['locale']})',
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }).toList(),
                        onChanged: (key) async {
                          if (key == null) return;
                          final voice = _targetVoices.firstWhere(
                            (item) =>
                                '${item['name']}|${item['locale']}' == key,
                          );
                          await _tts.setVoice(voice);
                          if (!mounted) return;
                          setState(() => _selectedVoiceKey = key);
                          update(() {});
                        },
                      ),
                    ),
                  _SliderSetting(
                    title: 'سرعة النطق',
                    value: _speechRate,
                    min: 0.25,
                    max: 0.8,
                    onChanged: (value) {
                      setState(() => _speechRate = value);
                      update(() {});
                    },
                  ),
                  _SliderSetting(
                    title: 'النبرة',
                    value: _pitch,
                    min: 0.5,
                    max: 2.0,
                    onChanged: (value) {
                      setState(() => _pitch = value);
                      update(() {});
                    },
                  ),
                  _SliderSetting(
                    title: 'مستوى صوت الكلام',
                    value: _speechVolume,
                    min: 0,
                    max: 1,
                    onChanged: (value) {
                      setState(() => _speechVolume = value);
                      update(() {});
                    },
                  ),
                  _SliderSetting(
                    title: 'مستوى صوت الفيديو',
                    value: _videoVolume,
                    min: 0,
                    max: 1,
                    onChanged: (value) async {
                      setState(() => _videoVolume = value);
                      await _player.setVolume((value * 100).round());
                      update(() {});
                    },
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('كتم صوت الفيديو أثناء النطق'),
                    value: _muteVideo,
                    onChanged: (value) {
                      setState(() => _muteVideo = value);
                      update(() {});
                    },
                  ),
                  const SizedBox(height: 8),
                  FilledButton(
                    onPressed: () => Navigator.pop(sheetContext),
                    child: const Text('تم'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _openInfo() async {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1A1C23),
      builder: (sheetContext) => FutureBuilder<dynamic>(
        future: context.read<YoutubeCatalogService>().client.videos.get(
          widget.video.id,
        ),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const SafeArea(
              child: SizedBox(
                height: 220,
                child: Center(child: CircularProgressIndicator()),
              ),
            );
          }
          if (snapshot.hasError) {
            return const SafeArea(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('تعذر تحميل معلومات الفيديو.'),
              ),
            );
          }
          final dynamic video = snapshot.data;
          final String description = video.description as String? ?? '';
          final dynamic date = video.publishDate;
          final dynamic views = video.engagement.viewCount;
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.video.title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      widget.video.channel,
                      style: const TextStyle(color: Colors.white60),
                    ),
                    const SizedBox(height: 10),
                    Text('تاريخ النشر: ${date ?? 'غير متوفر'}'),
                    Text('المشاهدات: ${views ?? 'غير متوفر'}'),
                    const SizedBox(height: 16),
                    const Text(
                      'الوصف',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      description.isEmpty ? 'لا يوجد وصف متاح.' : description,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _saveBookmarkAt(int index) async {
    if (index < 0 || index >= _captions.length) return;
    final line = _captions[index];
    await _store.addBookmark(
      video: widget.video,
      position: line.offset,
      originalText: line.text,
      translatedText: _translated[index] ?? '',
    );
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('تم حفظ الإشارة المرجعية.')));
  }

  Future<void> _saveCurrentBookmark() => _saveBookmarkAt(_activeCaption);

  Future<void> _copyCaption(int index) async {
    if (index < 0 || index >= _captions.length) return;
    final original = _captions[index].text;
    final translated = _translated[index];
    final value = translated == null || translated.isEmpty
        ? original
        : '$original\n$translated';
    await Clipboard.setData(ClipboardData(text: value));
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('تم نسخ النص.')));
  }

  Future<void> _skipBy(Duration delta) async {
    var target = _currentPosition + delta;
    if (target < Duration.zero) target = Duration.zero;
    final duration = widget.video.duration;
    if (duration != null && target > duration) target = duration;
    await _player.seekTo(seconds: target.inMilliseconds / 1000.0);
  }

  Future<void> _handleVideoEnded() async {
    if (_autoNextTriggered || !context.read<AppSettings>().autoNext) return;
    _autoNextTriggered = true;
    try {
      final catalog = context.read<YoutubeCatalogService>();
      final current = await catalog.client.videos.get(widget.video.id);
      final related = await catalog.client.videos.getRelatedVideos(current);
      if (related == null || related.isEmpty || !mounted) return;
      final dynamic next = related.first;
      String id;
      try {
        id = next.id.value as String;
      } catch (_) {
        id = next.id.toString();
      }
      final String title = next.title as String? ?? '';
      if (id.isEmpty || title.isEmpty || id == widget.video.id) return;
      String thumbnail = '';
      try {
        thumbnail = next.thumbnails.highResUrl as String;
      } catch (_) {
        try {
          thumbnail = next.thumbnails.mediumResUrl as String;
        } catch (_) {}
      }
      final video = WaleedVideo(
        id: id,
        title: title,
        channel: next.author as String? ?? '',
        thumbnailUrl: thumbnail,
        duration: next.duration as Duration?,
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => PlayerScreen(video: video)),
      );
    } catch (_) {
      // Keep the ended player on screen if recommendations are unavailable.
    }
  }

  Future<void> _openOnYouTube() async {
    final uri = Uri.parse(widget.video.watchUrl);
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر فتح الفيديو في YouTube.')),
      );
    }
  }

  Future<void> _playCaptionAt(int index) async {
    if (index < 0 || index >= _captions.length) return;
    await _player.seekTo(
      seconds: _captions[index].offset.inMilliseconds / 1000.0,
    );
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    _positionSubscription?.cancel();
    _playerStateSubscription?.cancel();
    _tts.stop();
    _player.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المشغّل'),
        actions: [
          IconButton(
            tooltip: 'معلومات الفيديو',
            onPressed: _openInfo,
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Stack(
            alignment: Alignment.bottomCenter,
            children: [
              YoutubePlayer(
                controller: _player,
                aspectRatio: 16 / 9,
                keepAlive: true,
              ),
              if (_captionsVisible &&
                  _activeCaption >= 0 &&
                  _activeCaption < _captions.length)
                Positioned(
                  left: 12,
                  right: 12,
                  bottom: 20,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: .78),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      child: Column(
                        children: [
                          if (_translationVisible)
                            Text(
                              _translated[_activeCaption] ??
                                  (_translationPending.contains(_activeCaption)
                                      ? 'جارٍ الترجمة…'
                                      : ''),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: const Color(0xFFFFE27A),
                                fontSize: _captionFontSize + 1,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          Text(
                            _captions[_activeCaption].text,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: _captionFontSize,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 4, 10, 2),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  tooltip: 'رجوع 10 ثوانٍ',
                  onPressed: () => _skipBy(const Duration(seconds: -10)),
                  icon: const Icon(Icons.replay_10),
                ),
                IconButton(
                  tooltip: 'تقديم 10 ثوانٍ',
                  onPressed: () => _skipBy(const Duration(seconds: 10)),
                  icon: const Icon(Icons.forward_10),
                ),
                TextButton.icon(
                  onPressed: _openOnYouTube,
                  icon: const Icon(Icons.open_in_new, size: 18),
                  label: const Text('فتح في YouTube'),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
            child: Text(
              widget.video.title,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              widget.video.channel,
              style: const TextStyle(color: Colors.white60),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            alignment: WrapAlignment.spaceEvenly,
            children: [
              _PlayerAction(
                icon: Icons.closed_caption_outlined,
                label: 'الترجمة النصية',
                onTap: _openCaptions,
              ),
              _PlayerAction(
                icon: Icons.record_voice_over_outlined,
                label: 'التعليق الصوتي',
                onTap: _openVoiceOverSettings,
              ),
              _PlayerAction(
                icon: Icons.bookmark_add_outlined,
                label: 'الإشارات المرجعية',
                onTap: _saveCurrentBookmark,
              ),
              _PlayerAction(
                icon: Icons.info_outline,
                label: 'معلومات',
                onTap: _openInfo,
              ),
            ],
          ),
          if (_captions.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      const Text(
                        'الترجمة النصية',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const Spacer(),
                      DropdownButton<String>(
                        value: _targetLanguageCode,
                        underline: const SizedBox.shrink(),
                        items: const [
                          DropdownMenuItem(value: 'ar', child: Text('العربية')),
                          DropdownMenuItem(value: 'en', child: Text('English')),
                          DropdownMenuItem(
                            value: 'fr',
                            child: Text('Français'),
                          ),
                          DropdownMenuItem(value: 'de', child: Text('Deutsch')),
                          DropdownMenuItem(value: 'es', child: Text('Español')),
                          DropdownMenuItem(
                            value: 'it',
                            child: Text('Italiano'),
                          ),
                          DropdownMenuItem(
                            value: 'pt',
                            child: Text('Português'),
                          ),
                          DropdownMenuItem(value: 'ru', child: Text('Русский')),
                          DropdownMenuItem(value: 'ja', child: Text('日本語')),
                          DropdownMenuItem(value: 'ko', child: Text('한국어')),
                          DropdownMenuItem(value: 'zh', child: Text('中文')),
                          DropdownMenuItem(value: 'tr', child: Text('Türkçe')),
                          DropdownMenuItem(value: 'hi', child: Text('हिन्दी')),
                          DropdownMenuItem(
                            value: 'nl',
                            child: Text('Nederlands'),
                          ),
                          DropdownMenuItem(
                            value: 'id',
                            child: Text('Bahasa Indonesia'),
                          ),
                        ],
                        onChanged: (value) {
                          if (value != null) _changeTargetLanguage(value);
                        },
                      ),
                      TextButton(
                        onPressed: () => setState(
                          () => _captionsVisible = !_captionsVisible,
                        ),
                        child: Text(
                          _captionsVisible ? 'إخفاء النص' : 'إظهار النص',
                        ),
                      ),
                      TextButton(
                        onPressed: () => setState(
                          () => _translationVisible = !_translationVisible,
                        ),
                        child: Text(
                          _translationVisible
                              ? 'إخفاء الترجمة'
                              : 'إظهار الترجمة',
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Icon(Icons.text_fields, size: 18),
                      Expanded(
                        child: Slider(
                          min: 12,
                          max: 24,
                          divisions: 6,
                          value: _captionFontSize,
                          label: _captionFontSize.round().toString(),
                          onChanged: (value) =>
                              setState(() => _captionFontSize = value),
                        ),
                      ),
                      Text(
                        _captionFontSize.round().toString(),
                        style: const TextStyle(color: Colors.white60),
                      ),
                    ],
                  ),
                  if (_captionsVisible)
                    SizedBox(
                      height: (_captions.length * 94.0)
                          .clamp(100.0, 380.0)
                          .toDouble(),
                      child: ListView.builder(
                        itemCount: _captions.length,
                        itemBuilder: (context, index) {
                          final line = _captions[index];
                          final active = index == _activeCaption;
                          final translated = _translated[index];
                          return Card(
                            color: active
                                ? const Color(0xFF302B50)
                                : const Color(0xFF1A1C23),
                            margin: const EdgeInsets.only(bottom: 7),
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(10, 8, 4, 8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Text(
                                    line.text,
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                      fontSize: _captionFontSize,
                                      height: 1.35,
                                    ),
                                  ),
                                  if (_translationVisible &&
                                      translated != null &&
                                      translated.isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Text(
                                        translated,
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                          color: const Color(0xFFFFE27A),
                                          fontSize: _captionFontSize,
                                          height: 1.35,
                                        ),
                                      ),
                                    )
                                  else if (_translationVisible &&
                                      _translationPending.contains(index))
                                    const Padding(
                                      padding: EdgeInsets.only(top: 5),
                                      child: Text(
                                        'جارٍ الترجمة…',
                                        style: TextStyle(color: Colors.white54),
                                      ),
                                    ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      IconButton(
                                        tooltip: 'انتقال إلى توقيت السطر',
                                        visualDensity: VisualDensity.compact,
                                        onPressed: () => _playCaptionAt(index),
                                        icon: const Icon(
                                          Icons.play_arrow,
                                          size: 20,
                                        ),
                                      ),
                                      IconButton(
                                        tooltip: 'نسخ النص',
                                        visualDensity: VisualDensity.compact,
                                        onPressed: () => _copyCaption(index),
                                        icon: const Icon(
                                          Icons.copy_outlined,
                                          size: 18,
                                        ),
                                      ),
                                      IconButton(
                                        tooltip: 'حفظ الإشارة المرجعية',
                                        visualDensity: VisualDensity.compact,
                                        onPressed: () => _saveBookmarkAt(index),
                                        icon: const Icon(
                                          Icons.bookmark_add_outlined,
                                          size: 19,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Text(
                  'الفيديوهات المقترحة',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () => _player.setVolume(100),
                  child: const Text('الصوت'),
                ),
              ],
            ),
          ),
          _RelatedVideos(currentVideo: widget.video),
        ],
      ),
    );
  }
}

class _CaptionTrackSheet extends StatefulWidget {
  const _CaptionTrackSheet({
    required this.videoId,
    required this.onSelect,
    this.selected,
  });

  final String videoId;
  final CaptionTrackOption? selected;
  final void Function(CaptionTrackOption, List<WaleedCaptionLine>) onSelect;

  @override
  State<_CaptionTrackSheet> createState() => _CaptionTrackSheetState();
}

class _CaptionTrackSheetState extends State<_CaptionTrackSheet> {
  late Future<List<CaptionTrackOption>> _tracks;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _tracks = context.read<CaptionService>().listTracks(widget.videoId);
  }

  Future<void> _select(CaptionTrackOption track) async {
    setState(() => _loading = true);
    try {
      final lines = await context.read<CaptionService>().loadTrack(track);
      if (mounted) widget.onSelect(track, lines);
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تحميل مسار الترجمة: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * .72,
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.all(18),
              child: Text(
                'مسارات الترجمة النصية',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            if (_loading) const LinearProgressIndicator(),
            Expanded(
              child: FutureBuilder<List<CaptionTrackOption>>(
                future: _tracks,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return const Center(
                      child: Text('تعذر جلب مسارات الترجمة لهذا الفيديو.'),
                    );
                  }
                  final tracks = snapshot.data ?? const <CaptionTrackOption>[];
                  if (tracks.isEmpty) {
                    return const Center(
                      child: Text('هذا الفيديو لا يحتوي على ترجمة نصية متاحة.'),
                    );
                  }
                  return ListView.builder(
                    itemCount: tracks.length,
                    itemBuilder: (context, index) {
                      final track = tracks[index];
                      return ListTile(
                        leading: const Icon(Icons.subtitles_outlined),
                        title: Text(track.label),
                        subtitle: Text(
                          track.isAutoGenerated
                              ? 'تم إنشاؤها تلقائياً'
                              : 'مسار ترجمة',
                        ),
                        trailing:
                            widget.selected?.languageCode == track.languageCode
                            ? const Icon(Icons.check, color: Color(0xFF8B7CFF))
                            : null,
                        onTap: _loading ? null : () => _select(track),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RelatedVideos extends StatefulWidget {
  const _RelatedVideos({required this.currentVideo});

  final WaleedVideo currentVideo;

  @override
  State<_RelatedVideos> createState() => _RelatedVideosState();
}

class _RelatedVideosState extends State<_RelatedVideos> {
  late Future<List<WaleedVideo>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<WaleedVideo>> _load() async {
    final service = context.read<YoutubeCatalogService>();
    final current = await service.client.videos.get(widget.currentVideo.id);
    final related = await service.client.videos.getRelatedVideos(current);
    if (related == null) return const [];
    final output = <WaleedVideo>[];
    for (final dynamic item in related) {
      try {
        output.add(
          WaleedVideo(
            id: item.id.value as String,
            title: item.title as String,
            channel: item.author as String,
            thumbnailUrl: _thumbnail(item.thumbnails),
            duration: item.duration as Duration?,
          ),
        );
      } catch (_) {}
      if (output.length >= 8) break;
    }
    return output;
  }

  String _thumbnail(dynamic thumbnails) {
    try {
      return thumbnails.highResUrl as String;
    } catch (_) {
      try {
        return thumbnails.mediumResUrl as String;
      } catch (_) {
        return '';
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<WaleedVideo>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Padding(
            padding: EdgeInsets.all(18),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final videos = snapshot.data ?? const <WaleedVideo>[];
        if (videos.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(18),
            child: Text(
              'لا توجد اقتراحات متاحة حالياً.',
              style: TextStyle(color: Colors.white54),
            ),
          );
        }
        return Column(
          children: videos
              .map(
                (video) => ListTile(
                  leading: SizedBox(
                    width: 112,
                    child: VideoThumbnail(url: video.thumbnailUrl, height: 68),
                  ),
                  title: Text(
                    video.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(
                    video.channel,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  onTap: () => Navigator.of(context).pushReplacement(
                    MaterialPageRoute<void>(
                      builder: (_) => PlayerScreen(video: video),
                    ),
                  ),
                ),
              )
              .toList(),
        );
      },
    );
  }
}

class _PlayerAction extends StatelessWidget {
  const _PlayerAction({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 88,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            children: [
              Icon(icon, size: 23, color: const Color(0xFFB8AEFF)),
              const SizedBox(height: 5),
              Text(
                label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SliderSetting extends StatelessWidget {
  const _SliderSetting({
    required this.title,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
  });

  final String title;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text(title)),
            Text(
              value.toStringAsFixed(2),
              style: const TextStyle(color: Colors.white54),
            ),
          ],
        ),
        Slider(
          value: value.clamp(min, max),
          min: min,
          max: max,
          onChanged: onChanged,
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/local_store.dart';
import '../../models/waleed_video.dart';
import '../../widgets/video_list_tile.dart';
import '../player/player_screen.dart';

class PlaylistsTab extends StatelessWidget {
  const PlaylistsTab({super.key});

  Future<void> _renamePlaylist(
    BuildContext context,
    int playlistId,
    String currentName,
  ) async {
    final store = context.read<LocalStore>();
    final name = TextEditingController(text: currentName);
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('إعادة تسمية القائمة'),
        content: TextField(
          controller: name,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم القائمة'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    final newName = name.text.trim();
    name.dispose();
    if (accepted == true && newName.isNotEmpty) {
      await store.renamePlaylist(playlistId, newName);
    }
  }

  Future<void> _createPlaylist(BuildContext context) async {
    final store = context.read<LocalStore>();
    final name = TextEditingController();
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('قائمة تشغيل جديدة'),
        content: TextField(
          controller: name,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم القائمة'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('إنشاء'),
          ),
        ],
      ),
    );
    final createdName = name.text.trim();
    name.dispose();
    if (accepted == true && createdName.isNotEmpty) {
      await store.createPlaylist(createdName);
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LocalStore>();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Row(
            children: [
              const Text(
                'قوائم التشغيل المحفوظة',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5),
              ),
              const Spacer(),
              TextButton.icon(
                onPressed: () => _createPlaylist(context),
                icon: const Icon(Icons.add),
                label: const Text('قائمة جديدة'),
              ),
            ],
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, Object?>>>(
            future: store.loadPlaylists(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting &&
                  !snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return const Center(child: Text('تعذر تحميل قوائم التشغيل.'));
              }
              final playlists = snapshot.data ?? const [];
              if (playlists.isEmpty) {
                return _LibraryEmpty(
                  icon: Icons.queue_music_outlined,
                  message: 'لا توجد قوائم تشغيل بعد',
                  actionLabel: 'إنشاء قائمة تشغيل',
                  onAction: () => _createPlaylist(context),
                );
              }
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 20),
                itemCount: playlists.length,
                separatorBuilder: (_, _) =>
                    const Divider(height: 1, color: Colors.white12),
                itemBuilder: (context, index) {
                  final playlist = playlists[index];
                  final playlistId = playlist['id'] as int;
                  final count = (playlist['video_count'] as num?)?.toInt() ?? 0;
                  return ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xFF7C6CFF),
                      child: Icon(Icons.queue_music, color: Colors.white),
                    ),
                    title: Text(playlist['name'] as String? ?? ''),
                    subtitle: Text('$count فيديو'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          tooltip: 'إعادة تسمية القائمة',
                          icon: const Icon(Icons.edit_outlined),
                          onPressed: () => _renamePlaylist(
                            context,
                            playlistId,
                            playlist['name'] as String? ?? '',
                          ),
                        ),
                        IconButton(
                          tooltip: 'حذف القائمة',
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => store.deletePlaylist(playlistId),
                        ),
                      ],
                    ),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => PlaylistDetailsScreen(
                          playlistId: playlistId,
                          title: playlist['name'] as String? ?? '',
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class PlaylistDetailsScreen extends StatelessWidget {
  const PlaylistDetailsScreen({
    required this.playlistId,
    required this.title,
    super.key,
  });

  final int playlistId;
  final String title;

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LocalStore>();
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: FutureBuilder<List<WaleedVideo>>(
        future: store.loadPlaylistVideos(playlistId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting &&
              !snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('تعذر تحميل القائمة.'));
          }
          final videos = snapshot.data ?? const <WaleedVideo>[];
          if (videos.isEmpty) {
            return const _LibraryEmpty(
              icon: Icons.queue_music_outlined,
              message: 'لا توجد فيديوهات في هذه القائمة',
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: videos.length,
            separatorBuilder: (_, _) =>
                const Divider(height: 16, color: Colors.white12),
            itemBuilder: (context, index) => Row(
              children: [
                Expanded(
                  child: VideoListTile(
                    video: videos[index],
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => PlayerScreen(video: videos[index]),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'إزالة من قائمة التشغيل',
                  icon: const Icon(Icons.remove_circle_outline),
                  onPressed: () =>
                      store.removeFromPlaylist(playlistId, videos[index].id),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class RecentTab extends StatelessWidget {
  const RecentTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LocalStore>();
    return FutureBuilder<List<WaleedVideo>>(
      future: store.loadRecent(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting &&
            !snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return const Center(child: Text('تعذر تحميل الفيديوهات الأخيرة.'));
        }
        final videos = snapshot.data ?? const <WaleedVideo>[];
        if (videos.isEmpty) {
          return const _LibraryEmpty(
            icon: Icons.history,
            message: 'لا توجد فيديوهات في سجل المشاهدة بعد',
          );
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: Row(
                children: [
                  Text(
                    'آخر المشاهدات (${videos.length})',
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 13.5,
                    ),
                  ),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: store.clearAllRecent,
                    icon: const Icon(Icons.clear_all, size: 18),
                    label: const Text('مسح السجل'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 20),
                itemCount: videos.length,
                separatorBuilder: (_, _) =>
                    const Divider(height: 14, color: Colors.white12),
                itemBuilder: (context, index) {
                  final video = videos[index];
                  return VideoListTile(
                    video: video,
                    onRemoveFromHistory: () => store.deleteRecent(video.id),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => PlayerScreen(
                          video: video,
                          initialPosition: Duration(
                            milliseconds: video.lastPositionMs,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

class _LibraryEmpty extends StatelessWidget {
  const _LibraryEmpty({
    required this.icon,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 46, color: Colors.white38),
          const SizedBox(height: 12),
          Text(message, style: const TextStyle(color: Colors.white70)),
          if (actionLabel != null && onAction != null) ...[
            const SizedBox(height: 14),
            FilledButton.tonalIcon(
              onPressed: onAction,
              icon: const Icon(Icons.add),
              label: Text(actionLabel!),
            ),
          ],
        ],
      ),
    );
  }
}

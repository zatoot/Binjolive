import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/local_store.dart';
import '../../models/waleed_video.dart';
import '../player/player_screen.dart';
import '../../widgets/video_list_tile.dart';

class PlaylistsTab extends StatefulWidget {
  const PlaylistsTab({super.key});

  @override
  State<PlaylistsTab> createState() => _PlaylistsTabState();
}

class _PlaylistsTabState extends State<PlaylistsTab> {
  late Future<List<Map<String, Object?>>> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<LocalStore>().loadPlaylists();
  }

  Future<void> _refresh() async {
    setState(() => _future = context.read<LocalStore>().loadPlaylists());
    await _future;
  }

  Future<void> _renamePlaylist(int playlistId, String currentName) async {
    final store = context.read<LocalStore>();
    final name = TextEditingController(text: currentName);
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('إعادة تسمية القائمة'),
        content: TextField(
          controller: name,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم القائمة'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    if (accepted == true && name.text.trim().isNotEmpty) {
      await store.renamePlaylist(playlistId, name.text.trim());
      if (!mounted) {
        name.dispose();
        return;
      }
      setState(() => _future = store.loadPlaylists());
      await _future;
    }
    name.dispose();
  }

  Future<void> _createPlaylist() async {
    final store = context.read<LocalStore>();
    final name = TextEditingController();
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('قائمة تشغيل جديدة'),
        content: TextField(
          controller: name,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم القائمة'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('إنشاء'),
          ),
        ],
      ),
    );
    if (accepted == true && name.text.trim().isNotEmpty) {
      await store.createPlaylist(name.text.trim());
      if (!mounted) return;
      setState(() => _future = store.loadPlaylists());
      await _future;
    }
    name.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: AlignmentDirectional.centerEnd,
          child: TextButton.icon(
            onPressed: _createPlaylist,
            icon: const Icon(Icons.add),
            label: const Text('قائمة جديدة'),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, Object?>>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return const Center(child: Text('تعذر تحميل قوائم التشغيل.'));
              }
              final playlists = snapshot.data ?? const [];
              if (playlists.isEmpty) {
                return const _LibraryEmpty(
                  icon: Icons.queue_music_outlined,
                  message: 'لا توجد فيديوهات',
                );
              }
              return RefreshIndicator(
                onRefresh: _refresh,
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 20),
                  itemCount: playlists.length,
                  separatorBuilder: (_, _) =>
                      const Divider(height: 1, color: Colors.white12),
                  itemBuilder: (context, index) {
                    final playlist = playlists[index];
                    final playlistId = playlist['id'] as int;
                    return ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: Color(0xFF292B34),
                        child: Icon(Icons.queue_music),
                      ),
                      title: Text(playlist['name'] as String? ?? ''),
                      subtitle: const Text('قائمة وليد'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            tooltip: 'إعادة تسمية القائمة',
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () => _renamePlaylist(
                              playlistId,
                              playlist['name'] as String? ?? '',
                            ),
                          ),
                          IconButton(
                            tooltip: 'حذف القائمة',
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              await context.read<LocalStore>().deletePlaylist(
                                playlistId,
                              );
                              await _refresh();
                            },
                          ),
                        ],
                      ),
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => PlaylistDetailsScreen(
                            playlistId: playlistId,
                            title: playlist['name'] as String? ?? '',
                          ),
                        ),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class PlaylistDetailsScreen extends StatefulWidget {
  const PlaylistDetailsScreen({
    required this.playlistId,
    required this.title,
    super.key,
  });

  final int playlistId;
  final String title;

  @override
  State<PlaylistDetailsScreen> createState() => _PlaylistDetailsScreenState();
}

class _PlaylistDetailsScreenState extends State<PlaylistDetailsScreen> {
  late Future<List<WaleedVideo>> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<LocalStore>().loadPlaylistVideos(widget.playlistId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: FutureBuilder<List<WaleedVideo>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('تعذر تحميل القائمة.'));
          }
          final videos = snapshot.data ?? const <WaleedVideo>[];
          if (videos.isEmpty) {
            return const _LibraryEmpty(
              icon: Icons.queue_music_outlined,
              message: 'لا توجد فيديوهات',
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: videos.length,
            separatorBuilder: (_, _) =>
                const Divider(height: 16, color: Colors.white12),
            itemBuilder: (context, index) => Row(
              children: [
                Expanded(
                  child: VideoListTile(
                    video: videos[index],
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => PlayerScreen(video: videos[index]),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'إزالة من قائمة التشغيل',
                  icon: const Icon(Icons.remove_circle_outline),
                  onPressed: () async {
                    await context.read<LocalStore>().removeFromPlaylist(
                      widget.playlistId,
                      videos[index].id,
                    );
                    if (!mounted) return;
                    setState(() {
                      _future = context.read<LocalStore>().loadPlaylistVideos(
                        widget.playlistId,
                      );
                    });
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class RecentTab extends StatefulWidget {
  const RecentTab({super.key});

  @override
  State<RecentTab> createState() => _RecentTabState();
}

class _RecentTabState extends State<RecentTab> {
  late Future<List<WaleedVideo>> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<LocalStore>().loadRecent();
  }

  Future<void> _refresh() async {
    setState(() => _future = context.read<LocalStore>().loadRecent());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<WaleedVideo>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return const Center(child: Text('تعذر تحميل الفيديوهات الأخيرة.'));
        }
        final videos = snapshot.data ?? const <WaleedVideo>[];
        if (videos.isEmpty) {
          return const _LibraryEmpty(
            icon: Icons.history,
            message: 'لا توجد فيديوهات',
          );
        }
        return RefreshIndicator(
          onRefresh: _refresh,
          child: ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: videos.length,
            separatorBuilder: (_, _) =>
                const Divider(height: 16, color: Colors.white12),
            itemBuilder: (context, index) => VideoListTile(
              video: videos[index],
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => PlayerScreen(video: videos[index]),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _LibraryEmpty extends StatelessWidget {
  const _LibraryEmpty({required this.icon, required this.message});

  final IconData icon;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 42, color: Colors.white38),
          const SizedBox(height: 12),
          Text(message, style: const TextStyle(color: Colors.white70)),
        ],
      ),
    );
  }
}

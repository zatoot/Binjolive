import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/local_store.dart';

import '../../models/waleed_video.dart';
import 'videos_library_tabs.dart';
import '../../services/youtube_catalog_service.dart';
import '../../widgets/video_list_tile.dart';
import '../player/player_screen.dart';
import '../search/video_search_screen.dart';

class VideosScreen extends StatelessWidget {
  const VideosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const VideoSearchScreen(),
                ),
              ),
              child: Container(
                height: 52,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1C23),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.search, color: Colors.white70),
                    SizedBox(width: 12),
                    Text(
                      'ابحث عن فيديوهات',
                      style: TextStyle(color: Colors.white70),
                    ),
                    Spacer(),
                    Icon(Icons.tune, color: Colors.white54),
                  ],
                ),
              ),
            ),
          ),
          const TabBar(
            tabs: [
              Tab(text: 'من أجلك'),
              Tab(text: 'قوائم التشغيل'),
              Tab(text: 'الأخيرة'),
            ],
          ),
          const Expanded(
            child: TabBarView(
              children: [_ForYouFeed(), PlaylistsTab(), RecentTab()],
            ),
          ),
        ],
      ),
    );
  }
}

class _ForYouFeed extends StatefulWidget {
  const _ForYouFeed();

  @override
  State<_ForYouFeed> createState() => _ForYouFeedState();
}

class _ForYouFeedState extends State<_ForYouFeed> {
  late Future<List<WaleedVideo>> _future;

  @override
  void initState() {
    super.initState();
    _future = _loadFeed();
  }

  Future<List<WaleedVideo>> _loadFeed() async {
    final store = context.read<LocalStore>();
    final catalog = context.read<YoutubeCatalogService>();
    final recent = await store.loadRecent();
    return catalog.loadForYouFeed(recent: recent);
  }

  Future<void> _refresh() async {
    setState(() => _future = _loadFeed());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<WaleedVideo>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return _FeedMessage(
            message: 'تعذر تحميل الفيديوهات. تحقق من الاتصال وحاول مجدداً.',
            onRetry: _refresh,
          );
        }
        final videos = snapshot.data ?? const <WaleedVideo>[];
        if (videos.isEmpty) {
          return _FeedMessage(
            message: 'لم تصل نتائج فيديوهات حالياً.',
            onRetry: _refresh,
          );
        }
        return RefreshIndicator(
          onRefresh: _refresh,
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 20),
            itemCount: videos.length,
            separatorBuilder: (_, _) => const SizedBox(height: 12),
            itemBuilder: (context, index) => VideoListTile(
              video: videos[index],
              onTap: () => _openVideo(context, videos[index]),
            ),
          ),
        );
      },
    );
  }

  void _openVideo(BuildContext context, WaleedVideo video) {
    Navigator.of(
      context,
    ).push(MaterialPageRoute<void>(builder: (_) => PlayerScreen(video: video)));
  }
}

class _FeedMessage extends StatelessWidget {
  const _FeedMessage({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/app_settings.dart';
import '../../data/local_store.dart';
import '../../models/waleed_video.dart';
import '../../services/caption_service.dart';
import '../../services/youtube_catalog_service.dart';
import '../../widgets/video_list_tile.dart';
import '../player/player_screen.dart';
import '../search/video_search_screen.dart';
import 'videos_library_tabs.dart';

class VideosScreen extends StatelessWidget {
  const VideosScreen({this.onPasteLink, super.key});

  final VoidCallback? onPasteLink;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 10),
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const VideoSearchScreen(),
                      ),
                    ),
                    child: Container(
                      height: 48,
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: isDark
                            ? const Color(0xFF181B24)
                            : Colors.black.withValues(alpha: 0.06),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.search_rounded,
                            color: isDark ? Colors.white70 : Colors.black54,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'ابحث عن فيديوهات أو الصق رابطاً...',
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: isDark ? Colors.white70 : Colors.black54,
                                fontSize: 13.5,
                              ),
                            ),
                          ),
                          Icon(
                            Icons.tune_rounded,
                            size: 20,
                            color: isDark ? Colors.white54 : Colors.black45,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                if (onPasteLink != null) ...[
                  const SizedBox(width: 8),
                  IconButton.filledTonal(
                    tooltip: 'لصق رابط YouTube',
                    onPressed: onPasteLink,
                    icon: const Icon(Icons.content_paste_go_rounded),
                  ),
                ],
              ],
            ),
          ),
          const TabBar(
            tabs: [
              Tab(text: 'من أجلك'),
              Tab(text: 'قوائم التشغيل'),
              Tab(text: 'الأخيرة'),
            ],
          ),
          const Expanded(
            child: TabBarView(
              children: [_ForYouFeed(), PlaylistsTab(), RecentTab()],
            ),
          ),
        ],
      ),
    );
  }
}

class _ForYouFeed extends StatefulWidget {
  const _ForYouFeed();

  @override
  State<_ForYouFeed> createState() => _ForYouFeedState();
}

class _ForYouFeedState extends State<_ForYouFeed>
    with AutomaticKeepAliveClientMixin {
  String _selectedCategoryId = 'all';
  Future<List<WaleedVideo>>? _future;
  final Map<String, String> _translatedTitles = {};

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _future = _loadFeed();
  }

  Future<List<WaleedVideo>> _loadFeed() async {
    final store = context.read<LocalStore>();
    final catalog = context.read<YoutubeCatalogService>();
    final captions = context.read<CaptionService>();
    final settings = context.read<AppSettings>();
    final shouldTranslate = settings.translateTitles;
    final targetLang = settings.targetLanguageCode;

    final recent = await store.loadRecent();
    final videos = await catalog.loadForYouFeed(
      recent: recent,
      categoryId: _selectedCategoryId,
      limit: 24,
    );

    if (shouldTranslate && mounted) {
      unawaited(_translateFeedTitles(videos, captions, targetLang));
    }
    return videos;
  }

  Future<void> _translateFeedTitles(
    List<WaleedVideo> videos,
    CaptionService captions,
    String targetLang,
  ) async {
    final lines = videos
        .map(
          (v) => WaleedCaptionLine(
            text: v.title,
            offset: Duration.zero,
            duration: const Duration(seconds: 1),
          ),
        )
        .toList();
    final indices = List<int>.generate(lines.length, (i) => i);
    try {
      final batch = await captions.translateBatch(
        lines: lines,
        indices: indices,
        sourceCode: 'auto',
        targetCode: targetLang,
      );
      if (!mounted) return;
      setState(() {
        for (final entry in batch.entries) {
          if (entry.key >= 0 && entry.key < videos.length) {
            _translatedTitles[videos[entry.key].id] = entry.value;
          }
        }
      });
    } catch (_) {}
  }

  Future<void> _refresh() async {
    setState(() => _future = _loadFeed());
    await _future;
  }

  void _selectCategory(String id) {
    if (_selectedCategoryId == id) return;
    setState(() {
      _selectedCategoryId = id;
      _future = _loadFeed();
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final translateTitles = context.watch<AppSettings>().translateTitles;

    return Column(
      children: [
        SizedBox(
          height: 48,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            scrollDirection: Axis.horizontal,
            itemCount: YoutubeCatalogService.categories.length,
            separatorBuilder: (_, _) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final cat = YoutubeCatalogService.categories[index];
              final selected = cat.id == _selectedCategoryId;
              return ChoiceChip(
                label: Text(cat.label),
                selected: selected,
                onSelected: (_) => _selectCategory(cat.id),
              );
            },
          ),
        ),
        Expanded(
          child: FutureBuilder<List<WaleedVideo>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return _FeedMessage(
                  message: 'تعذر تحميل الفيديوهات. تحقق من الاتصال وحاول مجدداً.',
                  onRetry: _refresh,
                );
              }
              final videos = snapshot.data ?? const <WaleedVideo>[];
              if (videos.isEmpty) {
                return _FeedMessage(
                  message: 'لم تصل نتائج فيديوهات حالياً.',
                  onRetry: _refresh,
                );
              }
              return RefreshIndicator(
                onRefresh: _refresh,
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
                  itemCount: videos.length,
                  separatorBuilder: (_, _) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final video = videos[index];
                    return VideoListTile(
                      video: video,
                      titleOverride: translateTitles
                          ? _translatedTitles[video.id]
                          : null,
                      onTap: () => _openVideo(context, video),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  void _openVideo(BuildContext context, WaleedVideo video) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => PlayerScreen(video: video)),
    );
  }
}

class _FeedMessage extends StatelessWidget {
  const _FeedMessage({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }
}

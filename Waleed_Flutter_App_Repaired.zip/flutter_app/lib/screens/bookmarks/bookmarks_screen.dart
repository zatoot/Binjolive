import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../data/local_store.dart';
import '../../models/waleed_video.dart';
import '../player/player_screen.dart';

class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({super.key});

  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  final TextEditingController _search = TextEditingController();

  @override
  void initState() {
    super.initState();
    _search.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _export(BuildContext context) async {
    final rows = await context.read<LocalStore>().loadBookmarks();
    if (rows.isEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('لا توجد إشارات مرجعية لتصديرها.')),
        );
      }
      return;
    }
    final buffer = StringBuffer(
      'Video Title,Video Id,Video Url,Bookmark Time,Original Text,Translated Text,Note\n',
    );
    for (final row in rows) {
      String csv(Object? value) {
        final raw = (value ?? '').toString().replaceAll('"', '""');
        return '"$raw"';
      }

      final videoId = row['video_id'] as String? ?? '';
      final time = Duration(milliseconds: row['position_ms'] as int? ?? 0);
      buffer.writeln(
        [
          csv(row['video_title']),
          csv(videoId),
          csv('https://www.youtube.com/watch?v=$videoId'),
          csv(_formatDuration(time)),
          csv(row['original_text']),
          csv(row['translated_text']),
          csv(row['note']),
        ].join(','),
      );
    }
    await SharePlus.instance.share(
      ShareParams(title: 'إشارات وليد المرجعية', text: buffer.toString()),
    );
  }

  static Future<void> showEditBookmarkDialog(
    BuildContext context,
    Map<String, Object?> row,
  ) async {
    final store = context.read<LocalStore>();
    final original = TextEditingController(
      text: row['original_text'] as String? ?? '',
    );
    final translated = TextEditingController(
      text: row['translated_text'] as String? ?? '',
    );
    final note = TextEditingController(text: row['note'] as String? ?? '');

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تعديل الإشارة المرجعية'),
        content: SizedBox(
          width: 480,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: original,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'الترجمة النصية الأصلية',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: translated,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: 'الترجمة'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: note,
                  minLines: 1,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'ملاحظة',
                    hintText: 'أدخل ملاحظة هنا',
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );

    if (saved == true) {
      await store.updateBookmark(
        id: row['id'] as int,
        originalText: original.text,
        translatedText: translated.text,
        note: note.text,
      );
    }
    original.dispose();
    translated.dispose();
    note.dispose();
  }

  static String _formatDuration(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    if (d.inHours > 0) {
      return '${d.inHours}:${two(d.inMinutes.remainder(60))}:${two(d.inSeconds.remainder(60))}';
    }
    return '${two(d.inMinutes)}:${two(d.inSeconds.remainder(60))}';
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LocalStore>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 8, 8, 10),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _search,
                  decoration: InputDecoration(
                    hintText: 'ابحث عن الإشارات المرجعية...',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: _search.text.isNotEmpty
                        ? IconButton(
                            onPressed: _search.clear,
                            icon: const Icon(Icons.close, size: 18),
                          )
                        : null,
                    filled: true,
                    fillColor: isDark
                        ? const Color(0xFF181B24)
                        : Colors.black.withValues(alpha: 0.06),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              IconButton(
                tooltip: 'تصدير الإشارات المرجعية',
                onPressed: () => _export(context),
                icon: const Icon(Icons.ios_share_outlined),
              ),
            ],
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, Object?>>>(
            future: store.loadBookmarks(query: _search.text),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting &&
                  !snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return const Center(
                  child: Text('تعذر تحميل الإشارات المرجعية.'),
                );
              }
              final rows = snapshot.data ?? const [];
              if (rows.isEmpty) {
                return const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.bookmarks_outlined,
                        size: 44,
                        color: Colors.white38,
                      ),
                      SizedBox(height: 12),
                      Text('لا توجد إشارات مرجعية'),
                    ],
                  ),
                );
              }
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 24),
                itemCount: rows.length,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final row = rows[index];
                  return _BookmarkCard(
                    row: row,
                    onEdit: () => showEditBookmarkDialog(context, row),
                    onDelete: () => store.removeBookmark(row['id'] as int),
                    onPlayAtTimestamp: () {
                      final videoId = row['video_id'] as String;
                      final video = WaleedVideo(
                        id: videoId,
                        title: row['video_title'] as String? ?? '',
                        channel: row['channel'] as String? ?? '',
                        thumbnailUrl:
                            'https://i.ytimg.com/vi/$videoId/hqdefault.jpg',
                      );
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => PlayerScreen(
                            video: video,
                            initialPosition: Duration(
                              milliseconds: row['position_ms'] as int? ?? 0,
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class _BookmarkCard extends StatelessWidget {
  const _BookmarkCard({
    required this.row,
    required this.onEdit,
    required this.onDelete,
    required this.onPlayAtTimestamp,
  });

  final Map<String, Object?> row;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onPlayAtTimestamp;

  String _formatPos(int ms) {
    final d = Duration(milliseconds: ms);
    String two(int n) => n.toString().padLeft(2, '0');
    if (d.inHours > 0) {
      return '${d.inHours}:${two(d.inMinutes.remainder(60))}:${two(d.inSeconds.remainder(60))}';
    }
    return '${two(d.inMinutes)}:${two(d.inSeconds.remainder(60))}';
  }

  @override
  Widget build(BuildContext context) {
    final original = row['original_text'] as String? ?? '';
    final translated = row['translated_text'] as String? ?? '';
    final note = row['note'] as String? ?? '';
    final posMs = row['position_ms'] as int? ?? 0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFF7C6CFF).withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _formatPos(posMs),
                    style: const TextStyle(
                      color: Color(0xFF9E92FF),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    row['video_title'] as String? ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 13.5,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              original,
              style: const TextStyle(fontSize: 14, height: 1.35),
            ),
            if (translated.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                translated,
                style: const TextStyle(
                  color: Color(0xFFFFE082),
                  fontSize: 14.5,
                  fontWeight: FontWeight.w600,
                  height: 1.35,
                ),
              ),
            ],
            if (note.isNotEmpty) ...[
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'ملاحظة: $note',
                  style: const TextStyle(fontSize: 12.5, color: Colors.white70),
                ),
              ),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                FilledButton.tonalIcon(
                  onPressed: onPlayAtTimestamp,
                  icon: const Icon(Icons.play_arrow, size: 18),
                  label: const Text('تشغيل المقطع'),
                ),
                const Spacer(),
                IconButton(
                  tooltip: 'تعديل',
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit_outlined, size: 20),
                ),
                IconButton(
                  tooltip: 'حذف',
                  onPressed: onDelete,
                  icon: const Icon(
                    Icons.delete_outline,
                    size: 20,
                    color: Colors.redAccent,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

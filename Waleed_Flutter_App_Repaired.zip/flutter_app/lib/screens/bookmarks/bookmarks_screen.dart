import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../data/local_store.dart';
import '../../models/waleed_video.dart';
import '../player/player_screen.dart';

class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({super.key});

  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  final TextEditingController _search = TextEditingController();
  late Future<List<Map<String, Object?>>> _items;

  @override
  void initState() {
    super.initState();
    _items = _load();
    _search.addListener(_refresh);
  }

  Future<List<Map<String, Object?>>> _load() {
    return context.read<LocalStore>().loadBookmarks(query: _search.text);
  }

  void _refresh() {
    if (!mounted) return;
    setState(() => _items = _load());
  }

  @override
  void dispose() {
    _search.removeListener(_refresh);
    _search.dispose();
    super.dispose();
  }

  Future<void> _export() async {
    final rows = await context.read<LocalStore>().loadBookmarks();
    if (rows.isEmpty) {
      _message('لا توجد إشارات مرجعية لتصديرها.');
      return;
    }
    final buffer = StringBuffer(
      'Video Title,Video ID,Bookmark Time,Original Text,Translated Text,Note\n',
    );
    for (final row in rows) {
      String csv(Object? value) {
        final raw = (value ?? '').toString().replaceAll('"', '""');
        return '"$raw"';
      }

      final time = Duration(milliseconds: row['position_ms'] as int? ?? 0);
      buffer.writeln(
        [
          csv(row['video_title']),
          csv(row['video_id']),
          csv(time.toString()),
          csv(row['original_text']),
          csv(row['translated_text']),
          csv(row['note']),
        ].join(','),
      );
    }
    await SharePlus.instance.share(
      ShareParams(title: 'إشارات وليد المرجعية', text: buffer.toString()),
    );
  }

  Future<void> _edit(Map<String, Object?> row) async {
    final store = context.read<LocalStore>();
    final original = TextEditingController(
      text: row['original_text'] as String? ?? '',
    );
    final translated = TextEditingController(
      text: row['translated_text'] as String? ?? '',
    );
    final note = TextEditingController(text: row['note'] as String? ?? '');
    final form = GlobalKey<FormState>();
    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تعديل الإشارة المرجعية'),
        content: SizedBox(
          width: 520,
          child: Form(
            key: form,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: original,
                    minLines: 2,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      labelText: 'الترجمة النصية الأصلية',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: translated,
                    minLines: 2,
                    maxLines: 4,
                    decoration: const InputDecoration(labelText: 'الترجمة'),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: note,
                    minLines: 1,
                    maxLines: 3,
                    decoration: const InputDecoration(labelText: 'ملاحظة'),
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    if (saved == true) {
      await store.updateBookmark(
        id: row['id'] as int,
        originalText: original.text,
        translatedText: translated.text,
        note: note.text,
      );
      _refresh();
    }
    original.dispose();
    translated.dispose();
    note.dispose();
  }

  Future<void> _remove(Map<String, Object?> row) async {
    final store = context.read<LocalStore>();
    final okay = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إزالة الإشارة المرجعية؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('إزالة'),
          ),
        ],
      ),
    );
    if (okay == true) {
      await store.removeBookmark(row['id'] as int);
      _refresh();
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 8, 8, 10),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _search,
                  decoration: InputDecoration(
                    hintText: 'ابحث عن الإشارات المرجعية',
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: const Color(0xFF1A1C23),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              IconButton(
                tooltip: 'تصدير الإشارات المرجعية',
                onPressed: _export,
                icon: const Icon(Icons.ios_share_outlined),
              ),
            ],
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, Object?>>>(
            future: _items,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return const Center(
                  child: Text('تعذر تحميل الإشارات المرجعية.'),
                );
              }
              final rows = snapshot.data ?? const [];
              if (rows.isEmpty) {
                return const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.bookmarks_outlined,
                        size: 42,
                        color: Colors.white38,
                      ),
                      SizedBox(height: 12),
                      Text('لا توجد إشارات مرجعية'),
                    ],
                  ),
                );
              }
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 20),
                itemCount: rows.length,
                separatorBuilder: (_, _) =>
                    const Divider(height: 16, color: Colors.white12),
                itemBuilder: (context, index) {
                  final row = rows[index];
                  return _BookmarkCard(
                    row: row,
                    onEdit: () => _edit(row),
                    onDelete: () => _remove(row),
                    onPlay: () {
                      final video = WaleedVideo(
                        id: row['video_id'] as String,
                        title: row['video_title'] as String? ?? '',
                        channel: row['channel'] as String? ?? '',
                        thumbnailUrl:
                            'https://i.ytimg.com/vi/${row['video_id']}/hqdefault.jpg',
                      );
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => PlayerScreen(
                            video: video,
                            initialPosition: Duration(
                              milliseconds: row['position_ms'] as int? ?? 0,
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class _BookmarkCard extends StatelessWidget {
  const _BookmarkCard({
    required this.row,
    required this.onEdit,
    required this.onDelete,
    required this.onPlay,
  });

  final Map<String, Object?> row;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onPlay;

  @override
  Widget build(BuildContext context) {
    final original = row['original_text'] as String? ?? '';
    final translated = row['translated_text'] as String? ?? '';
    final note = row['note'] as String? ?? '';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              row['video_title'] as String? ?? '',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(original, style: const TextStyle(color: Colors.white70)),
            if (translated.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                translated,
                style: const TextStyle(color: Color(0xFFFFE27A)),
              ),
            ],
            if (note.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                'ملاحظة: $note',
                style: const TextStyle(color: Colors.white54),
              ),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                TextButton.icon(
                  onPressed: onPlay,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('تشغيل'),
                ),
                const Spacer(),
                IconButton(
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit_outlined),
                ),
                IconButton(
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/app_settings.dart';
import '../../data/local_store.dart';
import '../../models/waleed_video.dart';
import '../../services/caption_service.dart';
import '../../services/youtube_catalog_service.dart';
import '../../widgets/video_list_tile.dart';
import '../player/player_screen.dart';

class VideoSearchScreen extends StatefulWidget {
  const VideoSearchScreen({super.key});

  @override
  State<VideoSearchScreen> createState() => _VideoSearchScreenState();
}

class _VideoSearchScreenState extends State<VideoSearchScreen> {
  final TextEditingController _query = TextEditingController();
  Future<List<WaleedVideo>>? _results;
  bool _captionsOnly = true;
  bool _translateQuery = false;
  String _searchTargetLang = 'en';
  bool _busy = false;
  String? _translatedQueryPreview;
  final Map<String, String> _translatedTitles = {};

  @override
  void initState() {
    super.initState();
    _query.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  Future<void> _search([String? customQuery]) async {
    if (customQuery != null) {
      _query.text = customQuery;
    }
    final raw = _query.text.trim();
    if (raw.isEmpty || _busy) return;

    // If user pasted a direct YouTube link, open it immediately in PlayerScreen
    final directId = WaleedVideo.tryExtractVideoId(raw);
    if (directId != null && raw.contains('http')) {
      final video = WaleedVideo(
        id: directId,
        title: 'فيديو من YouTube',
        channel: 'YouTube',
        thumbnailUrl: 'https://i.ytimg.com/vi/$directId/hqdefault.jpg',
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => PlayerScreen(video: video)),
      );
      return;
    }

    final store = context.read<LocalStore>();
    final captionService = context.read<CaptionService>();
    final catalog = context.read<YoutubeCatalogService>();
    final settings = context.read<AppSettings>();
    final translateQuery = _translateQuery;
    final captionsOnly = _captionsOnly;
    final translateTitles = settings.translateTitles;
    final targetLang = settings.targetLanguageCode;

    unawaited(store.saveSearchQuery(raw));
    FocusScope.of(context).unfocus();

    setState(() {
      _busy = true;
      _translatedQueryPreview = null;
    });

    try {
      var effectiveQuery = raw;
      if (translateQuery) {
        try {
          effectiveQuery = await captionService.translateLine(
            text: raw,
            sourceCode: 'auto',
            targetCode: _searchTargetLang,
          );
          if (mounted) {
            setState(() => _translatedQueryPreview = effectiveQuery);
          }
        } catch (_) {}
      }

      final videos = await catalog.searchVideos(
        effectiveQuery,
        captionsOnly: captionsOnly,
        limit: 30,
      );

      _translatedTitles.clear();
      if (!mounted) return;
      setState(() => _results = Future.value(videos));

      if (translateTitles && videos.isNotEmpty) {
        final lines = videos
            .map(
              (v) => WaleedCaptionLine(
                text: v.title,
                offset: Duration.zero,
                duration: const Duration(seconds: 1),
              ),
            )
            .toList();
        final indices = List<int>.generate(lines.length, (i) => i);
        unawaited(
          captionService
              .translateBatch(
                lines: lines,
                indices: indices,
                sourceCode: 'auto',
                targetCode: targetLang,
              )
              .then((batch) {
                if (!mounted) return;
                setState(() {
                  for (final entry in batch.entries) {
                    if (entry.key >= 0 && entry.key < videos.length) {
                      _translatedTitles[videos[entry.key].id] = entry.value;
                    }
                  }
                });
              })
              .catchError((_) {}),
        );
      }
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _results = Future.error(error);
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openFilters() async {
    var captions = _captionsOnly;
    var translate = _translateQuery;
    var lang = _searchTargetLang;
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, update) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'إعدادات البحث',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('مع ترجمة نصية فقط (Subtitles/CC)'),
                  value: captions,
                  onChanged: (value) => update(() => captions = value),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('ترجمة عبارة البحث تلقائياً'),
                  value: translate,
                  onChanged: (value) => update(() => translate = value),
                ),
                if (translate)
                  DropdownButtonFormField<String>(
                    initialValue: lang,
                    decoration: const InputDecoration(
                      labelText: 'ترجمة البحث إلى لغة',
                    ),
                    items: AppSettings.supportedLanguages
                        .map(
                          (item) => DropdownMenuItem<String>(
                            value: item.code,
                            child: Text('${item.arabicName} (${item.nativeName})'),
                          ),
                        )
                        .toList(),
                    onChanged: (val) {
                      if (val != null) update(() => lang = val);
                    },
                  ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    TextButton(
                      onPressed: () => Navigator.pop(sheetContext),
                      child: const Text('إلغاء'),
                    ),
                    const Spacer(),
                    FilledButton(
                      onPressed: () {
                        setState(() {
                          _captionsOnly = captions;
                          _translateQuery = translate;
                          _searchTargetLang = lang;
                        });
                        Navigator.pop(sheetContext);
                        if (_query.text.trim().isNotEmpty) _search();
                      },
                      child: const Text('تطبيق'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(title: const Text('ابحث عن فيديوهات')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _query,
                    autofocus: true,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _search(),
                    decoration: InputDecoration(
                      hintText: 'ابحث عن موضوع أو الصق رابط YouTube...',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: _query.text.isNotEmpty
                          ? IconButton(
                              tooltip: 'مسح',
                              onPressed: () {
                                _query.clear();
                                setState(() {
                                  _results = null;
                                  _translatedQueryPreview = null;
                                });
                              },
                              icon: const Icon(Icons.close, size: 19),
                            )
                          : null,
                      filled: true,
                      fillColor: isDark
                          ? const Color(0xFF181B24)
                          : Colors.black.withValues(alpha: 0.06),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(
                  onPressed: _openFilters,
                  icon: const Icon(Icons.tune),
                  tooltip: 'إعدادات البحث',
                ),
                const SizedBox(width: 4),
                IconButton.filled(
                  onPressed: _busy ? null : () => _search(),
                  icon: const Icon(Icons.arrow_forward),
                  tooltip: 'بحث',
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
            child: Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                FilterChip(
                  label: const Text('مع ترجمة نصية'),
                  selected: _captionsOnly,
                  onSelected: (v) {
                    setState(() => _captionsOnly = v);
                    if (_query.text.trim().isNotEmpty) _search();
                  },
                ),
                FilterChip(
                  label: Text(
                    _translateQuery
                        ? 'ترجمة البحث (${_searchTargetLang.toUpperCase()})'
                        : 'ترجمة عبارة البحث',
                  ),
                  selected: _translateQuery,
                  onSelected: (v) {
                    setState(() => _translateQuery = v);
                    if (_query.text.trim().isNotEmpty) _search();
                  },
                ),
                if (_translatedQueryPreview != null)
                  Chip(
                    avatar: const Icon(Icons.translate, size: 16),
                    label: Text('عرض النتائج لـ: $_translatedQueryPreview'),
                  ),
              ],
            ),
          ),
          Expanded(
            child: _busy && _results == null
                ? const Center(child: CircularProgressIndicator())
                : _results == null
                ? _SearchIntro(onSelectQuery: _search)
                : FutureBuilder<List<WaleedVideo>>(
                    future: _results,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting ||
                          _busy) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (snapshot.hasError) {
                        return _SearchMessage(
                          icon: Icons.cloud_off_outlined,
                          message: 'تعذر تنفيذ البحث حالياً. تحقق من الاتصال وحاول مجدداً.',
                          action: FilledButton.tonal(
                            onPressed: () => _search(),
                            child: const Text('إعادة المحاولة'),
                          ),
                        );
                      }
                      final videos = snapshot.data ?? const <WaleedVideo>[];
                      if (videos.isEmpty) {
                        return const _SearchMessage(
                          icon: Icons.search_off,
                          message: 'لم يتم العثور على نتائج مطابقة',
                        );
                      }
                      return ListView.separated(
                        padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
                        itemCount: videos.length,
                        separatorBuilder: (_, _) =>
                            const Divider(height: 16, color: Colors.white12),
                        itemBuilder: (context, index) => VideoListTile(
                          video: videos[index],
                          titleOverride: _translatedTitles[videos[index].id],
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) =>
                                  PlayerScreen(video: videos[index]),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _SearchIntro extends StatelessWidget {
  const _SearchIntro({required this.onSelectQuery});

  final ValueChanged<String> onSelectQuery;

  static const List<String> _suggestions = [
    'TED talks English subtitles',
    'Daily English conversation',
    'BBC Learning English',
    'Artificial Intelligence explained',
    'National Geographic documentary',
    'Short stories in English',
  ];

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LocalStore>();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        FutureBuilder<List<String>>(
          future: store.loadSearchHistory(),
          builder: (context, snapshot) {
            final history = snapshot.data ?? const [];
            if (history.isEmpty) return const SizedBox.shrink();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text(
                      'عمليات البحث الأخيرة',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: store.clearSearchHistory,
                      child: const Text('مسح'),
                    ),
                  ],
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: history
                      .map(
                        (item) => ActionChip(
                          avatar: const Icon(Icons.history, size: 16),
                          label: Text(item),
                          onPressed: () => onSelectQuery(item),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(height: 18),
              ],
            );
          },
        ),
        const Text(
          'مواضيع مقترحة للترجمة والتعلّم',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _suggestions
              .map(
                (item) => ActionChip(
                  avatar: const Icon(Icons.trending_up, size: 16),
                  label: Text(item),
                  onPressed: () => onSelectQuery(item),
                ),
              )
              .toList(),
        ),
      ],
    );
  }
}

class _SearchMessage extends StatelessWidget {
  const _SearchMessage({
    required this.icon,
    required this.message,
    this.action,
  });

  final IconData icon;
  final String message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 42, color: Colors.white38),
            const SizedBox(height: 14),
            Text(message, textAlign: TextAlign.center),
            if (action != null) ...[const SizedBox(height: 16), action!],
          ],
        ),
      ),
    );
  }
}

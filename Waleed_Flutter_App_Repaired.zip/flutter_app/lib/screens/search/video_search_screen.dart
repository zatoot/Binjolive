import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/waleed_video.dart';
import '../../data/app_settings.dart';
import '../../services/caption_service.dart';
import '../../services/youtube_catalog_service.dart';
import '../player/player_screen.dart';
import '../../widgets/video_list_tile.dart';

class VideoSearchScreen extends StatefulWidget {
  const VideoSearchScreen({super.key});

  @override
  State<VideoSearchScreen> createState() => _VideoSearchScreenState();
}

class _VideoSearchScreenState extends State<VideoSearchScreen> {
  final TextEditingController _query = TextEditingController();
  Future<List<WaleedVideo>>? _results;
  bool _captionsOnly = false;
  bool _translateQuery = false;
  bool _busy = false;
  final Map<String, String> _translatedTitles = {};

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final raw = _query.text.trim();
    if (raw.isEmpty || _busy) return;
    final captionService = context.read<CaptionService>();
    final catalog = context.read<YoutubeCatalogService>();
    final translateQuery = _translateQuery;
    final captionsOnly = _captionsOnly;
    final translateTitles = context.read<AppSettings>().translateTitles;

    setState(() => _busy = true);

    try {
      var query = raw;
      if (translateQuery) {
        query = await captionService.translateLine(
          text: raw,
          sourceCode: 'ar',
          targetCode: 'en',
        );
      }
      final videos = await catalog.searchVideos(
        query,
        captionsOnly: captionsOnly,
        limit: 30,
      );
      _translatedTitles.clear();
      if (translateTitles) {
        for (final video in videos) {
          try {
            _translatedTitles[video.id] = await captionService.translateLine(
              text: video.title,
              sourceCode: 'en',
              targetCode: 'ar',
            );
          } catch (_) {
            // Keep the original title when the source language/model is unavailable.
          }
        }
      }
      if (!mounted) return;
      setState(() => _results = Future.value(videos));
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _results = Future.error(error);
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openFilters() async {
    var captions = _captionsOnly;
    var translate = _translateQuery;
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, update) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'إعدادات البحث',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('مع ترجمة نصية'),
                  value: captions,
                  onChanged: (value) => update(() => captions = value),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('ترجمة عبارة البحث إلى الإنجليزية'),
                  value: translate,
                  onChanged: (value) => update(() => translate = value),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    TextButton(
                      onPressed: () => Navigator.pop(sheetContext),
                      child: const Text('إلغاء'),
                    ),
                    const Spacer(),
                    FilledButton(
                      onPressed: () {
                        setState(() {
                          _captionsOnly = captions;
                          _translateQuery = translate;
                        });
                        Navigator.pop(sheetContext);
                        if (_query.text.trim().isNotEmpty) _search();
                      },
                      child: const Text('تطبيق'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ابحث عن فيديوهات')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 6, 14, 12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _query,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _search(),
                    decoration: InputDecoration(
                      hintText: 'عنوان الفيديو أو موضوع البحث',
                      prefixIcon: const Icon(Icons.search),
                      filled: true,
                      fillColor: const Color(0xFF1A1C23),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(
                  onPressed: _openFilters,
                  icon: const Icon(Icons.tune),
                  tooltip: 'إعدادات البحث',
                ),
                const SizedBox(width: 4),
                IconButton.filled(
                  onPressed: _busy ? null : _search,
                  icon: const Icon(Icons.arrow_forward),
                  tooltip: 'بحث',
                ),
              ],
            ),
          ),
          if (_captionsOnly || _translateQuery)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
              child: Wrap(
                spacing: 8,
                children: [
                  if (_captionsOnly) const Chip(label: Text('مع ترجمة نصية')),
                  if (_translateQuery)
                    const Chip(label: Text('ترجمة عبارة البحث')),
                ],
              ),
            ),
          Expanded(
            child: _busy && _results == null
                ? const Center(child: CircularProgressIndicator())
                : _results == null
                ? const _SearchIntro()
                : FutureBuilder<List<WaleedVideo>>(
                    future: _results,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (snapshot.hasError) {
                        return _SearchMessage(
                          icon: Icons.cloud_off_outlined,
                          message:
                              'تعذر تنفيذ البحث حالياً.\n${snapshot.error}',
                          action: FilledButton.tonal(
                            onPressed: _search,
                            child: const Text('إعادة المحاولة'),
                          ),
                        );
                      }
                      final videos = snapshot.data ?? const <WaleedVideo>[];
                      if (videos.isEmpty) {
                        return const _SearchMessage(
                          icon: Icons.search_off,
                          message: 'لم يتم العثور على نتائج',
                        );
                      }
                      return ListView.separated(
                        padding: const EdgeInsets.fromLTRB(14, 6, 14, 20),
                        itemCount: videos.length,
                        separatorBuilder: (_, _) =>
                            const Divider(height: 18, color: Colors.white12),
                        itemBuilder: (context, index) => VideoListTile(
                          video: videos[index],
                          titleOverride: _translatedTitles[videos[index].id],
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) =>
                                  PlayerScreen(video: videos[index]),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _SearchIntro extends StatelessWidget {
  const _SearchIntro();

  @override
  Widget build(BuildContext context) {
    return const _SearchMessage(
      icon: Icons.search,
      message: 'اكتب موضوعاً أو عنوان فيديو لعرض نتائج YouTube هنا.',
    );
  }
}

class _SearchMessage extends StatelessWidget {
  const _SearchMessage({
    required this.icon,
    required this.message,
    this.action,
  });

  final IconData icon;
  final String message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 42, color: Colors.white38),
            const SizedBox(height: 14),
            Text(message, textAlign: TextAlign.center),
            if (action != null) ...[const SizedBox(height: 16), action!],
          ],
        ),
      ),
    );
  }
}

class WaleedVideo {
  const WaleedVideo({
    required this.id,
    required this.title,
    required this.channel,
    required this.thumbnailUrl,
    this.duration,
    this.viewCount,
    this.publishedAt,
    this.description = '',
    this.progress = 0,
    this.lastPositionMs = 0,
  });

  final String id;
  final String title;
  final String channel;
  final String thumbnailUrl;
  final Duration? duration;
  final int? viewCount;
  final DateTime? publishedAt;
  final String description;
  final double progress;
  final int lastPositionMs;

  String get watchUrl => 'https://www.youtube.com/watch?v=$id';

  String get effectiveThumbnailUrl =>
      thumbnailUrl.isNotEmpty ? thumbnailUrl : 'https://i.ytimg.com/vi/$id/hqdefault.jpg';

  WaleedVideo copyWith({
    String? title,
    String? channel,
    String? thumbnailUrl,
    Duration? duration,
    int? viewCount,
    DateTime? publishedAt,
    String? description,
    double? progress,
    int? lastPositionMs,
  }) {
    return WaleedVideo(
      id: id,
      title: title ?? this.title,
      channel: channel ?? this.channel,
      thumbnailUrl: thumbnailUrl ?? this.thumbnailUrl,
      duration: duration ?? this.duration,
      viewCount: viewCount ?? this.viewCount,
      publishedAt: publishedAt ?? this.publishedAt,
      description: description ?? this.description,
      progress: progress ?? this.progress,
      lastPositionMs: lastPositionMs ?? this.lastPositionMs,
    );
  }

  /// Extracts a canonical 11-character YouTube video ID from any URL, share text, or raw ID.
  static String? tryExtractVideoId(String? rawInput) {
    if (rawInput == null) return null;
    final trimmed = rawInput.trim();
    if (trimmed.isEmpty) return null;

    if (RegExp(r'^[A-Za-z0-9_-]{11}$').hasMatch(trimmed)) {
      return trimmed;
    }

    final regex = RegExp(
      r'(?:https?://)?(?:www\.|m\.|music\.)?(?:youtube\.com/(?:watch\?(?:[^#\s"&]*&)*v=|shorts/|live/|embed/|v/)|youtu\.be/)([A-Za-z0-9_-]{11})',
      caseSensitive: false,
    );
    final match = regex.firstMatch(trimmed);
    if (match != null && match.group(1) != null) {
      return match.group(1);
    }

    final urlMatch = RegExp(r'https?://[^\s]+').firstMatch(trimmed);
    final candidateUrl = urlMatch?.group(0) ?? trimmed;
    final uri = Uri.tryParse(candidateUrl);
    if (uri != null) {
      if (uri.host == 'youtu.be' || uri.host.endsWith('.youtu.be')) {
        if (uri.pathSegments.isNotEmpty) {
          final seg = uri.pathSegments.first;
          if (RegExp(r'^[A-Za-z0-9_-]{11}$').hasMatch(seg)) return seg;
        }
      }
      if (uri.host.contains('youtube.com') || uri.host.contains('youtube-nocookie.com')) {
        final v = uri.queryParameters['v'];
        if (v != null && RegExp(r'^[A-Za-z0-9_-]{11}$').hasMatch(v)) {
          return v;
        }
        for (final marker in const ['shorts', 'live', 'embed', 'v', 'watch']) {
          final idx = uri.pathSegments.indexOf(marker);
          if (idx >= 0 && idx + 1 < uri.pathSegments.length) {
            final seg = uri.pathSegments[idx + 1];
            if (RegExp(r'^[A-Za-z0-9_-]{11}$').hasMatch(seg)) return seg;
          }
        }
      }
    }
    return null;
  }
}

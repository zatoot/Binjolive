class WaleedVideo {
  const WaleedVideo({
    required this.id,
    required this.title,
    required this.channel,
    required this.thumbnailUrl,
    this.duration,
    this.viewCount,
    this.publishedAt,
    this.progress = 0,
  });

  final String id;
  final String title;
  final String channel;
  final String thumbnailUrl;
  final Duration? duration;
  final int? viewCount;
  final DateTime? publishedAt;
  final double progress;

  String get watchUrl => 'https://www.youtube.com/watch?v=$id';

  WaleedVideo copyWith({
    String? title,
    String? channel,
    String? thumbnailUrl,
    Duration? duration,
    int? viewCount,
    DateTime? publishedAt,
    double? progress,
  }) {
    return WaleedVideo(
      id: id,
      title: title ?? this.title,
      channel: channel ?? this.channel,
      thumbnailUrl: thumbnailUrl ?? this.thumbnailUrl,
      duration: duration ?? this.duration,
      viewCount: viewCount ?? this.viewCount,
      publishedAt: publishedAt ?? this.publishedAt,
      progress: progress ?? this.progress,
    );
  }
}

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/waleed_video.dart';

class LocalStore extends ChangeNotifier {
  LocalStore() : _database = _openDatabase();

  final Future<Database> _database;

  static Future<Database> _openDatabase() async {
    final base = await getDatabasesPath();
    return openDatabase(
      p.join(base, 'waleed.db'),
      version: 2,
      onCreate: (db, version) async {
        await _createTables(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        await _createTables(db);
        if (oldVersion < 2) {
          try {
            await db.execute(
              'ALTER TABLE recent_videos ADD COLUMN last_position_ms INTEGER NOT NULL DEFAULT 0',
            );
          } catch (_) {}
        }
      },
    );
  }

  static Future<void> _createTables(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS recent_videos (
        video_id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        channel TEXT NOT NULL,
        thumbnail_url TEXT NOT NULL,
        duration_seconds INTEGER,
        progress REAL NOT NULL DEFAULT 0,
        last_position_ms INTEGER NOT NULL DEFAULT 0,
        last_opened INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS playlists (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        created_at INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS playlist_videos (
        playlist_id INTEGER NOT NULL,
        video_id TEXT NOT NULL,
        title TEXT NOT NULL,
        channel TEXT NOT NULL,
        thumbnail_url TEXT NOT NULL,
        duration_seconds INTEGER,
        added_at INTEGER NOT NULL,
        PRIMARY KEY (playlist_id, video_id),
        FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS bookmarks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        video_id TEXT NOT NULL,
        video_title TEXT NOT NULL,
        channel TEXT NOT NULL,
        position_ms INTEGER NOT NULL,
        original_text TEXT NOT NULL,
        translated_text TEXT NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        created_at INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS search_history (
        query TEXT PRIMARY KEY,
        searched_at INTEGER NOT NULL
      )
    ''');
  }

  Future<void> saveRecent(
    WaleedVideo video, {
    double? progress,
    int? positionMs,
  }) async {
    final db = await _database;
    final existing = await db.query(
      'recent_videos',
      where: 'video_id = ?',
      whereArgs: [video.id],
      limit: 1,
    );
    final prevProgress = existing.isNotEmpty
        ? (existing.first['progress'] as num?)?.toDouble() ?? 0.0
        : 0.0;
    final prevPos = existing.isNotEmpty
        ? (existing.first['last_position_ms'] as int?) ?? 0
        : 0;

    await db.insert(
      'recent_videos',
      {
        'video_id': video.id,
        'title': video.title,
        'channel': video.channel,
        'thumbnail_url': video.effectiveThumbnailUrl,
        'duration_seconds': video.duration?.inSeconds,
        'progress': (progress ?? prevProgress).clamp(0.0, 1.0),
        'last_position_ms': positionMs ?? prevPos,
        'last_opened': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    notifyListeners();
  }

  Future<List<WaleedVideo>> loadRecent() async {
    final db = await _database;
    final rows = await db.query('recent_videos', orderBy: 'last_opened DESC');
    return rows
        .map(
          (row) => WaleedVideo(
            id: row['video_id'] as String,
            title: row['title'] as String,
            channel: row['channel'] as String,
            thumbnailUrl: row['thumbnail_url'] as String,
            duration: row['duration_seconds'] == null
                ? null
                : Duration(seconds: row['duration_seconds'] as int),
            progress: (row['progress'] as num?)?.toDouble() ?? 0.0,
            lastPositionMs: (row['last_position_ms'] as int?) ?? 0,
          ),
        )
        .toList();
  }

  Future<void> updateRecentProgress(
    String videoId,
    double progress, {
    int? positionMs,
  }) async {
    final db = await _database;
    final values = <String, Object?>{
      'progress': progress.clamp(0.0, 1.0),
    };
    if (positionMs != null) {
      values['last_position_ms'] = positionMs;
    }
    await db.update(
      'recent_videos',
      values,
      where: 'video_id = ?',
      whereArgs: [videoId],
    );
    notifyListeners();
  }

  Future<void> deleteRecent(String videoId) async {
    final db = await _database;
    await db.delete(
      'recent_videos',
      where: 'video_id = ?',
      whereArgs: [videoId],
    );
    notifyListeners();
  }

  Future<void> clearAllRecent() async {
    final db = await _database;
    await db.delete('recent_videos');
    notifyListeners();
  }

  Future<int> createPlaylist(String name) async {
    final db = await _database;
    final id = await db.insert('playlists', {
      'name': name.trim(),
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    notifyListeners();
    return id;
  }

  Future<List<Map<String, Object?>>> loadPlaylists() async {
    final db = await _database;
    final rows = await db.rawQuery('''
      SELECT p.id, p.name, p.created_at, COUNT(pv.video_id) AS video_count
      FROM playlists p
      LEFT JOIN playlist_videos pv ON p.id = pv.playlist_id
      GROUP BY p.id
      ORDER BY p.created_at DESC
    ''');
    return rows;
  }

  Future<void> addToPlaylist(int playlistId, WaleedVideo video) async {
    final db = await _database;
    await db.insert(
      'playlist_videos',
      {
        'playlist_id': playlistId,
        'video_id': video.id,
        'title': video.title,
        'channel': video.channel,
        'thumbnail_url': video.effectiveThumbnailUrl,
        'duration_seconds': video.duration?.inSeconds,
        'added_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    notifyListeners();
  }

  Future<List<WaleedVideo>> loadPlaylistVideos(int playlistId) async {
    final db = await _database;
    final rows = await db.query(
      'playlist_videos',
      where: 'playlist_id = ?',
      whereArgs: [playlistId],
      orderBy: 'added_at DESC',
    );
    return rows
        .map(
          (row) => WaleedVideo(
            id: row['video_id'] as String,
            title: row['title'] as String,
            channel: row['channel'] as String,
            thumbnailUrl: row['thumbnail_url'] as String,
            duration: row['duration_seconds'] == null
                ? null
                : Duration(seconds: row['duration_seconds'] as int),
          ),
        )
        .toList();
  }

  Future<int> addBookmark({
    required WaleedVideo video,
    required Duration position,
    required String originalText,
    required String translatedText,
    String note = '',
  }) async {
    final db = await _database;
    final id = await db.insert('bookmarks', {
      'video_id': video.id,
      'video_title': video.title,
      'channel': video.channel,
      'position_ms': position.inMilliseconds,
      'original_text': originalText,
      'translated_text': translatedText,
      'note': note.trim(),
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    notifyListeners();
    return id;
  }

  Future<List<Map<String, Object?>>> loadBookmarks({
    String query = '',
    String? videoId,
  }) async {
    final db = await _database;
    final trimmed = query.trim();
    final conditions = <String>[];
    final args = <Object?>[];

    if (videoId != null && videoId.isNotEmpty) {
      conditions.add('video_id = ?');
      args.add(videoId);
    }
    if (trimmed.isNotEmpty) {
      final term = '%$trimmed%';
      conditions.add(
        '(video_title LIKE ? OR original_text LIKE ? OR translated_text LIKE ? OR note LIKE ?)',
      );
      args.addAll([term, term, term, term]);
    }

    return db.query(
      'bookmarks',
      where: conditions.isEmpty ? null : conditions.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: videoId != null ? 'position_ms ASC' : 'created_at DESC',
    );
  }

  Future<void> updateBookmark({
    required int id,
    required String originalText,
    required String translatedText,
    required String note,
  }) async {
    final db = await _database;
    await db.update(
      'bookmarks',
      {
        'original_text': originalText.trim(),
        'translated_text': translatedText.trim(),
        'note': note.trim(),
      },
      where: 'id = ?',
      whereArgs: [id],
    );
    notifyListeners();
  }

  Future<void> removeBookmark(int id) async {
    final db = await _database;
    await db.delete('bookmarks', where: 'id = ?', whereArgs: [id]);
    notifyListeners();
  }

  Future<void> deletePlaylist(int playlistId) async {
    final db = await _database;
    await db.transaction((txn) async {
      await txn.delete(
        'playlist_videos',
        where: 'playlist_id = ?',
        whereArgs: [playlistId],
      );
      await txn.delete('playlists', where: 'id = ?', whereArgs: [playlistId]);
    });
    notifyListeners();
  }

  Future<void> renamePlaylist(int playlistId, String name) async {
    final db = await _database;
    await db.update(
      'playlists',
      {'name': name.trim()},
      where: 'id = ?',
      whereArgs: [playlistId],
    );
    notifyListeners();
  }

  Future<void> removeFromPlaylist(int playlistId, String videoId) async {
    final db = await _database;
    await db.delete(
      'playlist_videos',
      where: 'playlist_id = ? AND video_id = ?',
      whereArgs: [playlistId, videoId],
    );
    notifyListeners();
  }

  Future<void> saveSearchQuery(String query) async {
    final q = query.trim();
    if (q.isEmpty) return;
    final db = await _database;
    await db.insert(
      'search_history',
      {
        'query': q,
        'searched_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<String>> loadSearchHistory({int limit = 10}) async {
    final db = await _database;
    final rows = await db.query(
      'search_history',
      orderBy: 'searched_at DESC',
      limit: limit,
    );
    return rows.map((r) => r['query'] as String).toList();
  }

  Future<void> clearSearchHistory() async {
    final db = await _database;
    await db.delete('search_history');
    notifyListeners();
  }
}

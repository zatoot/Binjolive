import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/waleed_video.dart';

class LocalStore {
  LocalStore() : _database = _openDatabase();

  final Future<Database> _database;

  static Future<Database> _openDatabase() async {
    final base = await getDatabasesPath();
    return openDatabase(
      p.join(base, 'waleed.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE recent_videos (
            video_id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            channel TEXT NOT NULL,
            thumbnail_url TEXT NOT NULL,
            duration_seconds INTEGER,
            progress REAL NOT NULL DEFAULT 0,
            last_opened INTEGER NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE playlists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            created_at INTEGER NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE playlist_videos (
            playlist_id INTEGER NOT NULL,
            video_id TEXT NOT NULL,
            title TEXT NOT NULL,
            channel TEXT NOT NULL,
            thumbnail_url TEXT NOT NULL,
            duration_seconds INTEGER,
            added_at INTEGER NOT NULL,
            PRIMARY KEY (playlist_id, video_id),
            FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE
          )
        ''');
        await db.execute('''
          CREATE TABLE bookmarks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            video_id TEXT NOT NULL,
            video_title TEXT NOT NULL,
            channel TEXT NOT NULL,
            position_ms INTEGER NOT NULL,
            original_text TEXT NOT NULL,
            translated_text TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            created_at INTEGER NOT NULL
          )
        ''');
      },
    );
  }

  Future<void> saveRecent(WaleedVideo video, {double progress = 0}) async {
    final db = await _database;
    await db.insert('recent_videos', {
      'video_id': video.id,
      'title': video.title,
      'channel': video.channel,
      'thumbnail_url': video.thumbnailUrl,
      'duration_seconds': video.duration?.inSeconds,
      'progress': progress.clamp(0, 1),
      'last_opened': DateTime.now().millisecondsSinceEpoch,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<WaleedVideo>> loadRecent() async {
    final db = await _database;
    final rows = await db.query('recent_videos', orderBy: 'last_opened DESC');
    return rows
        .map(
          (row) => WaleedVideo(
            id: row['video_id'] as String,
            title: row['title'] as String,
            channel: row['channel'] as String,
            thumbnailUrl: row['thumbnail_url'] as String,
            duration: row['duration_seconds'] == null
                ? null
                : Duration(seconds: row['duration_seconds'] as int),
            progress: (row['progress'] as num?)?.toDouble() ?? 0,
          ),
        )
        .toList();
  }

  Future<int> createPlaylist(String name) async {
    final db = await _database;
    return db.insert('playlists', {
      'name': name.trim(),
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<Map<String, Object?>>> loadPlaylists() async {
    final db = await _database;
    return db.query('playlists', orderBy: 'created_at DESC');
  }

  Future<void> addToPlaylist(int playlistId, WaleedVideo video) async {
    final db = await _database;
    await db.insert('playlist_videos', {
      'playlist_id': playlistId,
      'video_id': video.id,
      'title': video.title,
      'channel': video.channel,
      'thumbnail_url': video.thumbnailUrl,
      'duration_seconds': video.duration?.inSeconds,
      'added_at': DateTime.now().millisecondsSinceEpoch,
    }, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<List<WaleedVideo>> loadPlaylistVideos(int playlistId) async {
    final db = await _database;
    final rows = await db.query(
      'playlist_videos',
      where: 'playlist_id = ?',
      whereArgs: [playlistId],
      orderBy: 'added_at DESC',
    );
    return rows
        .map(
          (row) => WaleedVideo(
            id: row['video_id'] as String,
            title: row['title'] as String,
            channel: row['channel'] as String,
            thumbnailUrl: row['thumbnail_url'] as String,
            duration: row['duration_seconds'] == null
                ? null
                : Duration(seconds: row['duration_seconds'] as int),
          ),
        )
        .toList();
  }

  Future<int> addBookmark({
    required WaleedVideo video,
    required Duration position,
    required String originalText,
    required String translatedText,
    String note = '',
  }) async {
    final db = await _database;
    return db.insert('bookmarks', {
      'video_id': video.id,
      'video_title': video.title,
      'channel': video.channel,
      'position_ms': position.inMilliseconds,
      'original_text': originalText,
      'translated_text': translatedText,
      'note': note,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<Map<String, Object?>>> loadBookmarks({String query = ''}) async {
    final db = await _database;
    final term = '%${query.trim()}%';
    return db.query(
      'bookmarks',
      where: query.trim().isEmpty ? null : 'video_title LIKE ? OR original_text LIKE ? OR translated_text LIKE ? OR note LIKE ?',
      whereArgs: query.trim().isEmpty ? null : [term, term, term, term],
      orderBy: 'created_at DESC',
    );
  }

  Future<void> updateBookmark({
    required int id,
    required String originalText,
    required String translatedText,
    required String note,
  }) async {
    final db = await _database;
    await db.update(
      'bookmarks',
      {
        'original_text': originalText,
        'translated_text': translatedText,
        'note': note,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> removeBookmark(int id) async {
    final db = await _database;
    await db.delete('bookmarks', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deletePlaylist(int playlistId) async {
    final db = await _database;
    await db.transaction((txn) async {
      await txn.delete(
        'playlist_videos',
        where: 'playlist_id = ?',
        whereArgs: [playlistId],
      );
      await txn.delete('playlists', where: 'id = ?', whereArgs: [playlistId]);
    });
  }

  Future<void> renamePlaylist(int playlistId, String name) async {
    final db = await _database;
    await db.update(
      'playlists',
      {'name': name.trim()},
      where: 'id = ?',
      whereArgs: [playlistId],
    );
  }

  Future<void> removeFromPlaylist(int playlistId, String videoId) async {
    final db = await _database;
    await db.delete(
      'playlist_videos',
      where: 'playlist_id = ? AND video_id = ?',
      whereArgs: [playlistId, videoId],
    );
  }

  Future<void> updateRecentProgress(String videoId, double progress) async {
    final db = await _database;
    await db.update(
      'recent_videos',
      {'progress': progress.clamp(0, 1)},
      where: 'video_id = ?',
      whereArgs: [videoId],
    );
  }

  Future<void> deleteRecent(String videoId) async {
    final db = await _database;
    await db.delete(
      'recent_videos',
      where: 'video_id = ?',
      whereArgs: [videoId],
    );
  }
}

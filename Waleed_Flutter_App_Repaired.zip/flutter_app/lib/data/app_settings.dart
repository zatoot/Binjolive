import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SupportedLanguageOption {
  const SupportedLanguageOption({
    required this.code,
    required this.nativeName,
    required this.arabicName,
  });

  final String code;
  final String nativeName;
  final String arabicName;
}

class AppSettings extends ChangeNotifier {
  AppSettings._(this._preferences);

  static const List<SupportedLanguageOption> supportedLanguages = [
    SupportedLanguageOption(code: 'ar', nativeName: 'العربية', arabicName: 'العربية'),
    SupportedLanguageOption(code: 'en', nativeName: 'English', arabicName: 'الإنجليزية'),
    SupportedLanguageOption(code: 'fr', nativeName: 'Français', arabicName: 'الفرنسية'),
    SupportedLanguageOption(code: 'es', nativeName: 'Español', arabicName: 'الإسبانية'),
    SupportedLanguageOption(code: 'de', nativeName: 'Deutsch', arabicName: 'الألمانية'),
    SupportedLanguageOption(code: 'tr', nativeName: 'Türkçe', arabicName: 'التركية'),
    SupportedLanguageOption(code: 'ru', nativeName: 'Русский', arabicName: 'الروسية'),
    SupportedLanguageOption(code: 'it', nativeName: 'Italiano', arabicName: 'الإيطالية'),
    SupportedLanguageOption(code: 'pt', nativeName: 'Português', arabicName: 'البرتغالية'),
    SupportedLanguageOption(code: 'zh', nativeName: '中文', arabicName: 'الصينية'),
    SupportedLanguageOption(code: 'ja', nativeName: '日本語', arabicName: 'اليابانية'),
    SupportedLanguageOption(code: 'ko', nativeName: '한국어', arabicName: 'الكورية'),
    SupportedLanguageOption(code: 'hi', nativeName: 'हिन्दी', arabicName: 'الهندية'),
    SupportedLanguageOption(code: 'ur', nativeName: 'اردو', arabicName: 'الأردية'),
    SupportedLanguageOption(code: 'fa', nativeName: 'فارسی', arabicName: 'الفارسية'),
    SupportedLanguageOption(code: 'id', nativeName: 'Bahasa Indonesia', arabicName: 'الإندونيسية'),
    SupportedLanguageOption(code: 'nl', nativeName: 'Nederlands', arabicName: 'الهولندية'),
    SupportedLanguageOption(code: 'pl', nativeName: 'Polski', arabicName: 'البولندية'),
    SupportedLanguageOption(code: 'uk', nativeName: 'Українська', arabicName: 'الأوكرانية'),
    SupportedLanguageOption(code: 'vi', nativeName: 'Tiếng Việt', arabicName: 'الفيتنامية'),
    SupportedLanguageOption(code: 'th', nativeName: 'ไทย', arabicName: 'التايلاندية'),
  ];

  final SharedPreferences _preferences;

  bool _autoRotate = true;
  bool _translateTitles = true;
  bool _autoNext = true;
  bool _darkMode = true;
  String _targetLanguageCode = 'ar';
  bool _showOriginalCaptions = true;
  bool _showTranslatedCaptions = true;
  bool _showOverlayCaptions = true;
  double _primaryFontSize = 15.0;
  double _translationFontSize = 16.5;
  int _fontWeightIndex = 2; // 0: Light, 1: Normal, 2: Medium, 3: Bold

  bool _voiceOverEnabled = false;
  bool _voiceOverAutoRate = true;
  bool _voiceOverPauseForTail = true;
  bool _voiceOverMuteVideo = false;
  double _voiceOverSpeechRate = 0.52;
  double _voiceOverPitch = 1.0;
  double _voiceOverSpeechVolume = 1.0;
  double _voiceOverVideoVolume = 0.22;
  String? _selectedVoiceKey;

  bool get autoRotate => _autoRotate;
  bool get translateTitles => _translateTitles;
  bool get autoNext => _autoNext;
  bool get darkMode => _darkMode;
  String get targetLanguageCode => _targetLanguageCode;
  bool get showOriginalCaptions => _showOriginalCaptions;
  bool get showTranslatedCaptions => _showTranslatedCaptions;
  bool get showOverlayCaptions => _showOverlayCaptions;
  double get primaryFontSize => _primaryFontSize;
  double get translationFontSize => _translationFontSize;
  int get fontWeightIndex => _fontWeightIndex;

  bool get voiceOverEnabled => _voiceOverEnabled;
  bool get voiceOverAutoRate => _voiceOverAutoRate;
  bool get voiceOverPauseForTail => _voiceOverPauseForTail;
  bool get voiceOverMuteVideo => _voiceOverMuteVideo;
  double get voiceOverSpeechRate => _voiceOverSpeechRate;
  double get voiceOverPitch => _voiceOverPitch;
  double get voiceOverSpeechVolume => _voiceOverSpeechVolume;
  double get voiceOverVideoVolume => _voiceOverVideoVolume;
  String? get selectedVoiceKey => _selectedVoiceKey;

  FontWeight get captionFontWeight {
    switch (_fontWeightIndex) {
      case 0:
        return FontWeight.w300;
      case 1:
        return FontWeight.w400;
      case 2:
        return FontWeight.w600;
      case 3:
      default:
        return FontWeight.w700;
    }
  }

  static String languageLabel(String code) {
    final norm = code.toLowerCase().split(RegExp('[-_]')).first;
    for (final item in supportedLanguages) {
      if (item.code == norm) {
        return '${item.arabicName} (${item.nativeName})';
      }
    }
    return code;
  }

  static Future<AppSettings> load() async {
    final prefs = await SharedPreferences.getInstance();
    final s = AppSettings._(prefs);
    s._autoRotate = prefs.getBool('auto_rotate') ?? true;
    s._translateTitles = prefs.getBool('translate_titles') ?? true;
    s._autoNext = prefs.getBool('auto_next') ?? true;
    s._darkMode = prefs.getBool('dark_mode') ?? true;
    s._targetLanguageCode = prefs.getString('target_language_code') ?? 'ar';
    s._showOriginalCaptions = prefs.getBool('show_original_captions') ?? true;
    s._showTranslatedCaptions = prefs.getBool('show_translated_captions') ?? true;
    s._showOverlayCaptions = prefs.getBool('show_overlay_captions') ?? true;
    s._primaryFontSize = (prefs.getDouble('primary_font_size') ?? 15.0).clamp(11.0, 28.0);
    s._translationFontSize = (prefs.getDouble('translation_font_size') ?? 16.5).clamp(11.0, 28.0);
    s._fontWeightIndex = (prefs.getInt('font_weight_index') ?? 2).clamp(0, 3);
    s._voiceOverEnabled = prefs.getBool('vo_enabled') ?? false;
    s._voiceOverAutoRate = prefs.getBool('vo_auto_rate') ?? true;
    s._voiceOverPauseForTail = prefs.getBool('vo_pause_tail') ?? true;
    s._voiceOverMuteVideo = prefs.getBool('vo_mute_video') ?? false;
    s._voiceOverSpeechRate = (prefs.getDouble('vo_speech_rate') ?? 0.52).clamp(0.25, 0.85);
    s._voiceOverPitch = (prefs.getDouble('vo_pitch') ?? 1.0).clamp(0.5, 2.0);
    s._voiceOverSpeechVolume = (prefs.getDouble('vo_speech_vol') ?? 1.0).clamp(0.0, 1.0);
    s._voiceOverVideoVolume = (prefs.getDouble('vo_video_vol') ?? 0.22).clamp(0.0, 1.0);
    s._selectedVoiceKey = prefs.getString('vo_voice_key');
    return s;
  }

  Future<void> setAutoRotate(bool value) async {
    _autoRotate = value;
    notifyListeners();
    await _preferences.setBool('auto_rotate', value);
  }

  Future<void> setTranslateTitles(bool value) async {
    _translateTitles = value;
    notifyListeners();
    await _preferences.setBool('translate_titles', value);
  }

  Future<void> setAutoNext(bool value) async {
    _autoNext = value;
    notifyListeners();
    await _preferences.setBool('auto_next', value);
  }

  Future<void> setDarkMode(bool value) async {
    _darkMode = value;
    notifyListeners();
    await _preferences.setBool('dark_mode', value);
  }

  Future<void> setTargetLanguageCode(String code) async {
    _targetLanguageCode = code;
    notifyListeners();
    await _preferences.setString('target_language_code', code);
  }

  Future<void> setShowOriginalCaptions(bool value) async {
    _showOriginalCaptions = value;
    notifyListeners();
    await _preferences.setBool('show_original_captions', value);
  }

  Future<void> setShowTranslatedCaptions(bool value) async {
    _showTranslatedCaptions = value;
    notifyListeners();
    await _preferences.setBool('show_translated_captions', value);
  }

  Future<void> setShowOverlayCaptions(bool value) async {
    _showOverlayCaptions = value;
    notifyListeners();
    await _preferences.setBool('show_overlay_captions', value);
  }

  Future<void> setPrimaryFontSize(double value) async {
    _primaryFontSize = value.clamp(11.0, 28.0);
    notifyListeners();
    await _preferences.setDouble('primary_font_size', _primaryFontSize);
  }

  Future<void> setTranslationFontSize(double value) async {
    _translationFontSize = value.clamp(11.0, 28.0);
    notifyListeners();
    await _preferences.setDouble('translation_font_size', _translationFontSize);
  }

  Future<void> setFontWeightIndex(int value) async {
    _fontWeightIndex = value.clamp(0, 3);
    notifyListeners();
    await _preferences.setInt('font_weight_index', _fontWeightIndex);
  }

  Future<void> setVoiceOverEnabled(bool value) async {
    _voiceOverEnabled = value;
    notifyListeners();
    await _preferences.setBool('vo_enabled', value);
  }

  Future<void> setVoiceOverAutoRate(bool value) async {
    _voiceOverAutoRate = value;
    notifyListeners();
    await _preferences.setBool('vo_auto_rate', value);
  }

  Future<void> setVoiceOverPauseForTail(bool value) async {
    _voiceOverPauseForTail = value;
    notifyListeners();
    await _preferences.setBool('vo_pause_tail', value);
  }

  Future<void> setVoiceOverMuteVideo(bool value) async {
    _voiceOverMuteVideo = value;
    notifyListeners();
    await _preferences.setBool('vo_mute_video', value);
  }

  Future<void> setVoiceOverSpeechRate(double value) async {
    _voiceOverSpeechRate = value.clamp(0.25, 0.85);
    notifyListeners();
    await _preferences.setDouble('vo_speech_rate', _voiceOverSpeechRate);
  }

  Future<void> setVoiceOverPitch(double value) async {
    _voiceOverPitch = value.clamp(0.5, 2.0);
    notifyListeners();
    await _preferences.setDouble('vo_pitch', _voiceOverPitch);
  }

  Future<void> setVoiceOverSpeechVolume(double value) async {
    _voiceOverSpeechVolume = value.clamp(0.0, 1.0);
    notifyListeners();
    await _preferences.setDouble('vo_speech_vol', _voiceOverSpeechVolume);
  }

  Future<void> setVoiceOverVideoVolume(double value) async {
    _voiceOverVideoVolume = value.clamp(0.0, 1.0);
    notifyListeners();
    await _preferences.setDouble('vo_video_vol', _voiceOverVideoVolume);
  }

  Future<void> setSelectedVoiceKey(String? key) async {
    _selectedVoiceKey = key;
    notifyListeners();
    if (key == null || key.isEmpty) {
      await _preferences.remove('vo_voice_key');
    } else {
      await _preferences.setString('vo_voice_key', key);
    }
  }
}

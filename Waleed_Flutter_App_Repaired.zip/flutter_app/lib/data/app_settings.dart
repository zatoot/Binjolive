import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  AppSettings._(this._preferences);

  final SharedPreferences _preferences;
  bool _autoRotate = true;
  bool _translateTitles = false;
  bool _autoNext = true;
  bool _darkMode = true;

  bool get autoRotate => _autoRotate;
  bool get translateTitles => _translateTitles;
  bool get autoNext => _autoNext;
  bool get darkMode => _darkMode;

  static Future<AppSettings> load() async {
    final preferences = await SharedPreferences.getInstance();
    final settings = AppSettings._(preferences);
    settings._autoRotate = preferences.getBool('auto_rotate') ?? true;
    settings._translateTitles =
        preferences.getBool('translate_titles') ?? false;
    settings._autoNext = preferences.getBool('auto_next') ?? true;
    settings._darkMode = preferences.getBool('dark_mode') ?? true;
    return settings;
  }

  Future<void> setAutoRotate(bool value) async {
    _autoRotate = value;
    notifyListeners();
    await _preferences.setBool('auto_rotate', value);
  }

  Future<void> setTranslateTitles(bool value) async {
    _translateTitles = value;
    notifyListeners();
    await _preferences.setBool('translate_titles', value);
  }

  Future<void> setAutoNext(bool value) async {
    _autoNext = value;
    notifyListeners();
    await _preferences.setBool('auto_next', value);
  }

  Future<void> setDarkMode(bool value) async {
    _darkMode = value;
    notifyListeners();
    await _preferences.setBool('dark_mode', value);
  }
}

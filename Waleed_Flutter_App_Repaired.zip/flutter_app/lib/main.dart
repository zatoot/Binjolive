import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app/waleed_app.dart';
import 'data/local_store.dart';
import 'data/app_settings.dart';
import 'services/caption_service.dart';
import 'services/youtube_catalog_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final catalog = YoutubeCatalogService();
  final store = LocalStore();
  final captions = CaptionService(catalog.client);
  final settings = await AppSettings.load();

  runApp(
    MultiProvider(
      providers: [
        Provider<YoutubeCatalogService>.value(value: catalog),
        Provider<LocalStore>.value(value: store),
        Provider<CaptionService>.value(value: captions),
        ChangeNotifierProvider<AppSettings>.value(value: settings),
      ],
      child: const WaleedApp(),
    ),
  );
}

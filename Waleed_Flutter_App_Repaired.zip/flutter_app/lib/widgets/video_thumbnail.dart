import 'package:flutter/material.dart';

class VideoThumbnail extends StatelessWidget {
  const VideoThumbnail({
    required this.url,
    this.width,
    this.height = 92,
    super.key,
  });

  final String url;
  final double? width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        width: width,
        height: height,
        child: url.isEmpty
            ? Container(
                color: const Color(0xFF292B34),
                alignment: Alignment.center,
                child: const Icon(Icons.play_circle_outline, size: 34),
              )
            : Image.network(
                url,
                fit: BoxFit.cover,
                errorBuilder: (_, _, _) => Container(
                  color: const Color(0xFF292B34),
                  alignment: Alignment.center,
                  child: const Icon(Icons.play_circle_outline, size: 34),
                ),
              ),
      ),
    );
  }
}

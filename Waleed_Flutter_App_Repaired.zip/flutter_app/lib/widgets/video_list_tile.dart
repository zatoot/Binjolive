import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/local_store.dart';
import '../models/waleed_video.dart';
import 'video_thumbnail.dart';

class VideoListTile extends StatelessWidget {
  const VideoListTile({
    required this.video,
    required this.onTap,
    this.titleOverride,
    super.key,
  });

  final WaleedVideo video;
  final VoidCallback onTap;
  final String? titleOverride;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 152,
            child: Column(
              children: [
                VideoThumbnail(url: video.thumbnailUrl, width: 152, height: 94),
                if (video.progress > 0)
                  LinearProgressIndicator(
                    value: video.progress.clamp(0.0, 1.0).toDouble(),
                    minHeight: 3,
                    backgroundColor: Colors.white12,
                  ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    titleOverride ?? video.title,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 14,
                      height: 1.35,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    video.channel,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white60, fontSize: 12),
                  ),
                  const SizedBox(height: 3),
                  if (video.duration != null)
                    Text(
                      _durationText(video.duration!),
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 11,
                      ),
                    ),
                ],
              ),
            ),
          ),
          IconButton(
            tooltip: 'المزيد',
            visualDensity: VisualDensity.compact,
            onPressed: () => _showVideoActions(context),
            icon: const Icon(Icons.more_vert, color: Colors.white70),
          ),
        ],
      ),
    );
  }

  void _showVideoActions(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.playlist_add),
              title: const Text('إضافة إلى قائمة تشغيل'),
              onTap: () async {
                Navigator.pop(context);
                final store = context.read<LocalStore>();
                final playlists = await store.loadPlaylists();
                if (!context.mounted) return;
                if (playlists.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'أنشئ قائمة تشغيل أولاً من تبويب قوائم التشغيل.',
                      ),
                    ),
                  );
                  return;
                }
                final selected = await showDialog<int>(
                  context: context,
                  builder: (dialogContext) => SimpleDialog(
                    title: const Text('اختر قائمة تشغيل'),
                    children: playlists
                        .map(
                          (playlist) => SimpleDialogOption(
                            onPressed: () => Navigator.pop(
                              dialogContext,
                              playlist['id'] as int,
                            ),
                            child: Text(playlist['name'] as String? ?? ''),
                          ),
                        )
                        .toList(),
                  ),
                );
                if (selected != null) {
                  await store.addToPlaylist(selected, video);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('تمت الإضافة إلى قائمة التشغيل.'),
                      ),
                    );
                  }
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.open_in_new),
              title: const Text('فتح الفيديو'),
              onTap: () {
                Navigator.pop(context);
                onTap();
              },
            ),
          ],
        ),
      ),
    );
  }

  String _durationText(Duration duration) {
    String two(int value) => value.toString().padLeft(2, '0');
    if (duration.inHours > 0) {
      return '${duration.inHours}:${two(duration.inMinutes.remainder(60))}:${two(duration.inSeconds.remainder(60))}';
    }
    return '${duration.inMinutes}:${two(duration.inSeconds.remainder(60))}';
  }
}

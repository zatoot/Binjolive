import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../data/local_store.dart';
import '../models/waleed_video.dart';
import 'video_thumbnail.dart';

class VideoListTile extends StatelessWidget {
  const VideoListTile({
    required this.video,
    required this.onTap,
    this.titleOverride,
    this.subtitleBadge,
    this.onRemoveFromHistory,
    super.key,
  });

  final WaleedVideo video;
  final VoidCallback onTap;
  final String? titleOverride;
  final String? subtitleBadge;
  final VoidCallback? onRemoveFromHistory;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final secondaryColor = isDark ? Colors.white60 : Colors.black54;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 148,
              child: Stack(
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      VideoThumbnail(
                        url: video.effectiveThumbnailUrl,
                        width: 148,
                        height: 88,
                      ),
                      if (video.progress > 0)
                        ClipRRect(
                          borderRadius: const BorderRadius.vertical(
                            bottom: Radius.circular(8),
                          ),
                          child: LinearProgressIndicator(
                            value: video.progress.clamp(0.0, 1.0).toDouble(),
                            minHeight: 3.5,
                            backgroundColor: Colors.white12,
                            color: const Color(0xFF7C6CFF),
                          ),
                        ),
                    ],
                  ),
                  if (video.duration != null)
                    Positioned(
                      left: 6,
                      bottom: video.progress > 0 ? 8 : 6,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.78),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          _durationText(video.duration!),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      titleOverride ?? video.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 14,
                        height: 1.35,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (titleOverride != null &&
                        titleOverride != video.title) ...[
                      const SizedBox(height: 3),
                      Text(
                        video.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: secondaryColor, fontSize: 11.5),
                      ),
                    ],
                    const SizedBox(height: 6),
                    if (video.channel.isNotEmpty)
                      Text(
                        video.channel,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: secondaryColor, fontSize: 12),
                      ),
                    if (video.progress > 0 || subtitleBadge != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        subtitleBadge ??
                            'تمت مشاهدة ${(video.progress * 100).round()}%',
                        style: const TextStyle(
                          color: Color(0xFF8B7CFF),
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            IconButton(
              tooltip: 'المزيد',
              visualDensity: VisualDensity.compact,
              onPressed: () => _showVideoActions(context),
              icon: Icon(Icons.more_vert, color: secondaryColor),
            ),
          ],
        ),
      ),
    );
  }

  void _showVideoActions(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.play_circle_outline),
              title: const Text('تشغيل وترجمة الفيديو'),
              onTap: () {
                Navigator.pop(sheetContext);
                onTap();
              },
            ),
            ListTile(
              leading: const Icon(Icons.playlist_add),
              title: const Text('إضافة إلى قائمة تشغيل'),
              onTap: () async {
                Navigator.pop(sheetContext);
                await showAddToPlaylistDialog(context, video);
              },
            ),
            ListTile(
              leading: const Icon(Icons.copy_outlined),
              title: const Text('نسخ رابط الفيديو'),
              onTap: () async {
                Navigator.pop(sheetContext);
                await Clipboard.setData(ClipboardData(text: video.watchUrl));
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('تم نسخ رابط الفيديو.')),
                  );
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.share_outlined),
              title: const Text('مشاركة الفيديو'),
              onTap: () {
                Navigator.pop(sheetContext);
                SharePlus.instance.share(
                  ShareParams(text: '${video.title}\n${video.watchUrl}'),
                );
              },
            ),
            if (onRemoveFromHistory != null)
              ListTile(
                leading: const Icon(
                  Icons.delete_outline,
                  color: Colors.redAccent,
                ),
                title: const Text('إزالة من السجل'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  onRemoveFromHistory!();
                },
              ),
          ],
        ),
      ),
    );
  }

  static Future<void> showAddToPlaylistDialog(
    BuildContext context,
    WaleedVideo video,
  ) async {
    final store = context.read<LocalStore>();
    var playlists = await store.loadPlaylists();
    if (!context.mounted) return;

    final selected = await showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('احفظ في قائمة تشغيل'),
        content: SizedBox(
          width: 360,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (playlists.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('لا توجد قوائم تشغيل بعد. أنشئ قائمة جديدة الآن:'),
                )
              else
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 240),
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: playlists.length,
                    itemBuilder: (ctx, i) {
                      final pl = playlists[i];
                      return ListTile(
                        leading: const Icon(Icons.queue_music),
                        title: Text(pl['name'] as String? ?? ''),
                        onTap: () => Navigator.pop(
                          dialogContext,
                          pl['id'] as int,
                        ),
                      );
                    },
                  ),
                ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.add_circle_outline, color: Color(0xFF7C6CFF)),
                title: const Text('إنشاء قائمة تشغيل جديدة'),
                onTap: () async {
                  final nameCtrl = TextEditingController();
                  final createdName = await showDialog<String>(
                    context: dialogContext,
                    builder: (innerCtx) => AlertDialog(
                      title: const Text('قائمة تشغيل جديدة'),
                      content: TextField(
                        controller: nameCtrl,
                        autofocus: true,
                        decoration: const InputDecoration(
                          labelText: 'اسم القائمة',
                        ),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(innerCtx),
                          child: const Text('إلغاء'),
                        ),
                        FilledButton(
                          onPressed: () => Navigator.pop(
                            innerCtx,
                            nameCtrl.text.trim(),
                          ),
                          child: const Text('إنشاء'),
                        ),
                      ],
                    ),
                  );
                  nameCtrl.dispose();
                  if (createdName != null && createdName.isNotEmpty) {
                    final newId = await store.createPlaylist(createdName);
                    if (dialogContext.mounted) {
                      Navigator.pop(dialogContext, newId);
                    }
                  }
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    );

    if (selected != null) {
      await store.addToPlaylist(selected, video);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تمت إضافة الفيديو إلى قائمة التشغيل.')),
        );
      }
    }
  }

  String _durationText(Duration duration) {
    String two(int value) => value.toString().padLeft(2, '0');
    if (duration.inHours > 0) {
      return '${duration.inHours}:${two(duration.inMinutes.remainder(60))}:${two(duration.inSeconds.remainder(60))}';
    }
    return '${duration.inMinutes}:${two(duration.inSeconds.remainder(60))}';
  }
}

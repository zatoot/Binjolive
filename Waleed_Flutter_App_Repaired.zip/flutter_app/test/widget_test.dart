import 'package:flutter_test/flutter_test.dart';
import 'package:waleed/models/waleed_video.dart';

void main() {
  test('builds a canonical YouTube watch URL', () {
    const video = WaleedVideo(
      id: 'dQw4w9WgXcQ',
      title: 'sample',
      channel: 'channel',
      thumbnailUrl: '',
    );
    expect(video.watchUrl, 'https://www.youtube.com/watch?v=dQw4w9WgXcQ');
  });
}

package com.waleed.video

import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val METHOD_CHANNEL = "com.waleed.video/share_intents"
        private const val EVENT_CHANNEL = "com.waleed.video/share_events"
    }

    private var shareEventSink: EventChannel.EventSink? = null
    private var pendingSharedText: String? = null
    private var initialIntentConsumed: Boolean = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, METHOD_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getInitialSharedText" -> {
                        val value = pendingSharedText ?: if (!initialIntentConsumed) {
                            initialIntentConsumed = true
                            sharedTextFrom(intent)
                        } else {
                            null
                        }
                        pendingSharedText = null
                        result.success(value)
                    }
                    else -> result.notImplemented()
                }
            }

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, EVENT_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    shareEventSink = events
                    pendingSharedText?.let {
                        shareEventSink?.success(it)
                        pendingSharedText = null
                    }
                }

                override fun onCancel(arguments: Any?) {
                    shareEventSink = null
                }
            })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val shared = sharedTextFrom(intent) ?: return
        val sink = shareEventSink
        if (sink != null) {
            sink.success(shared)
        } else {
            pendingSharedText = shared
        }
    }

    private fun sharedTextFrom(source: Intent?): String? {
        if (source == null) return null
        return when (source.action) {
            Intent.ACTION_SEND -> {
                source.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                    ?: source.getStringExtra(Intent.EXTRA_TITLE)
            }
            Intent.ACTION_VIEW -> source.dataString
            else -> null
        }?.trim()?.takeIf { it.isNotEmpty() }
    }
}

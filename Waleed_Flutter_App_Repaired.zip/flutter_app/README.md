# تطبيق وليد

Independent Flutter Android application focused on YouTube video playback, captions, translation, voice-over, bookmarks and playlists.

- Android application ID: `com.waleed.video`
- Flutter: 3.47.x / Dart 3.13.x
- Android compile SDK: 36; target SDK: 35; minimum SDK: 23
- The Android host accepts YouTube links shared as text or opened as links.
- The app does not include an advertising SDK or an Advertising ID permission. This does not remove ads served within YouTube itself.

A build success alone is not proof of feature parity. See `../TARGET_SCOPE.md` and `../reports/WORKLOG_20261106_REBUILD.md`.

---

## سجل الحالة الفنية — 2026-11-06

### ما تم إنجازه والتحقق منه
- نجح تشغيل `flutter pub get`، ونجح `flutter analyze` دون أخطاء أو تحذيرات في آخر فحص سابق للبناء.
- عولج اختلاف مسار أداة Flutter `gen_snapshot` على Termux بإنشاء رابط رمزي داخل Flutter SDK:
  - المصدر: `bin/cache/artifacts/engine/linux-arm64-release/gen_snapshot`
  - المسار الذي يتوقعه Flutter: `bin/cache/artifacts/engine/linux-arm64-android-release/gen_snapshot`
  - هذا تعديل في مجلد أدوات Flutter، وليس تعديلاً على مصدر تطبيق وليد.
- تأكد تشغيل `gen_snapshot`، وظهر ناتج AOT السابق:
  `flutter_app/.dart_tool/flutter_build/024300ec029117a5da2414735d00cfd2/arm64-v8a/app.so`
  بحجم 11,064,848 بايت.
- محاولة البناء السابقة تجاوزت مرحلة AOT، لكنها فشلت عند `mergeReleaseNativeLibs` بسبب تعذر حل أسماء نطاقات مستودعات التنزيل، وليس بسبب خطأ Dart مثبت.
- في إعادة المحاولة، استجابت اختبارات الاتصال HTTP لمستودع Flutter على Google ومستودع Aliyun، وأصبحت مجموعة من الاعتماديات التي تعذر تنزيلها سابقاً موجودة في Gradle cache.

### حالة بناء Release الأخيرة
- أمر البناء:
  `flutter build apk --release --target-platform android-arm64 --no-pub`
- بدأ التشغيل المسجل في:
  `reports/release-build-network-retry-20261106.log`
  عند 17:53:05 بتوقيت العراق (+03:00).
- آخر تحقق: 18:13:48 بتوقيت العراق (+03:00)، وكانت عمليتا Flutter وGradle ما تزالان نشطتين. مدة التشغيل المسجلة تقارب 20 دقيقة و43 ثانية.
- Gradle daemon PID وقت الفحص: `8125`.
- لم يظهر في السجل حتى آخر قراءة سطر نجاح أو فشل نهائي.
- مسار APK المتوقع:
  `build/app/outputs/flutter-apk/app-release.apk`
  لم يكن موجوداً عند فحصه السابق؛ لذلك لا يوجد حتى الآن APK Release تم التحقق من وجوده أو صلاحية توقيعه.
- ظهرت تحذيرات عن غياب `source.properties` في مجلد NDK 28.2، وتحذير توافق Kotlin Gradle Plugin من إضافة `flutter_tts`. لم يثبت حتى الآن أن أياً منهما هو سبب فشل البناء.

### ما لم يتم إثباته بعد
- لم يكتمل بناء APK Release بنجاح، ولم يتم فحص توقيعه أو سلامة محتوياته.
- لم يتم تثبيت هذه النسخة على الهاتف أو إجراء اختبار تشغيل فعلي لها.
- لم يكتمل تدقيق ملف APK النهائي وملفاته الأصلية للتأكد عملياً من خلوه من مكونات الإعلانات ومعرّف الإعلانات.
- نجاح التحليل أو توليد ملف AOT لا يعني اكتمال وظائف التطبيق أو مطابقته للتطبيق المرجعي.

### توضيح نطاق المشروع
نسخة Flutter الحالية هي إعادة تنفيذ مستقلة للوظائف التي جرى العمل عليها، وليست حتى الآن نسخة مطابقة ثبت الوصول إليها عبر عكس هندسة Lingvotube 5.2.3. لا يجوز وصفها بأنها مطابقة أو مكتملة قبل استكمال مقارنة الوظائف والاختبارات. ملف APK المرجعي الأصلي محفوظ دون تعديل، ولم يتم تثبيت نسخة وليد على الجهاز.

### الملفات ذات الصلة
- سجل محاولة البناء الحالية: `reports/release-build-network-retry-20261106.log`
- سجل العمل السابق: `../reports/WORKLOG_20261106_REBUILD.md`
- مواصفات نطاق التطبيق: `../TARGET_SCOPE.md`

### تحديث نهائي لمحاولة البناء — 2026-11-06، 18:13:58 (+03:00)
هذا التحديث يحل محل حالة «البناء ما زال جارياً» أعلاه:
- انتهت محاولة Flutter بعد 1,240.7 ثانية، وسُجلت `BUILD_EXIT=1`.
- الرسالة النهائية من Flutter كانت: `Gradle build failed to produce an .apk file`.
- بحثت عن ملفات `.apk` في كامل مجلد `flutter_app/` ولم يُعثر على أي ملف.
- سجل Gradle daemon (`daemon-8125.out.log`) سجّل `BuildActionResult: Success` وخروج Gradle بالحالة 0. لذلك فشل Flutter هنا لأنه لم يجد APK ناتجاً، رغم أن سجل Gradle أبلغ عن نجاح الإجراء؛ والسبب الجذري لهذا التعارض لم يُحدد بعد.
- لا يوجد APK Release متاح للفحص أو التوقيع أو التثبيت. ملف Debug الأقدم الموجود في مجلد المشروع الجذر ليس ناتج هذه المحاولة ولا يُعد نجاحاً لبناء Release.
- انتهت عمليات البناء؛ لا توجد عملية Gradle 8125 أو Flutter 8044 نشطة في آخر فحص.
- لا توجد تغييرات على ملفات مصدر التطبيق ضمن محاولة البناء هذه؛ التغيير التقني السابق كان رابط `gen_snapshot` داخل Flutter SDK فقط.

**العائق المفتوح الآن:** تحديد لماذا لم يُنتج/يُظهر مسار Gradle ملف APK تحت مشروع Flutter، مع أن سجل Gradle سجّل نجاحاً. لا ينبغي بدء محاولة بناء أخرى أو إعلان إصدار جاهز قبل تشخيص هذه النقطة والتحقق من وجود الملف فعلياً.

### تصحيح تشخيص مسار APK وإثبات الملف — 2026-11-06، 18:30 (+03:00)
تم العثور على سبب التناقض السابق:
- إعداد Gradle القديم كان `rootProject.buildDir = '../../build'` داخل `android/build.gradle`. هذا وجّه مخرجات Android إلى `/data/data/com.termux/files/home/waleed-app/build/` خارج مشروع Flutter.
- Gradle نجح فعلياً في إنتاج:
  `/data/data/com.termux/files/home/waleed-app/build/app/outputs/flutter-apk/app-release.apk`
- Flutter كان يبحث داخل:
  `/data/data/com.termux/files/home/waleed-app/flutter_app/build/app/outputs/flutter-apk/`
  ولذلك انتهى أمر Flutter بـ `BUILD_EXIT=1` رغم وجود ملف APK في مسار البناء الخارجي. البحث السابق لم يشمل ذلك المجلد الخارجي؛ لذلك فإن عبارة «لم ينتج Gradle APK» كانت غير دقيقة، وتم تصحيحها هنا.
- صُحّح الآن `android/build.gradle` إلى `rootProject.buildDir = '../build'` حتى يكون مجلد بناء Android داخل `flutter_app/build/` كما يتوقع Flutter.
- أُخذت نسخة احتياطية قبل التغيير:
  `android/build.gradle.before-output-path-fix-20261106.bak`
- نُسخ APK الذي أنتجه Gradle إلى مسار Flutter المتوقع. هذه نسخة من ناتج البناء السابق، وليست دليلاً على أن أمر Flutter أُعيد تشغيله بنجاح بعد تعديل المسار. يلزم بناء لاحق للتحقق النهائي من أن Flutter ينتهي برمز خروج 0.

### فحوصات APK المتاحة حالياً
الملف:
`build/app/outputs/flutter-apk/app-release.apk`

- الحجم: 186 ميغابايت.
- SHA-256: `17a60677c4e9ab0ca02785d8df3ae239f3b27bad8b3439e90def19720d633e86`
- Application ID: `com.waleed.video`
- Version name: `0.2.0`
- Version code: `2`
- Minimum SDK: 24؛ Target SDK: 36.
- فحص ZIP: ناجح ولا توجد أخطاء في البيانات المضغوطة.
- فحص ZIP alignment: ناجح عند محاذاة 4 بايت.
- توقيع APK: صالح وفق APK Signature Scheme v2، بمفتاح Android Debug. هذا توقيع اختبار وليس مفتاح إصدار إنتاجي/متجر.
- فحص Manifest لم يعثر على إذن `com.google.android.gms.permission.AD_ID` أو إشارات AdMob المعروفة.
- فحص أسماء حزم DEX لم يجد أسماء الحزم الشائعة لخدمات إعلانات Google/Facebook/AppLovin/Unity. هذه فحوصات ساكنة محدودة وليست ضماناً مطلقاً لعدم وجود أي إعلان؛ كما أنها لا تمنع إعلانات YouTube التي يقدّمها YouTube نفسه.

### ملاحظة حجم الملف
- أكبر عنصر في APK هو `lib/arm64-v8a/libflutter.so`، حجمه نحو 165 ميغابايت داخل APK.
- فحص ELF وجد أقسام معلومات تصحيح كبيرة (`.debug_info`, `.debug_line`, `.debug_loc`, `.debug_str`).
- تجربة `llvm-strip --strip-debug` على نسخة اختبار منفصلة من مكتبة Flutter خفّضت حجمها من نحو 158 ميغابايت إلى 18 ميغابايت، مع الإبقاء على جدول الرموز الديناميكي.
- لم أستبدل المكتبة داخل APK الحالي، ولم أعد توقيعه بعد هذا الاختبار. كما أن مجلد NDK 28.2.13676358 المثبت حالياً غير مكتمل ولا يحتوي `source.properties` أو أدوات NDK؛ وهذا مرتبط بتحذيرات `CXX1101` أثناء البناء. تحسين حجم APK ما زال عملاً منفصلاً غير منجز.

### المتبقي
1. إعادة بناء Release بعد تصحيح مسار Gradle والتأكد من أن أمر Flutter ينتهي بنجاح ويضع APK بنفسه في المسار المتوقع.
2. معالجة تضخم `libflutter.so` عبر آلية stripping موثوقة قابلة للتكرار، لا عبر تعديل يدوي غير موثق للملف النهائي.
3. إعادة فحص APK النهائي بعد أي إعادة بناء/تحسين.
4. إجراء اختبار تشغيل فعلي بعد موافقة المستخدم على التثبيت. لم يتم تثبيت هذا APK على الهاتف.
5. تظل نسخة Flutter إعادة تنفيذ مستقلة وليست عكس هندسة مكتملة أو نسخة مطابقة مثبتة من Lingvotube 5.2.3.

### إثبات إعداد المسار بعد التصحيح
- شُغّل استعلام Gradle `properties` بعد تعديل `android/build.gradle`، وكانت النتيجة:
  - `projectDir: /data/data/com.termux/files/home/waleed-app/flutter_app/android`
  - `buildDir: /data/data/com.termux/files/home/waleed-app/flutter_app/build`
- هذا يؤكد أن Gradle أصبح يهيئ مسار الإخراج الصحيح. لم أعد تشغيل `assembleRelease` بعد التصحيح؛ لذلك يبقى التحقق من نجاح دورة Flutter كاملة بعد التعديل مفتوحاً.

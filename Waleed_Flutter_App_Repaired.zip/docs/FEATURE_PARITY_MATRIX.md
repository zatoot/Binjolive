# Waleed Feature Parity Matrix
Updated: 2026-11-06
Reference: Lingvotube 5.2.3 (com.mmt.translingua, versionCode 124)
Waleed application ID target: com.waleed.video

Legend:
- **Reference verified**: observed on the running app.
- **Reference static**: indicated by resources/AOT symbols, but live behavior not yet proven.
- **Waleed status**: not implemented until coded and device-tested.

| ID | Feature / workflow | Reference evidence | Waleed status | Required device test |
|---|---|---|---|---|
| NAV-01 | Main bottom navigation: Videos / YouTube / Bookmarks | Reference verified | Not implemented | Switch each tab; preserve scroll/state |
| NAV-02 | Drawer: Premium, restore, dark mode, settings, share, rate, privacy, terms, about | Reference verified | Not implemented | Open each action and verify destinations/states |
| VID-01 | Videos screen: search bar, For You / Playlists / Recent tabs | Reference verified | Not implemented | Switch tabs and validate content |
| VID-02 | For You feed with video cards (thumbnail/title/channel/duration) | Reference verified | Not implemented | Load feed, paginate/refresh, handle offline/empty |
| VID-03 | Video overflow menu | Static evidence | Not implemented | Enumerate actual menu actions on reference |
| VID-04 | Recent history with progress | Reference verified | Not implemented | Record opened video, progress, reopen, remove/clear |
| VID-05 | Playlists list and empty state | Empty state verified; actions static | Not implemented | Create, rename, add/remove, open playlist |
| SRCH-01 | In-app video search by text | Reference verified | Not implemented | Search query and select result |
| SRCH-02 | Search result cards + channel/title/duration | Reference verified | Not implemented | Verify result data and card navigation |
| SRCH-03 | Captions-only search filter | Reference verified control | Not implemented | Toggle and verify only matching results |
| SRCH-04 | Translate search query / translate result titles | Static evidence + setting visible | Not implemented | Change language and verify query/title behavior |
| SRCH-05 | Search empty/error/unavailable states | Static evidence | Not implemented | Test no results, network failure, provider unavailable |
| YT-01 | Embedded YouTube tab and in-WebView navigation | Reference verified | Not implemented | Load home, scroll, navigate back/forward |
| YT-02 | YouTube WebView search and results | Reference verified | Not implemented | Search query, open result, return |
| YT-03 | Receive shared YouTube link from external apps | Reference manifest supports SEND; resource onboarding | Not implemented | Share link from YouTube/browser into Waleed |
| PLAY-01 | Embedded YouTube player, play/pause, seek ±10s | Reference verified | Not implemented | Play, pause, seek, orientation, lifecycle |
| PLAY-02 | Related videos and Watch on YouTube | Reference verified | Not implemented | Open recommendation and external YouTube action |
| PLAY-03 | Auto-play next and auto-rotate settings | Settings visible | Not implemented | Toggle and verify behavior |
| PLAY-04 | Video information: title, channel, date, views, description, related | Reference verified | Not implemented | Open, expand/collapse description |
| CAP-01 | Caption track selection | Reference verified | Not implemented | Load tracks and choose alternate track |
| CAP-02 | Primary/original and translated captions together | Reference verified | Not implemented | Verify synchronization during playback |
| CAP-03 | Target-language selection | Reference verified | Not implemented | Select Arabic and a second language |
| CAP-04 | Show/hide original and translated text separately | Reference verified controls | Not implemented | Toggle each independently |
| CAP-05 | Font size/weight settings | Static evidence | Not implemented | Change size/weight and verify display |
| CAP-06 | Caption-line actions: play, copy, bookmark | Static evidence | Not implemented | Verify all line actions |
| VO-01 | Voice-over enable/disable, rate, pitch, voice, speech/video volume | Reference verified settings | Not implemented | Test actual TTS speech and audio mixing |
| VO-02 | Automatic rate and mute-video options | Static evidence | Not implemented | Verify automatic timing and mute behavior |
| BM-01 | Bookmarks tab, search, export | Reference verified | Not implemented | Search and export persisted entries |
| BM-02 | Create/edit bookmark: original line, translated line, note | Static evidence | Not implemented | Create, edit, reopen, delete |
| BM-03 | Player bookmarks: play/open/remove | Static evidence | Not implemented | Jump to timestamp and manage item |
| SET-01 | UI language | Reference verified | Not implemented | Switch language and restart |
| SET-02 | Player rotation, translate titles, auto-next, dark mode | Reference verified | Not implemented | Toggle each and verify persistence |
| ADS-01 | No Waleed ad SDK, Advertising ID, banners/interstitial/rewarded ads | Reference includes ad SDK and ad gate | Required from first build | Manifest, DEX, native libraries and runtime inspection |
| ADS-02 | No watch-an-ad gate for caption access | Reference verified ad gate | Required from first build | Full captions without Waleed ad prompt |
| YT-ADS | Do not suppress ads served by YouTube inside YouTube content | Scope boundary | Must remain separate | Do not add an ad blocker or interfere with YouTube playback |
| BILL-01 | Non-ad Premium/purchase/restore behavior | Drawer and paywall present; exact purchase behavior pending | Not implemented | Preserve only if verified; never fake purchase state |
| REL-01 | APK signed, installable, launch, persistence and lifecycle | Not tested | Not implemented | Full clean-install and upgrade test on Android 13 ARM64 |

## Delivery gates
1. No URL-paste-only build can be labelled a Waleed parity release.
2. Each row must be marked coded, static-tested, and device-tested separately.
3. An unimplemented row stays unimplemented; no assumption-based completion.
4. Waleed ads are removed; YouTube's own ad behavior is not modified.
5. Original Lingvotube APKs and app data remain untouched.

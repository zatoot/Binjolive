# Waleed — Implementation Plan
Updated: 2026-11-06

## Target
Independent Flutter Android application matching the user-facing workflows of Lingvotube 5.2.3. The intended product difference is the removal of advertising served by Waleed itself. The application is not a modified copy of Lingvotube.

## Technical direction
- Flutter / Dart, matching the reference application's framework and component model.
- Embedded YouTube player through the documented iframe player API.
- Embedded YouTube browsing through Android WebView.
- YouTube search/metadata/subtitle retrieval through publicly accessible, independently implemented client-side mechanisms; any undocumented endpoints may change and must be treated as unreliable.
- Local translation using Google ML Kit on-device language models.
- Android Text-to-Speech for voice-over.
- SQLite for recent videos, playlists, bookmarks, and settings that need durable records.
- Preferences for lightweight app settings.
- No Firebase credentials, Cloud Function secrets, private signing keys, analytics SDK, ads SDK, or Advertising ID.

## Planned architecture
- `lib/app`: app theme, routes, localization and app shell.
- `lib/screens/videos`: For You, Playlists and Recent tabs.
- `lib/screens/search`: search input, filters, query translation, result cards and state handling.
- `lib/screens/youtube`: embedded YouTube website/search tab.
- `lib/screens/player`: video iframe, related/next videos, caption and voice-over sheets, info.
- `lib/screens/bookmarks`: search, edit, export, and bookmark actions.
- `lib/screens/settings`: UI language, rotation, title translation, autoplay and theme.
- `lib/data`: SQLite schema and repositories.
- `lib/services`: YouTube search/metadata/caption provider, ML Kit translation and TTS.
- `lib/models`: video, caption, playlist, recent and bookmark models.

## Phases and acceptance
1. **Toolchain and base shell** — Flutter ARM64 build tool must be integrity-verified; generate a new Flutter project without touching the Java prototype.
2. **Reference parity shell** — implement navigation, drawer, videos tabs, card model and empty/loading/error states; visually inspect on the phone.
3. **Discovery and search** — implement For You/recommendation feed, in-app search, captions-only filter, query translation, YouTube WebView and external share intake.
4. **Player and captions** — implement the YouTube player, track listing, original/translated synchronized caption UI and ML Kit translation.
5. **Voice-over and persistence** — TTS controls, recent progress, playlists, bookmarks, editing, search and export.
6. **Parity and release verification** — test each feature matrix row on the device, check manifest/DEX/libs for ad SDK, sign APK and test install/launch.

## Non-negotiable rules
- Do not call a feature complete because it compiles.
- Do not use manual URL entry as a substitute for navigation/search.
- Keep the Lingvotube reference package, splits and app data unmodified.
- No Waleed advertisements or watch-an-ad unlock gates.
- Do not interfere with YouTube advertisements itself.
- Preserve non-ad functions and their expected workflow; do not silently omit them.
- Never report a parity release before the live device tests pass.
